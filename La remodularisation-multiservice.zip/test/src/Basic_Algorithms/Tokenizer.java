package Basic_Algorithms;

import Data_Structures.List;


public class Tokenizer {
	//Constructor.
	public Tokenizer(boolean stemmer, boolean stopper){
		this.stemmer = stemmer;
		this.stopper = stopper;
	}


	//Variables.
	private boolean stemmer;
	private boolean stopper;


	//Functions.
	public List<String> Tokenize(String s){
		List<String> terms = new List<String>();

		int pos = FindNextTerm(s);
		while(pos != -1){
			if(pos > 0){
				String term = s.substring(0, pos);

				boolean stoppedWord = false;
				if(stopper){
					Stopper st = new Stopper();
					stoppedWord = st.IsStopWord(term);
				}

				if(stemmer && stoppedWord == false){
					Stemmer st = new Stemmer();
					term = st.stem(term);
				}

				if(stoppedWord == false) terms.Insert(term);
			}

			s = s.substring(pos, s.length());
			pos = FindNextTerm(s);
		}

		return terms;
	}


	private int FindNextTerm(String s){
		int counter = 0;
		for(int i = 0; i < s.length(); ++i){
			if(Character.isUpperCase(s.charAt(i))){
				counter++;
				if(counter == 2) return i;
			}
		}

		if(counter == 1) return s.length();
		else return -1;
	}
}
