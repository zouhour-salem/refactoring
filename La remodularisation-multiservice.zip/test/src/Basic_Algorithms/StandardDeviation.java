package Basic_Algorithms;

import Data_Structures.List;


public class StandardDeviation {
	static public double Calculate(List<Integer> population){
		long n = 0;
	    double mean = 0;
	    double s = 0.0;

	    for (double x : population) {
	    	n++;
	        double delta = x - mean;
	        mean += delta / n;
	        s += delta * (x - mean);
	    }

	    return Math.sqrt(s / n);
	}
}
