package Basic_Algorithms;

import Services_Registry.Operation;

public class Sort {

	//Constructor.
	public Sort(){
		print = false;		
	}


	//Variables.
	private boolean print;


	//Operations.
	public String[] BubbleSort(String[] S){
		S = Copy(S);
		int n = S.length;
		boolean doMore = true;
		while (doMore) {
			n--;
		    doMore = false;
		    for(int i = 0; i < n; i++){
		    	if (S[i].compareTo(S[i+1]) > 0){
		    		doMore = true;
		    		String temp = S[i];
		    		S[i] = S[i+1];
		    		S[i+1] = temp;
		    	}
		    }
		}

		return S;
	}


	private String[] Copy(String[] S1){
		String[] S2 = new String[S1.length];
		for(int i = 0; i < S1.length; ++i) S2[i] = S1[i];
		return S2;
	}


	public void BubbleSort(String priority, Double[] A, Double[] B, Double[] C, Operation[] operations){		//Parallel sorting of C.
		if(print){
			System.out.println("\nBefore Sorting.");
			for(int i = 0; i < C.length; ++i) System.out.println("\nA = " + A[i] + " - B = " + B[i] + " - C = " + C[i] + " - operation = " + operations[i].get_name());
		}

		if(priority.equals("from-to")) BubbleSort_with_respect_A(A, B, operations);
		else if(priority.equals("to-from")) BubbleSort_with_respect_B(A, B, operations);
		else if(priority.equals("sum-from-to")) BubbleSort_with_respect_sum_and_A(A, B, C, operations);
		else if(priority.equals("sum-to-from")) BubbleSort_with_respect_sum_and_B(A, B, C, operations);

		if(print){
			System.out.println("\nAfter Sorting.");
			for(int i = 0; i < C.length; ++i) System.out.println("\nA = " + A[i] + " - B = " + B[i] + " - C = " + C[i] + " - operation = " + operations[i].get_name());
		}
	}


	private void BubbleSort_with_respect_A(Double[] A, Double[] B, Operation[] operations){
		int n = B.length;
		boolean doMore = true;

		while(doMore){
			n--;
		    doMore = false;
		    for(int i = 0; i < n; i++){
		    	if (A[i] < A[i+1]){
		    		doMore = true;

		    		Swap(A, i);
		    		Swap(B, i);
		    		Swap(operations, i);
		    	}

		    	if (A[i] == A[i+1]){
		    		if(B[i] < B[i+1]){
		    			doMore = true;

		    			Swap(A, i);
		    			Swap(B, i);
		    			Swap(operations, i);
		    		}
				}
    		}
		}
	}


	private void BubbleSort_with_respect_B(Double[] A, Double[] B, Operation[] operations){
		int n = B.length;
		boolean doMore = true;

		while(doMore){
			n--;
		    doMore = false;
		    for(int i = 0; i < n; i++){
		    	if (B[i] < B[i+1]){
		    		doMore = true;

		    		Swap(A, i);
		    		Swap(B, i);
		    		Swap(operations, i);
		    	}

		    	if (B[i] == B[i+1]){
		    		if(A[i] < A[i+1]){
		    			doMore = true;

		    			Swap(A, i);
		    			Swap(B, i);
		    			Swap(operations, i);
		    		}
				}
    		}
		}
	}


	private void BubbleSort_with_respect_sum_and_A(Double[] A, Double[] B, Double[] C, Operation[] operations){		//Parallel sorting of C.
		int n = C.length;
		boolean doMore = true;

		while(doMore){
			n--;
			doMore = false;
			for(int i = 0; i < n; i++){
			   	if (C[i] < C[i+1]){
			   		doMore = true;

			   		Swap(A, i);
			   		Swap(B, i);
			   		Swap(C, i);
			   		Swap(operations, i);
			   	}

			   	if (C[i] == C[i+1]){
			   		if(A[i] > B[i] && A[i] < A[i+1]){
			   			doMore = true;

			   			Swap(A, i);
			   			Swap(B, i);
			   			Swap(C, i);
			   			Swap(operations, i);
			   		}

			   		else if(A[i] > B[i] && A[i] == A[i+1]){
			    		if(B[i] < B[i+1]){
			    			doMore = true;

			    			Swap(A, i);
			   				Swap(B, i);
			   				Swap(C, i);
			   				Swap(operations, i);
			   			}
		    		}
				}
    		}
		}
	}


	private void BubbleSort_with_respect_sum_and_B(Double[] A, Double[] B, Double[] C, Operation[] operations){		//Parallel sorting of C.
		int n = C.length;
		boolean doMore = true;

		while(doMore){
			n--;
			doMore = false;
			for(int i = 0; i < n; i++){
			   	if (C[i] < C[i+1]){
			   		doMore = true;

			   		Swap(A, i);
			   		Swap(B, i);
			   		Swap(C, i);
			   		Swap(operations, i);
			   	}

			   	if (C[i] == C[i+1]){
			   		if(B[i] > A[i] && B[i] < B[i+1]){
			   			doMore = true;

			   			Swap(A, i);
			   			Swap(B, i);
			   			Swap(C, i);
			   			Swap(operations, i);
			   		}

			   		else if(B[i] > A[i] && B[i] == B[i+1]){
			    		if(A[i] < A[i+1]){
			    			doMore = true;

			    			Swap(A, i);
			   				Swap(B, i);
			   				Swap(C, i);
			   				Swap(operations, i);
			   			}
		    		}
				}
    		}
		}
	}


	private void Swap(Double[] A, int i){
		Double temp = A[i];
		A[i] = A[i+1];
		A[i+1] = temp;
	}


	private void Swap(Operation[] A, int i){
		Operation temp = A[i];
		A[i] = A[i+1];
		A[i+1] = temp;
	}
}
