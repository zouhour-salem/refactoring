package Basic_Algorithms;

import java.util.HashSet;
import java.util.Set;


public class Stopper {

	//Constructor.
	public Stopper(){
		stopWords = new HashSet<String>();
		stopWords.add("Of");
		stopWords.add("By");
		stopWords.add("For");
		stopWords.add("Off");
		stopWords.add("In");
		stopWords.add("Or");
		stopWords.add("From");
		stopWords.add("To");
		stopWords.add("My");
		stopWords.add("All");
		stopWords.add("Next");
	}


	//Variables.
	Set<String> stopWords;


	//Functions.
	public boolean IsStopWord(String word){
		if(stopWords.contains(word)) return true;
		return false;
	}
}
