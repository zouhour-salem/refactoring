package Basic_Algorithms;


public class EditDistance {

	//Operations.
	static public float CalculateNED(String first, String second, boolean without_prefix){
		float NED = 0, ED = 0;

		float n = first.length(); 
		float m = second.length();

		if(without_prefix = true) ED = CalculateED_without_prefix_verb(first, second);
		else ED = CalculateED(first, second);

		NED = (2 * ED) / (n + m + ED);

		return NED;
	}


	static private int CalculateED(String first, String second){
		int ED = 0;

		int n = first.length(); 
		int m = second.length();

		String sub = get_Longest_Common_Substring(first, second);
		int lcs = sub.length();
		
		ED = n + m - 2 * lcs; 
		
		return ED;
	}
	
	
	static private int CalculateED_without_prefix_verb(String first, String second){
		int ED = 0;

		int index_first = Find_the_prefix_Verb(first);
		int index_second = Find_the_prefix_Verb(second);

		if(index_first != -1) first = first.substring(index_first, first.length());
		if(index_second != -1) second = second.substring(index_second, second.length());
		
		int n = first.length(); 
		int m = second.length();

		String sub = get_Longest_Common_Substring(first, second);
		int lcs = sub.length();
		
		ED = n + m - 2 * lcs; 
		
		return ED;
	}

	
	static private int Find_the_prefix_Verb(String s){
		for(int i = 0; i < s.length(); ++i) 
			if(Character.isUpperCase(s.charAt(i))) return i;
		return -1;
	}


	static public String get_Longest_Common_Substring(String first, String second) {
		String tmp = "";
	    String max = "";
	                     
	    for(int i=0; i < first.length(); i++){
	    	for (int j=0; j < second.length(); j++){
	    		for (int k=1; (k+i) <= first.length() && (k+j) <= second.length(); k++){
	    			if (first.substring(i, k+i).equals(second.substring(j, k+j))){
	    				tmp = first.substring(i,k+i);
	                }
	                else{
	                	if (tmp.length() > max.length())
	                		max=tmp;
	                    
	                	tmp="";
	                }
	            }

	    		if (tmp.length() > max.length())
	    			max=tmp;
	    		
	    		tmp="";
	        }
	     }

	     return max;
	}
}
