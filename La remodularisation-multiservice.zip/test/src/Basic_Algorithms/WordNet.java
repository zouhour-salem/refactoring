package Basic_Algorithms;

import rita.wordnet.RiWordnet;
import edu.smu.tspell.wordnet.*;


public class WordNet {

	//Constructor.
	public WordNet(){
		System.setProperty("wordnet.database.dir", "C://Program Files/WordNet/2.1/dict");
		database = WordNetDatabase.getFileInstance(); 
	}


	//Variables.
	WordNetDatabase database;


	//Operations.
	public void FindSynonyms(String word){
		NounSynset nounSynset;
		NounSynset[] hyponyms;
		

		Synset[] synsets = database.getSynsets(word, SynsetType.NOUN);
		
		for (int i = 0; i < synsets.length; i++) {
		    nounSynset = (NounSynset)(synsets[i]);
		    hyponyms = nounSynset.getHyponyms();
		    System.out.println(nounSynset.getWordForms()[0] + ": " + nounSynset.getDefinition() + ") has " + hyponyms.length + " hyponyms");
		} 
	}
}
