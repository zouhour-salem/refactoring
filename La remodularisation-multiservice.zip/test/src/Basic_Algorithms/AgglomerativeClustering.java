package Basic_Algorithms;


public class AgglomerativeClustering {
	//Constructor.
	public AgglomerativeClustering(){
		
	}


	//Operations.
	public void Cluster(Double[][] table){
		//Initialize dataset.
		
	}
}
