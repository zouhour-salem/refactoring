package Basic_Algorithms;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import Data_Structures.List;

public class Intersection {

	//Operations.
	public List<String> Find(String[] S1, String[] S2){
		Set<String> S1_set = new HashSet<String>();
		for(int i = 0; i < S1.length; ++i) S1_set.add(S1[i]);

		Set<String> S2_set = new HashSet<String>();
		for(int i = 0; i < S2.length; ++i) S2_set.add(S2[i]);

		Set<String> intersection_set = new HashSet<String>();
	    for (String x : S1_set) if (S2_set.contains(x)) intersection_set.add(x);

		List<String> intersection = new List<String>();
		Iterator<String> iter = intersection_set.iterator();
		while (iter.hasNext()) intersection.Insert((String)iter.next());

		return intersection;
	}


	public int Find(List<String> S1, List<String> S2){
		Set<String> S1_set = new HashSet<String>();
		for(int i = 0; i < S1.length(); ++i) S1_set.add(S1.get(i));

		Set<String> S2_set = new HashSet<String>();
		for(int i = 0; i < S2.length(); ++i) S2_set.add(S2.get(i));

		Set<String> intersection_set = new HashSet<String>();
	    for (String x : S1_set) if (S2_set.contains(x)) intersection_set.add(x);

		List<String> intersection = new List<String>();
		Iterator<String> iter = intersection_set.iterator();
		while (iter.hasNext()) intersection.Insert((String)iter.next());

		return intersection.length();
	}
}
