package Basic_Algorithms;

import Data_Structures.List;


public class ConceptualDistance {

	//Operations.
	public float Calculate(String first, String second, boolean remove_prefix){
		float CD = 0;

		Tokenizer tok = new Tokenizer(true, true); 
		List<String> firstList = tok.Tokenize(first);
		List<String> secondList = tok.Tokenize(second);

		if(remove_prefix = true){
			if(firstList.length() > 1)	firstList.Remove(firstList.length() - 1);
			if(secondList.length() > 1)	secondList.Remove(secondList.length() - 1);
		}

		//System.out.println("First Word");for(int i = 0;i < firstList.length(); ++i) System.out.println("\t" + firstList.get(i));
		//System.out.println("Second Word");for(int i = 0;i < secondList.length(); ++i) System.out.println("\t" + secondList.get(i));

		Intersection sec = new Intersection();
		int commonTerms = sec.Find(firstList, secondList);
		//System.out.println("Intersection = " + commonTerms);

		Union un = new Union();
		int allTerms = un.Find(firstList, secondList);
		//System.out.println("Union = " + allTerms);

		CD = 1 - (float)commonTerms/(float)allTerms;
		//System.out.println("Conceptual Distance = " + CD);
		
		return CD;
	}


	
}
