package Basic_Algorithms;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import Data_Structures.List;

public class Union {

	//Operations.
	public List<String> Find(String[] S1, String[] S2){
		Set<String> set = new HashSet<String>();
		for(int i = 0; i < S1.length; ++i) set.add(S1[i]);
		for(int i = 0; i < S2.length; ++i) set.add(S2[i]);

		List<String> list = new List<String>();
		Iterator<String> iter = set.iterator();
		while (iter.hasNext()) list.Insert((String)iter.next());

		return list;
	}


	public int Find(List<String> S1, List<String> S2){
		Set<String> set = new HashSet<String>();
		for(int i = 0; i < S1.length(); ++i) set.add(S1.get(i));
		for(int i = 0; i < S2.length(); ++i) set.add(S2.get(i));

		List<String> list = new List<String>();
		Iterator<String> iter = set.iterator();
		while (iter.hasNext()) list.Insert((String)iter.next());

		return list.length();
	}
}
