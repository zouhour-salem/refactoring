package Basic_Algorithms;

import Data_Structures.List;

public class CombinationGenerator {
	//Variables.
	private List<Double> values;
	private int length;
	private Double[][] table;


	//Constructor.
	public CombinationGenerator(List<Double> values, int length) {
		this.length = length;
		this.values = values;
	}


	//Operations.
	public Double[][] Generate() {
		int l = values.length();
		int permutations = (int) Math.pow(l, length);
		table = new Double[permutations][length];

		for (int x = 0; x < length; x++) {
		    int t2 = (int) Math.pow(l, x);
		    for (int p1 = 0; p1 < permutations;) {
		        for (int al = 0; al < l; al++) {
		            for (int p2 = 0; p2 < t2; p2++) {
		                table[p1][x] = values.get(al);
		                p1++;
		            }
		        }
		    }
		}

		int counter = 0;
		for (int i = 0; i < table.length; i++) {
			counter++;
			System.out.print(counter + ":\t");
		    for (int j = 0; j < table[i].length; ++j){
		    	System.out.print(table[i][j] + "\t");
		    }
		    
			System.out.println();
		}

		return table;
	}
}