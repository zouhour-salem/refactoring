/*  
 * ====================================================================  
 *   
 * The Apache Software License, Version 1.1  
 *  
 * Copyright (c) 2003 Nick Lothian. All rights reserved.  
 *  
 * Redistribution and use in source and binary forms, with or without  
 * modification, are permitted provided that the following conditions  
 * are met:  
 *  
 * 1. Redistributions of source code must retain the above copyright  
 *    notice, this list of conditions and the following disclaimer.   
 *  
 * 2. Redistributions in binary form must reproduce the above copyright  
 *    notice, this list of conditions and the following disclaimer in  
 *    the documentation and/or other materials provided with the  
 *    distribution.  
 *  
 * 3. The end-user documentation included with the redistribution, if  
 *    any, must include the following acknowlegement:    
 *       "This product includes software developed by the   
 *        developers of Classifier4J (http://classifier4j.sf.net/)."  
 *    Alternately, this acknowlegement may appear in the software itself,  
 *    if and wherever such third-party acknowlegements normally appear.  
 *  
 * 4. The name "Classifier4J" must not be used to endorse or promote   
 *    products derived from this software without prior written   
 *    permission. For written permission, please contact     
 *    http://sourceforge.net/users/nicklothian/.  
 *  
 * 5. Products derived from this software may not be called   
 *    "Classifier4J", nor may "Classifier4J" appear in their names   
 *    without prior written permission. For written permission, please   
 *    contact http://sourceforge.net/users/nicklothian/.  
 *  
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED  
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES  
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE  
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR  
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT  
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF  
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND  
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,  
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT  
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF  
 * SUCH DAMAGE.  
 * ====================================================================  
 */   
   
package net.sf.classifier4J;   
   
import java.util.Arrays;   
   
import net.sf.classifier4J.util.ToStringBuilder;   
   
   
/**  
 * @author Nick Lothian  
 * @author Peter Leschev  
 */   
public class DefaultStopWordsProvider implements IStopWordProvider {   
    // This array is sorted in the constructor   
    private String[] stopWords =  {"a", "about", "above", "above", "across", "after", "afterwards", "again", "against", "all", "almost",
		     "alone", "along", "already", "also", "although", "always", "am", "among", "amongst", "amoungst", "amount", "an", "and",
		     "another", "any", "anyhow", "anyone", "anything", "anyway", "anywhere", "are", "around", "as", "at", "back", "be", "became",
		     "because", "become", "becomes", "becoming", "been", "before", "beforehand", "behind", "being", "below", "beside", "besides",
		     "between", "beyond", "bill", "both", "bottom", "but", "by", "call", "can", "cannot", "cant", "co", "con", "could", "couldnt",
		     "cry", "de", "describe", "detail", "do", "done", "down", "due", "during", "each", "eg", "eight", "either", "eleven", "else",
		     "elsewhere", "empty", "enough", "etc", "even", "ever", "every", "everyone", "everything", "everywhere", "except", "few",
		     "fifteen", "fify", "fill", "find", "fire", "first", "five", "for", "former", "formerly", "forty", "found", "four", "from",
		     "front", "full", "further", "get", "give", "go", "had", "has", "hasnt",
		     "have", "he", "hence", "her", "here", "hereafter", "hereby", "herein", "hereupon", "hers", "herself",
		     "him", "himself", "his", "how", "however", "hundred", "ie", "if", "in", "inc", "indeed", "interest", "into",
		     "is", "it", "its", "itself", "keep", "last", "latter", "latterly", "least", "less", "ltd", "made", "many",
		     "may", "me", "meanwhile", "might", "mill", "mine", "more", "moreover", "most", "mostly", "move", "much", "must",
		     "my", "myself", "name", "namely", "neither", "never", "nevertheless", "next", "nine", "no", "nobody", "none",
		     "noone", "nor", "not", "nothing", "now", "nowhere", "of", "off", "often", "on", "once", "one", "only", "onto",
		     "or", "other", "others", "otherwise", "our", "ours", "ourselves", "out", "over", "own", "part", "per", "perhaps",
		     "please", "put", "rather", "re", "same", "see", "seem", "seemed", "seeming", "seems", "serious", "several", "she",
		     "should", "show", "side", "since", "sincere", "six", "sixty", "so", "some", "somehow", "someone", "something",
		     "sometime", "sometimes", "somewhere", "still", "such", "system", "take", "ten", "than", "that", "the", "their",
		     "them", "themselves", "then", "thence", "there", "thereafter", "thereby", "therefore", "therein", "thereupon",
		     "these", "they", "thickv", "thin", "third", "this", "those", "though", "three", "through", "throughout", "thru",
		     "thus", "to", "together", "too", "toward", "towards", "twelve", "twenty", "two", "un", "under", "until",
		     "up", "upon", "us", "very", "via", "was", "we", "well", "were", "what", "whatever", "when", "whence", "whenever",
		     "where", "whereafter", "whereas", "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while",
		     "whither", "who", "whoever", "whole", "whom", "whose", "why", "will", "with", "within", "without", "would", "yet",
		     "you", "your", "yours", "yourself", "yourselves", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "1.", "2.", "3.", "4.", "5.", "6.", "11",
		     "7.", "8.", "9.", "12", "13", "14", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
		     "terms", "CONDITIONS", "conditions", "values", "interested.", "care", "sure", ".", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "{", "}", "[", "]", ":", ";", ",", "<", ".", ">", "/", "?", "_", "-", "+", "=",
		     "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
		     "contact", "grounds", "buyers", "tried", "said,", "plan", "value", "principle.", "forces", "sent:", "is,", "was", "like",
		     "discussion", "tmus", "diffrent.", "layout", "area.", "thanks", "thankyou", "hello", "bye", "rise", "fell", "fall", "psqft.", "http://", "km", "miles"} ;
    
    
    
    private String[] sortedStopWords = null;   
   
    public DefaultStopWordsProvider() {   
        sortedStopWords = getStopWords();   
        Arrays.sort(sortedStopWords);   
    }   
   
    /**  
     * getter method which can be overridden to   
     * supply the stop words. The array returned by this   
     * method is sorted and then used internally  
     *   
     * @return the array of stop words  
     */   
    public String[] getStopWords() {   
        return stopWords;   
    }   
   
    /**  
     * @see net.sf.classifier4J.IStopWordProvider#isStopWord(java.lang.String)  
     */   
    public boolean isStopWord(String word) {   
        if (word == null || "".equals(word)) {   
            return false;   
        } else {   
            // search the sorted array for the word, converted to lowercase   
            // if it is found, the index will be >= 0   
            return (Arrays.binarySearch(sortedStopWords, word.toLowerCase()) >= 0);   
        }   
    }   
   
    public String toString() {   
        return new ToStringBuilder(this).append("stopWords.size()", sortedStopWords.length).toString();   
    }   
}  