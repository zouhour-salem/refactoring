package Services_Registry_Processor;

import org.jdom.*;

import Services_Registry.*;
import Data_Structures.*;


public class Service_Parser{

	//Constructor.
	Service_Parser(){
		wsdl_print = true;
		schema_print = false;		
	}


	//Variables.
	private boolean wsdl_print;
	private boolean schema_print;


	//Operations.
	public Service_Provider Parse(String name_of_service_provider, java.util.List<?> contents){	
		List<XML_Type> XML_types = Parse_XML_Schema(contents);

		Runtime.getRuntime().gc();		//Call garbage collector.
		//if(schema_print) System.out.println("Finishing the call of garbage collector after parsing XML schema.");

		Service_Provider provider = Parse_WSDL_Services(name_of_service_provider, contents, XML_types);

		Runtime.getRuntime().gc();		//Call garbage collector.
		//if(wsdl_print) System.out.println("Finishing the call of garbage collector after parsing WSDL services.");

		return provider;
		//return null;
	}

	
	//----------------------------------- Parse_XML_Schema : START -----------------------------------
	public List<XML_Type> Parse_XML_Schema(java.util.List<?> contents){
		java.util.List<?> sub_contents = get_contents("schema", null, contents);
		List<XML_Type> XML_types = get_XML_Types_in_One_Level(sub_contents, null, new List<XML_Type>());	//First level XML types.

		Queue<XML_Type> Q = new Queue<XML_Type>();
		Q.Enqueue(XML_types);

		while(Q.isEmpty() == false){
			XML_Type type = Q.Dequeue();

			Object obj = type.get_type_obj();
			Element elt = (Element)obj;
			List<XML_Type> sub_types = get_XML_Types_in_One_Level(elt.getContent(), type, XML_types);

			if(sub_types.length() == 1 && sub_types.get(0).equals(type)){	//We have the following case: <xs:element name="..."><xs:simpleType><xs:restriction base="xs:string">..., and I have to update the parent type as built-in type even if I return a subtype, it is fake.
				type = sub_types.get(0);			
			}

			else if(sub_types.length() > 0){	
				type.set_is_ref(false);
				type.set_sub_types(sub_types);		//Create the hierarchical structure of the XML types.
				Q.Enqueue(sub_types);
			}

			else if(sub_types.length() == 0){
				Basic_Type_Hierarchy H = new Basic_Type_Hierarchy();
				String t = get_type(obj);
				type.set_type(t);

				if(H.Is_Basic_Type(t)){
					type.set_is_basic_type(true);
					type.set_is_ref(false);
				}
				else{
					type.set_is_basic_type(false);

					if(Is_Defined(type)) type.set_is_ref(true);		//the 'type' is reference.
					else type.set_is_ref(false);					//Undefined type.
				}
			}
		}


		XML_types = Free_obj(XML_types);
		Print_XML_Schema(XML_types);

		return XML_types;
	}


	private boolean Is_Defined(XML_Type type){
		Object obj = type.get_type_obj();
		Element elt = (Element)obj;
		java.util.List<?> attribs = elt.getAttributes();

		int count = 0; 
		for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
			at.next();
			++count;
		}

		if(count == 1){
			if(Is_element___ref(elt))	return true;	//We have the occasion: <xs:element ref="tns:ResponseStatus"/>
			else return false;							//Undefined type (void).
		}
		else return true;
	}


	/******************************** Get types in 1 Level ********************************/ 
	private List<XML_Type> get_XML_Types_in_One_Level(java.util.List<?> contents, XML_Type parent_type, List<XML_Type> so_far_XML_types){//This function finds the 'element' tag in one level, not recursively.
		List<XML_Type> XML_types = new List<XML_Type>();

		for (java.util.Iterator<?> it = contents.iterator(); it.hasNext();){
			Object obj = it.next();
			if (obj instanceof Element){
				Element elt = (Element)obj;

				if(Is_simpleType_or_complexType_without_name(elt)){		//Go one step inside the tag which is not "element or "attribute" or "simpleType" or "complexType".
					List<XML_Type> tmp_XML_types = get_XML_Types_in_One_Level(elt.getContent(), parent_type, so_far_XML_types);
					for(int i = 0; i < tmp_XML_types.length(); ++i) XML_types.Insert(tmp_XML_types.get(i));
				}

				else{
					String type_name1 = Is_element_or_attribute_or_simpleType_or_complexType___name_or_ref(elt);
					String type_name2 = Is_restriction___base(elt);

					if(type_name1 != null){		//I do not set its id, it is set -1, its real id will be set later.
						XML_Type type = new XML_Type(-1, obj, type_name1, parent_type);
						XML_types.Insert(type);
						//if(schema_print) System.out.println("--> \nElement or attribute or simpleType or complexType = " + type_name1 + "\n");
					}

					else if(type_name2 != null){
						parent_type.set_type(type_name2);
						parent_type.set_is_basic_type(true);
						parent_type.set_is_ref(false);
						XML_types.Insert(parent_type);
						//if(schema_print) System.out.println("--> \nRestriction and base = " + type_name2 + "\n");
					}

					else{
						//Go one step inside the tag which is not "element or "attribute" or "simpleType" or "complexType" or "restriction".
						List<XML_Type> tmp_XML_types = get_XML_Types_in_One_Level(elt.getContent(), parent_type, so_far_XML_types);
						for(int i = 0; i < tmp_XML_types.length(); ++i) XML_types.Insert(tmp_XML_types.get(i));
					}
				}
			}
		}

		Runtime.getRuntime().gc();		//Call garbage collector.

		return XML_types;
	}


	private boolean Is_element___ref(Element elt){
		if(elt.getName().equals("element")){
			java.util.List<?> attribs = elt.getAttributes();
			for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
				Attribute attrib = (Attribute)at.next();
				if(attrib.getName().equals("ref")) return true;
			}
		}

		return false;
	}


	private String Is_element_or_attribute_or_simpleType_or_complexType___name_or_ref(Element elt){
		if(elt.getName().equals("element") || elt.getName().equals("attribute") || elt.getName().equals("simpleType") || elt.getName().equals("complexType")){
			java.util.List<?> attribs = elt.getAttributes();
			for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
				Attribute attrib = (Attribute)at.next();
				String type_name = Clear_a_Token(attrib.getValue());
				if(attrib.getName().equals("name") || attrib.getName().equals("ref")) return type_name;
			}
		}

		return null;
	}


	private String Is_restriction___base(Element elt){
		if(elt.getName().equals("restriction")){
			java.util.List<?> attribs = elt.getAttributes();
			for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
				Attribute attrib = (Attribute)at.next();
				String built_in = Clear_a_Token(attrib.getValue());

				if(attrib.getName().equals("base"))	//We have the following case: <xs:element name="..."><xs:simpleType><xs:restriction base="xs:string">..., and I have to update the parent type as built-in type even if I return a subtype, it is fake.
					return built_in;
			}
		}

		return null;
	}


	private boolean Is_simpleType_or_complexType_without_name(Element elt){
		boolean flag = false;
		if(elt.getName().equals("simpleType") || elt.getName().equals("complexType")){
			java.util.List<?> attribs = elt.getAttributes();
			flag = true;
			for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
				Attribute attrib = (Attribute)at.next();
				if(attrib.getName().equals("name") || attrib.getName().equals("ref")) flag = false;
			}
		}

		return flag;
	}
	/******************************** Get types in 1 Level ********************************/


	private List<XML_Type> Free_obj(List<XML_Type> XML_types){
		for(int i = 0; i < XML_types.length(); ++i){
			XML_Type type = XML_types.get(i);
			type.Free_XML_type_obj();
		}

		return XML_types;
	}


	private XML_Type Find_in_first_level_of_Schema(String cname, List<XML_Type> XML_types){
		//if(schema_print) System.out.println("First Level Types:");
		for(int i = 0; i < XML_types.length(); ++i){
			XML_Type type = XML_types.get(i);
			String name = type.get_name();
			//if(schema_print) System.out.println("type = " + type.get_name());
			if(name.equals(cname)) return type;
		}
		
		return null;
	}


	private void Print_XML_Schema(List<XML_Type> XML_types){
		for(int i = 0; i < XML_types.length(); ++i){
			//if(schema_print) System.out.println("First Level Type (" + i + "):");

			XML_Type type = XML_types.get(i);
			Queue<XML_Type> Q = new Queue<XML_Type>();
			Q.Enqueue(type);

			while(Q.isEmpty() == false){
				type = Q.Dequeue();

				if(schema_print){
					//if(type.get_parent_type() == null && !type.Is_Basic_Type()) System.out.println("(name = " + type.get_name() + ", ref = " + type.Is_Ref() + ", built-in = " + type.Is_Basic_Type() + ", parent = null" + ", children = " + type.get_sub_types().length());
					//if(type.get_parent_type() == null && type.Is_Basic_Type()) System.out.println("(name = " + type.get_name() + ", ref = " + type.Is_Ref() + ", built-in = " + type.Is_Basic_Type() + ", type = " + type.get_type() + ", parent = null" + ", children = " + type.get_sub_types().length());
					//if(type.get_parent_type() != null && type.Is_Basic_Type()) System.out.println("(name = " + type.get_name() + ", ref = " + type.Is_Ref() + ", built-in = " + type.Is_Basic_Type() + ", type = " + type.get_type() + ", parent = " + type.get_parent_type().get_name() + ", children = " + type.get_sub_types().length());
					//if(type.get_parent_type() != null && !type.Is_Basic_Type()) System.out.println("(name = " + type.get_name() + ", ref = " + type.Is_Ref() + ", built-in = " + type.Is_Basic_Type() + ", type = " + type.get_type() + ", parent = " + type.get_parent_type().get_name() + ", children = " + type.get_sub_types().length());
				}

				List<XML_Type> sub_types = type.get_sub_types();
				Q.Enqueue(sub_types);
			}
		}
	}
	//----------------------------------- Parse_XML_Schema : END -------------------------------------


	//----------------------------------- Parse_WSDL_Services : START ------------------------------------
	public Service_Provider Parse_WSDL_Services(String name_of_service_provider, java.util.List<?> contents, List<XML_Type> XML_types){//Returns a list of full Service objects.
		Service_Provider provider = new Service_Provider(name_of_service_provider);

		List<String> services = get_Services(contents);
		for(int i = 0; i < services.length(); ++i){
			String service_name = services.get(i);
			Service service = provider.Insert(service_name);

			List<String> pTs = get_portTypes(service_name, contents);//Returns an empty list of portTypes Object.
			for(int p = 0; p < pTs.length(); ++p){
				String portType_name = pTs.get(p);
				portType pT = service.Insert(portType_name);

				java.util.List<?> portType_contents = get_contents("portType", portType_name, contents);
				List<String> ops = get_Operations(portType_name, portType_contents);
				for(int op = 0; op < ops.length(); ++op){
					String operation_name = ops.get(op);
					Operation operation = pT.Insert(operation_name);
					java.util.List<?> operation_contents = get_contents("operation", operation_name, portType_contents);

					String In_msg_name = get_Input_Msg(operation_name, operation_contents);					
					Message In_Msg = operation.Insert_Input_Msg(In_msg_name);
					String message_in_name = In_Msg.get_name();

					java.util.List<?> message_in_contents = get_contents("message", message_in_name, contents);
					List<String> In_parts = get_Parts(message_in_name, message_in_contents);
					for(int in_p = 0; in_p < In_parts.length(); ++in_p){
						String part_name = In_parts.get(in_p);
						Part part = In_Msg.Insert(part_name, null);
						String type_name = get_XML_Type(part_name, message_in_contents);
						
						XML_Type type = null;
						Basic_Type_Hierarchy H = new Basic_Type_Hierarchy();
						if(H.Is_Basic_Type(type_name)) type = new XML_Type(part_name, type_name, null);
						else{
							type = Find_in_first_level_of_Schema(type_name, XML_types);
							if(type == null){
								//if(schema_print) System.out.println("Undefined XML data type = " + type_name);
								type = Copy_sub_types(type_name);
							}

							else{
								//if(schema_print) System.out.println("Input Message with type = " + type.get_name());
								type = Copy_sub_types(type, null, XML_types);
							}
						}

						part.set_XML_type(type);
					}

					In_Msg.Generate_Parent_Matrix();

					String Out_msg_name = get_Output_Msg(operation_name, operation_contents);					
					Message Out_Msg = operation.Insert_Output_Msg(Out_msg_name);
					String message_out_name = Out_Msg.get_name();

					java.util.List<?> message_out_contents = get_contents("message", message_out_name, contents);
					List<String> Out_parts = get_Parts(message_out_name, message_out_contents);
					for(int out_p = 0; out_p < Out_parts.length(); ++out_p){
						String part_name = Out_parts.get(out_p);
						Part part = Out_Msg.Insert(part_name, null);
						String type_name = get_XML_Type(part_name, message_out_contents);

						XML_Type type = null;
						Basic_Type_Hierarchy H = new Basic_Type_Hierarchy();
						if(H.Is_Basic_Type(type_name)) type = new XML_Type(part_name, type_name, null);
						else{
							type = Find_in_first_level_of_Schema(type_name, XML_types);
							if(type == null){
								//if(schema_print) System.out.println("Undefined XML data type = " + type_name);
								type = Copy_sub_types(type_name);
							}

							else{
								//if(schema_print) System.out.println("Output Message with type = " + type.get_name());
								type = Copy_sub_types(type, null, XML_types);
							}
						}

						part.set_XML_type(type);
					}

					Out_Msg.Generate_Parent_Matrix();

					Runtime.getRuntime().gc();		//Call garbage collector.
				}

				Runtime.getRuntime().gc();		//Call garbage collector.
			}

			Runtime.getRuntime().gc();		//Call garbage collector.
		}

		//Get the jvm heap size.
        long heapSize = Runtime.getRuntime().totalMemory();
        long freeHeapSize = Runtime.getRuntime().freeMemory();

        //Print the jvm heap size.
        //System.out.println("Before Identify_Excluded_Elements --> Heap Size = " + heapSize + " Free = " + freeHeapSize);

		provider.Identify_Excluded_Elements();

		//Get the jvm heap size.
        heapSize = Runtime.getRuntime().totalMemory();
        freeHeapSize = Runtime.getRuntime().freeMemory();

        //Print the jvm heap size.
       // System.out.println("After Identify_Excluded_Elements --> Heap Size = " + heapSize + " Free = " + freeHeapSize);

		//if(schema_print) System.out.println("Parse_WSDL_Services: END.");

		return provider;
	}


	private XML_Type Copy_sub_types(String type_name){	//This is to define a copy_type for a surely Undefined type.
		XML_Type copy_type = new XML_Type(-1, null, type_name, null);
		copy_type.set_type(null);
		copy_type.set_is_ref(false);
		copy_type.set_is_basic_type(false);

		return copy_type;
	}


	private XML_Type Copy_sub_types(XML_Type hard_type, XML_Type parent_type, List<XML_Type> XML_types){
		XML_Type copy_type = null;
		XML_Type copy_type2 = null;
		XML_Type new_XML_type = null;
		List<XML_Type> sub_types = null;
		Queue<XML_Type> Q = new Queue<XML_Type>();

		if(hard_type.Is_Basic_Type()){
			//if(wsdl_print) System.out.println("Recursion for the hard_type = (" + hard_type.get_name() + ", " + hard_type.get_type() + ").");
			copy_type = new XML_Type(hard_type.get_name(), hard_type.get_type(), parent_type);
		}
		else{
			//if(wsdl_print) System.out.println("Recursion for the hard_type = " + hard_type.get_name() + ", which is complex type.");
			copy_type = new XML_Type(-1, null, hard_type.get_name(), parent_type);
			copy_type.set_type(hard_type.get_type());
			copy_type.set_is_ref(hard_type.Is_Ref());
			copy_type.set_sub_types(hard_type.get_sub_types());
			copy_type.set_is_basic_type(hard_type.Is_Basic_Type());
		}

		new_XML_type = copy_type;
		Q.Enqueue(copy_type);

		while(!Q.isEmpty()){
			copy_type = Q.Dequeue();
			//if(wsdl_print) System.out.println("Dequeue the copy_type = (" + copy_type.get_name() + ", " + copy_type.get_type() + ").");

			if(copy_type.Is_Ref()){
				if(copy_type.get_type() == null) hard_type = Find_in_first_level_of_Schema(copy_type.get_name(), XML_types);
				else hard_type = Find_in_first_level_of_Schema(copy_type.get_type(), XML_types);

				//if(wsdl_print) System.out.println("copy_type = (" + copy_type.get_name() + ", " + copy_type.get_type() + ") is ref and I found the hard type = " + hard_type.get_name());

				copy_type.Add_sub_type(Copy_sub_types(hard_type, copy_type, XML_types));		//Parent_type is the copy_type.

				//if(wsdl_print) System.out.println("copy_type = (" + copy_type.get_name() + ", " + copy_type.get_type() + ") after recursion.");
			}

			else{
				sub_types = copy_type.get_sub_types();
				copy_type.set_sub_types(new List<XML_Type>());
				//if(wsdl_print) System.out.println("copy_type = (" + copy_type.get_name() + ", " + copy_type.get_type() + ").");

				int len = sub_types.length();
				//if(wsdl_print) System.out.println("Length of copy_type = " + copy_type.get_name() + " is " + len);

				for(int i = 0; i < len; ++i){
					if(sub_types.get(i).Is_Basic_Type()) copy_type2 = new XML_Type(sub_types.get(i).get_name(), sub_types.get(i).get_type(), copy_type);
					else{
						copy_type2 = new XML_Type(-1, null, sub_types.get(i).get_name(), copy_type);
						copy_type2.set_type(sub_types.get(i).get_type());
						copy_type2.set_is_ref(sub_types.get(i).Is_Ref());
						copy_type2.set_sub_types(sub_types.get(i).get_sub_types());
						copy_type2.set_is_basic_type(sub_types.get(i).Is_Basic_Type());

						Q.Enqueue(copy_type2);
					}

					copy_type.Add_sub_type(copy_type2);

					//TODO: Cycles!
					/*if(copy_type2.Is_Ref() && Check_for_Cycle(copy_type2)){
						if(this.wsdl_print) System.out.println("Cycle for the type = (" + copy_type2.get_name() + ", " + copy_type2.get_type() + ").");
						Print_Path(copy_type2);
						System.exit(0);
					}*/
				}
			}
		}

		return new_XML_type;
	}


	public boolean Check_for_Cycle(XML_Type copy_type2){
		XML_Type parent = copy_type2.get_parent_type();
		while(parent != null){
			if(parent.get_type() == null && parent.get_name() != null && parent.get_name().equals(copy_type2.get_name())) return true;
			if(parent.get_type() != null && parent.get_type().equals(copy_type2.get_name())) return true;
			parent = parent.get_parent_type();
		}

		return false;
	}


	public void Print_Path(XML_Type copy_type2){
		XML_Type parent = copy_type2.get_parent_type();

		//if(wsdl_print) System.out.println("\tService_Parser - Print_Path : type = (" + copy_type2.get_name() + ", " + copy_type2.get_type() + ").");
		//if(wsdl_print) System.out.println("\tService_Parser - Print_Path : type = (" + parent.get_name() + ", " + parent.get_type() + ").");

		while(parent != null){
			parent = parent.get_parent_type();

			//if(wsdl_print && parent != null) System.out.println("\tService_Parser - Print_Path : type = (" + parent.get_name() + ", " + parent.get_type() + ").");
		}
	}
	//----------------------------------- Parse_WSDL_Services : END --------------------------------------


	//----------------------------------- get_Services : START --------------------------------------------------
	private List<String> get_Services(java.util.List<?> contents){//Returns a list of empty Service objects.
		List<String> services = new List<String>();

		for (java.util.Iterator<?> it = contents.iterator(); it.hasNext();){
			Object obj = it.next();

			if (obj instanceof Element){
				Element elt = (Element)obj;

				if(elt.getName().equals("service")){
					String service_name = get_name(obj);
					services.Insert(service_name);
				}

				List<String> tmp_services = get_Services(elt.getContent());
				services.Insert(tmp_services);
			}
		}

		return services;
	}
	//----------------------------------- get_Services : END ---------------------------------------------------


	//----------------------------------- get_portTypes : START ---------------------------------------
	private List<String> get_portTypes(String service_name, java.util.List<?> contents){//Returns a string list of portType names.
		List<String> pTs = new List<String>();

		java.util.List<?> binding_contents  = get_contents("service", service_name, contents);
		List<String> bindings_names = get_names("port", "binding", binding_contents);
		for(int i = 0; i < bindings_names.length(); ++i){
			Object binding_object = get_object("binding", bindings_names.get(i), contents);
			String portType_name = get_type(binding_object);

			if(Search_Clone_portType(portType_name, pTs) == false) pTs.Insert(portType_name);
		}

		return pTs;
	}


	private boolean Search_Clone_portType(String name, List<String> pTs){//Search Clone portType via its name.
		for(int i = 0; i < pTs.length(); ++i) if(pTs.get(i).equals(name)) return true;
		return false;
	}
	//----------------------------------- get_portTypes : END ---------------------------------------
	
	
	//----------------------------------- get_Operation : START ---------------------------------------
	private List<String> get_Operations(String portType_name, java.util.List<?> contents){//Returns a list of empty Operations Objects.
		List<String> ops = new List<String>();

		List<String> operation_names = get_names("operation", "name", contents);
		for(int i = 0; i < operation_names.length(); ++i){
			String operation_name = operation_names.get(i);
			ops.Insert(operation_name);
		}

		return ops;
	}	
	//----------------------------------- get_Operation : END ---------------------------------------
	
	
	//----------------------------------- get_Input_Msg : START ---------------------------------------
	private String get_Input_Msg(String operation_name, java.util.List<?> operation_contents){//Returns the Input Message name.
		List<String> In_Msg_name = get_names("input", "message", operation_contents);
		String message_name = In_Msg_name.get(0);							 //Of course, the list will have only one element.
		return message_name;
	}
	//----------------------------------- get_Input_Msg : END ---------------------------------------
	
	
	//----------------------------------- get_Output_Msg : START ---------------------------------------
	private String get_Output_Msg(String operation_name, java.util.List<?> operation_contents){//Returns the Output Message name.
		List<String> Out_Msg_name = get_names("output", "message", operation_contents);
		String message_name = Out_Msg_name.get(0);							 //Of course, the list will have only one element.
		return message_name;
	}
	//----------------------------------- get_Output_Msg : END ---------------------------------------
	
	

	//----------------------------------- get_Parts : START ---------------------------------------
	private List<String> get_Parts(String message_name, java.util.List<?> message_contents){//Returns a list of empty parts Object.
		List<String> parts = new List<String>();

		List<String> part_names = get_names("part", "name", message_contents);
		for(int i = 0; i < part_names.length(); ++i){
			String part_name = part_names.get(i);
			parts.Insert(part_name);
		}

		return parts;
	}
	//----------------------------------- get_Parts : END ---------------------------------------
	
	
	//----------------------------------- get_XML_Type : START ---------------------------------------
	private String get_XML_Type(String part_name, java.util.List<?> contents){//Returns the name of the XML type of a part.
		Object part_obj = get_object("part", part_name, contents);
		String XML_Type = get_type(part_obj);
		return XML_Type;
	}
	//----------------------------------- get_XML_Type : END ---------------------------------------


	//----------------------------------- Commonly used operations : START ---------------------------
	private String Clear_a_Token(String Token){
		int index = Token.indexOf(":");
		if(index > 0) Token = Token.substring(index + 1, Token.length());
		return Token;
	}


	//Finds the 'type' of an element.
	//e.g.<s:element minOccurs="0" maxOccurs="1" name="MerchantID" type="s:string" />
	private String get_type(Object obj){
		Element elt = (Element)obj;
		java.util.List<?> attribs = elt.getAttributes();
		for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
			Attribute attrib = (Attribute)at.next();
			if(attrib.getName().equals("type") || attrib.getName().equals("element")) return Clear_a_Token(attrib.getValue());
		}
			
		return null;
	}


	//Finds the 'name' of an element.
	//e.g.<s:element minOccurs="0" maxOccurs="1" name="MerchantID" type="s:string" />
	private String get_name(Object obj){
		Element elt = (Element)obj;
		java.util.List<?> attribs = elt.getAttributes();
		for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
			Attribute attrib = (Attribute)at.next();
			if(attrib.getName().equals("name")) return attrib.getValue();
		}
			
		return null;
	}


	//e.g., if tag = 'schema' and name = null, it finds the following tag: <xs:schema xmlns:tns="http://queue.amazonaws.com/doc/2009-02-01/".
	private java.util.List<?> get_contents(String tag, String name, java.util.List<?> contents){//This function finds the contents with a specific name.
		java.util.List<?> sub_contents = null;

		for (java.util.Iterator<?> it = contents.iterator(); it.hasNext();){
			Object obj = it.next();

			if (obj instanceof Element){
				Element elt = (Element)obj;

				if(elt.getName().equals(tag)){
					if(name == null) sub_contents = elt.getContent();
					if(name != null){
						String tag_name = get_name(obj);
						if(tag_name != null && tag_name.equals(name)) sub_contents = elt.getContent();
					}
				}

				java.util.List<?> tmp_contents = get_contents(tag, name, elt.getContent());
				if(tmp_contents != null ) sub_contents = tmp_contents;
			}
		}

		return sub_contents;
	}


	private Object get_object(String tag, String name, java.util.List<?> contents){//This function finds the object with a specific name.
		Object final_obj = null;

		for (java.util.Iterator<?> it = contents.iterator(); it.hasNext();){
			Object obj = it.next();

			if (obj instanceof Element){
				Element elt = (Element)obj;

				if(elt.getName().equals(tag)){
					if(name == null) final_obj = obj;
					if(name != null){
						String tag_name = get_name(obj);
						if(tag_name != null && tag_name.equals(name)) final_obj = obj;
					}
				}

				Object tmp_obj = get_object(tag, name, elt.getContent());
				if(tmp_obj != null ) final_obj = tmp_obj;
			}
		}

		return final_obj;
	}


	private List<String> get_names(String sub_tag, String attribute, java.util.List<?> contents){//Returns a list of string of the Objects' names of the first level.
		List<String> s = new List<String>();

		for (java.util.Iterator<?> it = contents.iterator(); it.hasNext();){
			Object obj = it.next();

			if (obj instanceof Element){
				Element elt = (Element)obj;
				java.util.List<?> attribs = elt.getAttributes();

				for (java.util.Iterator<?> at = attribs.iterator(); at.hasNext();){
					Attribute attrib = (Attribute)at.next();

					if(elt.getName().equals(sub_tag) && attrib.getName().equals(attribute)) s.Insert(Clear_a_Token(attrib.getValue()));
				}
			}
		}

		return s;
	}	
	//----------------------------------- Commonly used operations : END -----------------------------
}

