package Services_Registry_Processor;

import java.io.File;
import Services_Registry.Registry;
import Services_Registry.Service_Provider;
import Text_File.WSDLFile;

import java.util.*;

public class Registry_Processor {

	//Variables.
	File[] Files;
	int Number_Files;
	int tmp_Number_Files;


	//Operations.
	public Registry Scan(String Registry_Path){
		Registry R = new Registry();

		Number_Files = 0;
		tmp_Number_Files = 0;
		File Directory = new File(Registry_Path);
		Registry_Size(Directory);

		System.out.println("Registry_Processor - Scan : Number of Services in Registry = " + Number_Files);
		if(Number_Files > 0){
			Files = new File[Number_Files];
			Registry_Reader(Directory);

			for(int i = 0; i < Files.length; ++i){
				System.out.println("Scan: parsing the document (" + i + ") = " + Files[i].getName() + "...");

				List<?> contents = null;
				try{contents = WSDLFile.get_Contents(Files[i]);}
				catch(Exception ex){
					ex.printStackTrace();
					System.out.println("Scan: ERROR Syntax of the document (" + i + ") = " + Files[i].getName());
					System.exit(0);
				}

				Service_Parser SP = new Service_Parser();
				Service_Provider provider = null;
				if(contents != null) provider = SP.Parse(Files[i].getName(), contents);
				if(provider == null) System.out.println("Scan : ERROR Syntax of the document (" + i + ") = " + Files[i].getName());
				else R.Insert(provider);
			}
		}

		return R;
	}


	static int spc_count=-1;
	private void Registry_Size(File Directory){
		spc_count++;
		String spcs = "";
		for (int i = 0; i < spc_count; i++) spcs += " ";

		if(Directory.isFile()){
			String name = Directory.getName();
			String Extension = get_File_Extension(name);
			//System.out.println(spcs + "[FILE] " + Directory.getName() + " - Extension = " + Extension);
			if(Is_wsdl_File(Extension)) ++Number_Files;
		}
		else if(Directory.isDirectory()){
			File[] listOfFiles = Directory.listFiles();
			if(listOfFiles != null) for(int i = 0; i < listOfFiles.length; i++) Registry_Size(listOfFiles[i]);
		}

		spc_count--;
	}


	private void Registry_Reader(File Directory){
		spc_count++;
		String spcs = "";
		for (int i = 0; i < spc_count; i++) spcs += " ";

		if(Directory.isFile()){
			//System.out.println(spcs + "[FILE] " + Directory.getName());
			String name = Directory.getName();
			String Extension = get_File_Extension(name);
			if(Is_wsdl_File(Extension)){
				Files[tmp_Number_Files] = Directory;
				++tmp_Number_Files;
			}
		}
		else if(Directory.isDirectory()){
			//System.out.println(spcs + "[DIR] " + Directory.getName());
			File[] listOfFiles = Directory.listFiles();
			if(listOfFiles != null) for(int i = 0; i < listOfFiles.length; i++) Registry_Reader(listOfFiles[i]);
		}

		spc_count--;
	}


	private String get_File_Extension(String name){
		String Extension = null;
		int dotPos = name.lastIndexOf(".");
		if(dotPos > 0) Extension = name.substring(dotPos);
		return Extension;
	}


	private boolean Is_wsdl_File(String Extension){
		boolean wsdl = false;
		if(Extension != null && (Extension.equals(".xml") || Extension.equals(".wsdl"))) wsdl = true;
		return wsdl;
	}
}
