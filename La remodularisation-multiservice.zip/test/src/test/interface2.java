package test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class interface2 extends JFrame {
	JButton bChange ;
	JLabel lb2;
	public interface2(String title) {
		super( title );                     // invoke the JFrame constructor
	    setLayout( new FlowLayout() );      // set the layout manager
	   this.setSize(500, 500);
	    bChange = new JButton("interface2");
	    
	    
	    lb2=new JLabel("new label");// construct a JButton
	   add( bChange ); 
	   
	   bChange.addActionListener(new ActionListener()
	    {
	      public void actionPerformed(ActionEvent e)
	      {
	        // display/center the jdialog when the button is pressed
	    	  interface3 frame = new interface3("hello interface 3");
	    	  frame.setVisible(true);
	    	  
	    	
	    	  // construct a MyFrame object
	    	  
	      }
	    });
	   add(lb2);
	   // add the button to the JFrame
	    setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );   
	    this.setVisible(true);
	    
	    
	}
	    
	    
	    
	    
	}

