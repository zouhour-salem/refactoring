package test;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;



public class interface1 extends JFrame {
	JButton bChange ;
	JLabel lb1;
	public interface1(String title) {
		super( title );                     // invoke the JFrame constructor
	    setLayout( new FlowLayout() );      // set the layout manager
	    this.setSize(500, 500);
	    bChange = new JButton("interface1");
	    lb1=new JLabel("to interface 2");// construct a JButton
	    add( bChange ); 
	    add(lb1);// add the button to the JFrame
	    bChange.addActionListener(new ActionListener()
	    {
	      public void actionPerformed(ActionEvent e)
	      {
	        // display/center the jdialog when the button is pressed
	    	  interface2 frame = new interface2("Hello interface 2");
	    	  frame.lb2.setText(lb1.getText());
	    	  // construct a MyFrame object
	    	  frame.setVisible( true );
	      }
	    });
	     		 			//System.out.println("-------liste des op�rations-----"+liste2.get(l));
 		 		}
	
}
 		 		
 		 		
 		 		
 		
	