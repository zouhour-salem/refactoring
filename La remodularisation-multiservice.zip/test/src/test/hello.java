package test;

import java.util.ArrayList;
import java.util.List;

public class hello {
	public static void  main (String []args) {
		List<String>liste=new ArrayList<String>();            
		String ch="ThisIsMyCode";
		for (String w : ch.split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])")) {         
              String ww=w.toLowerCase();                     
                             
              liste.add(ww);                                                     
                             }                                                                                      
		for(int i =0 ; i<liste.size();i++){                                      
			System.out.println("le mot num�ro "  +   i   +  "  est  "+  liste.get(i)) ;                 
			}
		
		
	}

}

























