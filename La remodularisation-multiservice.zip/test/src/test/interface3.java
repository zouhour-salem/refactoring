package test;

import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class interface3  extends JFrame{

	JButton bChange ;
	JLabel lb2;
	public interface3(String title)  {
		super( title);                     // invoke the JFrame constructor
	    setLayout( new FlowLayout() );      // set the layout manager
	   this.setSize(500, 500);
	    bChange = new JButton("interface3");
	    
	    
	    lb2=new JLabel("new label");// construct a JButton
	   add( bChange );
	   add( lb2 );
		
	}

	
	

}
