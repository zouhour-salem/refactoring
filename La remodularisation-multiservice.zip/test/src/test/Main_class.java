package test;

public class Main_class {
	public static void main ( String[] args )
	  {
		new interface1("hello interface1").setVisible(true);
		//new interface2("hello interface2").setVisible(true);
		
	  }
}
