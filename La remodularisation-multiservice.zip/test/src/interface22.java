import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import org.annolab.tt4j.Model;
import org.annolab.tt4j.TokenHandler;
import org.annolab.tt4j.TreeTaggerException;
import org.annolab.tt4j.TreeTaggerWrapper;












import Services_Registry.Service;

import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;



















import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;

import org.annolab.tt4j.Model;
import org.annolab.tt4j.TokenHandler;
import org.annolab.tt4j.TreeTaggerException;
import org.annolab.tt4j.TreeTaggerWrapper;

import semantics.Compare;
import Services_Registry.Operation;
import Services_Registry.Registry;
import Services_Registry.Service;
import Services_Registry.Service_Provider;
import Services_Registry.portType;
import Services_Registry_Processor.Registry_Processor;
import Data_Structures.*;

import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

































import semantics.Compare;
import Services_Registry.Registry;
import Services_Registry.Service;
import Services_Registry.Service_Provider;
import Services_Registry.portType;
import Services_Registry_Processor.Registry_Processor;
import Data_Structures.*;
public class interface22 extends JFrame {

	JButton bChange ;
	JLabel lblNewLabel_1 ;
	 final JTable  table_4 ;
    
	 double[][] matrix ; 
	 
	  final String Registry_name = new String("Service Registry");
		 final Registry_Processor RP = new Registry_Processor();

		//static String usage = new String("Abstraction_Recovery");
		 String usage = new String("Interface_Restructuring");
	     String provider_folder;
		 String operations_folder;
		  Service_Provider provider;
		 String operations_structure;
		 String operations_relationships;
		 double  distance;
	public interface22(final double [][] tablecom,final double [][] tableseq,final double [][] tablesem , final List<Operation> ListeTotale, final String[][] totale) {
		                    // invoke the JFrame constructor
	    setLayout( new FlowLayout() );      // set the layout manager
	    this.setBounds(700, 700, 889, 520);
	    bChange = new JButton("interface2"); // construct a JButton
	    add( bChange );                     // add the button to the JFrame
	    setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	    
	    
	   
	    
	    final int somme=0;
	    final JFrame frame= new JFrame();
	    final JLabel comlbl = new JLabel("0.1");
	    comlbl.setVisible(false);
	    comlbl.setBounds(388, 89, 46, 14);
	    add(comlbl);
	    
	     final JLabel seqlbl = new JLabel("0.1");
	    seqlbl.setBounds(388, 284, 46, 14);
	    seqlbl.setVisible(false);
	   add(seqlbl);
	    
	    final JLabel semlbl = new JLabel("0.1");
	    semlbl.setBounds(388, 440, 46, 14);
	    semlbl.setVisible(false);
	    add(semlbl);
	    
this.getContentPane().setBackground(Color.PINK);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.getContentPane().setLayout(null);
		 final String select = null;
	    
	   final JTable table_1 = new JTable();
	    table_1.setBounds(184, 59, 200, 167);
	   
	    // frame.getContentPane().add(table_1);
	    add(table_1);
	    
	    final JTable  table_2 = new JTable();
	    table_2.setBounds(184, 251, 200, 167);
	   
	    // frame.getContentPane().add(table_2);
	    add(table_2);
	    
	    final JTable  table_3 = new JTable();
	    table_3.setBounds(184, 440, 200, 167);
	 
	    // frame.getContentPane().add(table_3);
	    add(table_3);
	    
	      table_4 = new JTable();
	      table_4.setName("table_4");
	    table_4.setBounds(770, 251, 200, 167);
	    //frame.getContentPane().add(table_4);
	    add(table_4);
	    
	    JLabel lbl = new JLabel("Method_by_method_calculates");
	    lbl.setFont(new Font("Times New Roman", Font.BOLD, 15));
	    lbl.setBounds(378, 11, 278, 14);
	    // frame.getContentPane().add(lbl);
	    add(lbl);
	    
	    JLabel lblNewLabel = new JLabel("select thresold");
	    lblNewLabel.setBounds(402, 141, 85, 14);
	    //frame.getContentPane().add(lblNewLabel);
	     add(lblNewLabel);
	    
	    JLabel label = new JLabel("select thresold");
	    label.setBounds(402, 304, 85, 14);
	   // frame.getContentPane().add(label);
	    add(label);
	    
	    JLabel label_1 = new JLabel("select thresold");
	    label_1.setBounds(402, 472, 85, 14);
	    //frame.getContentPane().add(label_1);
	    add(label_1);
	    
	    
	    
	    
	    lblNewLabel_1 = new JLabel("fromInterface1");
	    lblNewLabel_1.setVisible(false);
	    
	    lblNewLabel_1.setBounds(44, 35, 238, 14);
	    add(lblNewLabel_1);
	    
	    
	    JButton btnNewButton_1 = new JButton("<html>method__by_method <br/>matrix </html>");
	    btnNewButton_1.setBounds(589, 284, 158, 48);
	    add(btnNewButton_1);
	    
	    
	    
	    JButton btnCommunicationnalcohesion = new JButton("<html>Comunicationnal_Similarity<br />     Matrix </html> ");
	    btnCommunicationnalcohesion.setBounds(0, 132, 174, 46);
	    add(btnCommunicationnalcohesion);
	    //JButton button = new JButton("Sequentiel-Cohesion");
	   
	    JButton btnSequentielsimilarity = new JButton("<html>Sequentiel_Similarity<br />   Matrix</html> ");
	    
	    btnSequentielsimilarity.setBounds(0, 284, 174, 46);
	    add(btnSequentielsimilarity);
	  
	    
	    JButton btnSemanticsimilarity = new JButton("<html>Semantic_Similarity<br />       Matrix</html>");
	    
	    
	    btnSemanticsimilarity.setBounds(0, 456, 174, 46);
	   add(btnSemanticsimilarity);
	   
	
	
	    
	    
	    		
	    		
	    		
	    		
	    JButton btnNewButton_2 = new JButton("Next");
	    btnNewButton_2.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		
	    		 interface33 frame=new interface33(table_4,ListeTotale,totale,tablesem);
	    		 frame.frominterface22.setText(lblNewLabel_1.getText());
	    		 frame.setVisible(true);

	    	} });
	    btnNewButton_2.setBounds(861, 472, 154, 46);
	   add(btnNewButton_2);		

	   
	   
	   final String[]Message={ "0.1", "0.2","0.3" ,"0.4","0.5","0.6","0.7","0.8","0.9","0.33","0.25", "0.27", "0.29", "0.28"}; 
	    final JComboBox comBox = new JComboBox(Message);
	    comBox.setBounds(511, 138, 53, 20);
	   add(comBox);
	    
	    final JComboBox seqBox = new JComboBox(Message);
	    seqBox.setBounds(511, 301, 53, 20);
	    add(seqBox);
		
	    final JComboBox semBox = new JComboBox(Message);
	    semBox.setBounds(511, 469, 53, 20);
	    add(semBox);
	    
	    
	    
	    	String s1= seqlbl.getText();
	    	String s2=semlbl.getText();
	  
	
	   
	btnCommunicationnalcohesion.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    	
		        DefaultTableModel dmcom = new DefaultTableModel(0,0);
		 
		      Vector<Object> data1 = new Vector<Object>();
		      
		   
		    	for(int i=0; i<tablecom.length ;i++){
		    	data1.add(i);
		    	}
		    	
		    	dmcom.setColumnIdentifiers(data1);    	
		        	
		    	for(int i=0; i<tablecom.length ;i++){
		    		
		    		 Vector<Object> data = new Vector<Object>(); 
		    		for(int j=0; j<tablecom.length;j++){
		    			data.add(tablecom[i][j]);
		    			
		    			    	        
				 }
		    		
		             dmcom.addRow(data);
		        	
			}
		    	
		    table_1.setModel(dmcom);
		    JScrollPane scrollPane = new JScrollPane(table_1);
		    table_1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		    	
    		scrollPane.setBounds(184, 59, 200, 167);
    		add(scrollPane);
    		
				}

	    
			});

	
			
	    		
	 btnSequentielsimilarity.addActionListener(new ActionListener() {
					
					
					public void actionPerformed(ActionEvent arg0) {
						
			    		
			    	    
			    		
			    		 DefaultTableModel dmseq= new DefaultTableModel(0,0);
					      
					      Vector<Object> data1 = new Vector<Object>();
					    
					    	for(int i=0; i<tableseq.length ;i++){
					    	data1.add(i);
					    	}
					    	
					    	dmseq.setColumnIdentifiers(data1);
					    	
					    	for(int i=0; i<tableseq.length ;i++){
					    		
					    		 Vector<Object> data = new Vector<Object>(); 
					    		for(int j=0; j<tableseq.length;j++){
					    			data.add(tableseq[i][j]);
					    	
							 }
					    		
					             dmseq.addRow(data);
					
						}
					    	
					
					    table_2.setModel(dmseq);
					    	JScrollPane scrollPane = new JScrollPane(table_2);
					    	   table_2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
					    	
			    		    scrollPane.setBounds(184, 251, 200, 167);
			    	
			    		    add(scrollPane);
						
						}
					
				});	
	    	

	    
btnSemanticsimilarity.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    	
	 	
					
		    		
		    		
		    		 DefaultTableModel dmsem= new DefaultTableModel(0,0);
				    
				      Vector<Object> data1 = new Vector<Object>();
				      
			
				    	for(int i=0; i<tablesem.length ;i++){
				    	data1.add(i);
				    	}
				    	
				    	dmsem.setColumnIdentifiers(data1);
				    	
			
				       
				    	
				        	
				    	for(int i=0; i<tablesem.length ;i++){
				    		
				    		 Vector<Object> data = new Vector<Object>(); 
				    		for(int j=0; j<tablesem.length;j++){
				    			data.add(tablesem[i][j]);
				    		
				    
						 }
				    		
				             dmsem.addRow(data);
				             
				             	
				    	
				    	
				    		
					}
				    	
				    	
				    	
				    		
	
				    table_3.setModel(dmsem);
				    	JScrollPane scrollPane = new JScrollPane(table_3);
				    	   table_3.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
				    
		    		    scrollPane.setBounds(184, 440, 200, 167);
		    	
		    		    add(scrollPane);
					
					}}

	    	);
	    
	  
	    
	    
	    comBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				  myBox(e);

			 		
			}

			private void myBox(ActionEvent e) {

				if (comBox.getSelectedItem() != null) {
		      
		            comlbl.setText(comBox.getSelectedItem().toString());
		       
		            
		        }
				
			}
			});

	    seqBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				  myBox(e);

			
			}

			private void myBox(ActionEvent e) {

				if (seqBox.getSelectedItem() != null) {
		  
		            seqlbl.setText(seqBox.getSelectedItem().toString());
		  
		        }
				
			}}); 
	    
	    
	 
	    
	    

	    
	   semBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				  myBox(e);

			  
			}

			private void myBox(ActionEvent e) {
		
				if ( semBox.getSelectedItem() != null) {
		        
				    semlbl.setText( semBox.getSelectedItem().toString());
				   
		            
		        }
				
			}}); 
	    
	    
	    
	   btnNewButton_1.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	  
		 String k=comlbl.getText(); 
		 double k1= Double.parseDouble(k);
		 String kk=seqlbl.getText();
		 double kk1= Double.parseDouble(kk);
		 String kkk=semlbl.getText();
		 double kkk1= Double.parseDouble(kkk);
		 double sommek=k1+kk1+kkk1;
		 
		 
		 DefaultTableModel dmfin= new DefaultTableModel() ;
			 
			  int rowCount1 = table_1.getRowCount();
			  int rowCount2 = table_2.getRowCount();
			  int rowCount3 = table_3.getRowCount();
			  
			  int Count1 = table_1.getColumnCount();
			  int Count2 = table_2.getColumnCount();
			  int Count3 = table_3.getColumnCount();
			  
			  
			  Vector<Object> data1 = new Vector<Object>();
			 
			  
			  for(int i=0; i<Count1;i++){
				  data1.add(i);
		    	}
		    	
		    	dmfin.setColumnIdentifiers(data1);
				  
			  
			  
			
		    	//matrix = new double [Count1][Count1]; 
		    	
		    	for(int i=0; i<tablecom.length;i++){
					Vector<Object> data = new Vector<Object>(); 
					for(int j=0; j<tablecom.length; j++){
						
						
						 double lllc=tablecom[i][j];
						 
						 
						 double lllsq=tableseq[i][j];
						 
						
						 double lllsem= tablesem[i][j];
						 
						 double somme=(lllc*k1)+(lllsq*kk1)+(lllsem*kkk1);
						 double d = (double) Math.round(somme* 100) / 100;
						 
					
							  data.add(d);
						
					}
						
					
					dmfin.addRow(data);	  
					
				}
		    	
		 
			  
			 table_4.setModel(dmfin);
			 JScrollPane scrollPane = new JScrollPane(table_4);
			 table_4.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		    	//scrollPane.setMaximumSize(new Dimension(400,150));
  		    scrollPane .setBounds(770, 251, 200, 167);
  		   add(scrollPane);
	
		 }
	    	
	   });
	   

	}
	}


