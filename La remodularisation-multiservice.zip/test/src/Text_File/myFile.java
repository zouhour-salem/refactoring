package Text_File;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;


public class myFile {
	
	//Constructor
	public myFile(String cFileName){
		FileName = cFileName;
	}


	//Variables.
	String FileName;


	//Operations.
    public String READ_file(){
    	String contents = "", strLine = null;
        try{
        	FileInputStream fstream = new FileInputStream(FileName);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            while ((strLine = br.readLine()) != null){
            	if(contents == null) contents = strLine;
                else contents = contents + "\n" + strLine;
            }
            in.close();
        }catch (Exception e){System.err.println("Error: " + e.getMessage());}
        return contents;
    }


    public String Write(String text){
    	Writer output = null;
        try {
        	output = new BufferedWriter( new FileWriter(FileName) );
            output.write(text);
        }
        catch (IOException ex) {ex.printStackTrace();}
        finally {
        	try{if (output != null) output.close();}
            catch (IOException ex) {ex.printStackTrace();}
        }
        return null;
    }


    public String Append(String text){
    	Writer output = null;
        try {
        	String pre_contents = READ_file();
        	output = new BufferedWriter(new FileWriter(FileName));
            output.write(pre_contents + "\n" + text);
        }
        catch (IOException ex) {ex.printStackTrace();}
        finally {
        	try{if (output != null) output.close();}
            catch (IOException ex) {ex.printStackTrace();}
        }
        
        return null;
    }
    
    
    public boolean CHECK_the_existence_OF_FILE(){
		boolean RETURN_value = true;
        @SuppressWarnings("unused")
		BufferedReader input = null;
        try{
        	input = new BufferedReader( new FileReader( FileName ) );
        }catch (FileNotFoundException ex){RETURN_value = false;}
        return RETURN_value;
	}


	public boolean CHECK_the_existence_into_FILE(String s){
		String contents = this.READ_file();
        if(contents.indexOf(s) > 0 ) return true;
        else return false;
    }


	public String FIND_prev_contents(String contents, String s){
    	if(contents.indexOf(s) > 0 ) return contents.substring(0, contents.indexOf(s));
        else return null;
    }

   
    public String FIND_next_contents(String contents, String s){
    	if(contents.indexOf(s) > 0 ) return contents.substring(contents.indexOf(s) + 1, contents.length());
        else return null;
    }
}