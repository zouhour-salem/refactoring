package Text_File;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;



public class WSDLFile{
	
	//Constructor.
	public WSDLFile(String cFileName){
		FileName = cFileName;
		Contents = get_Template_Contents();
		New_Part_obj = New_Part_Obj(Contents);
		New_Msg_Obj = New_Msg_Obj(Contents);
		New_Operation_Obj = New_Operation_Obj(Contents);
		New_portType_Obj = New_portType_Obj(Contents);
	}

	//Variables.
	String FileName;
	File Abstractions_Folder = new File("Service Abstractions");
	List<?> Contents;
	Object New_Part_obj;
	Object New_Msg_Obj;
	Object New_Operation_Obj;
	Object New_portType_Obj;


	//Operations.
	public Object get_New_Part_Obj(){return New_Part_obj;}
	public Object get_New_Msg_Obj(){return New_Msg_Obj;}
	public Object get_New_Operation_Obj(){return New_Operation_Obj;}
	public Object get_New_portType_Obj(){return New_portType_Obj;}



	public static List<?> get_Contents(File fp){
		boolean error = false;
		SAXBuilder builder = new SAXBuilder();
		Document doc = null;
		try {doc = builder.build(fp);
		}catch (JDOMException e){error = true;
		}catch (IOException e){error = true;}
		
		if(error == false) return doc.getContent();
		else return null;
	}


	List<?> get_Template_Contents(){
		List<?> Contents = null;

		File[] Files = Abstractions_Folder.listFiles();
		for(int i = 0; i < Files.length; ++i){
			if(Files[i].getName().equals(FileName)) Contents = get_Contents(Files[i]);
		}

		return Contents;
	}


	public Object New_Part_Obj(List<?> Contents){
		Object final_obj = null;
		
		if(Contents != null){
			for (Iterator<?> it = Contents.iterator(); it.hasNext();){
				Object obj = it.next();
			
				if (obj instanceof Element){
					Element elt = (Element)obj;
					List<?> attribs = elt.getAttributes();
		
					for (Iterator<?> at = attribs.iterator(); at.hasNext();){
						Attribute attrib = (Attribute)at.next();
	
						if(elt.getName().equals("part") && attrib.getName().equals("name")){
							//System.out.println("***** name = " + attrib.getValue());
							final_obj = obj;
						}
						
						if(elt.getName().equals("part") && attrib.getName().equals("type")){
							//System.out.println("***** type = " + attrib.getValue());
						}
					}

					Object new_Obj = New_Part_Obj(elt.getContent());
					if(new_Obj != null ) final_obj = new_Obj;
				}
			}
		}

		return final_obj;
	}


	public Object Update_Part_Obj(Object obj, String name, String type){
		Element elt = (Element)obj;
		List<?> attribs = elt.getAttributes();
		for (Iterator<?> at = attribs.iterator(); at.hasNext();){
			Attribute attrib = (Attribute)at.next();

			if(attrib.getName().equals("name")) attrib.setValue(name);
			if(attrib.getName().equals("type")) attrib.setValue(type);
		}

		return obj;
	}


	public Object New_Msg_Obj(List<?> Contents){
		Object final_obj = null;
		
		if(Contents != null){
			for (Iterator<?> it = Contents.iterator(); it.hasNext();){
				Object obj = it.next();
			
				if (obj instanceof Element){
					Element elt = (Element)obj;
					List<?> attribs = elt.getAttributes();
		
					for (Iterator<?> at = attribs.iterator(); at.hasNext();){
						Attribute attrib = (Attribute)at.next();
	
						if(elt.getName().equals("message") && attrib.getName().equals("name")){
							//System.out.println("***** name = " + attrib.getValue());
							final_obj = obj;
						}
					}

					Object new_Obj = New_Msg_Obj(elt.getContent());
					if(new_Obj != null ) final_obj = new_Obj;
				}
			}
		}

		return final_obj;
	}


	public Object Update_Msg_Obj(Object obj, String name){
		Element elt = (Element)obj;
		List<?> attribs = elt.getAttributes();
		for (Iterator<?> at = attribs.iterator(); at.hasNext();){
			Attribute attrib = (Attribute)at.next();

			if(attrib.getName().equals("name")) attrib.setValue(name);
		}

		return obj;
	}


	public Object New_Operation_Obj(List<?> Contents){
		Object final_obj = null;
		
		if(Contents != null){
			for (Iterator<?> it = Contents.iterator(); it.hasNext();){
				Object obj = it.next();
			
				if (obj instanceof Element){
					Element elt = (Element)obj;
					List<?> attribs = elt.getAttributes();
		
					for (Iterator<?> at = attribs.iterator(); at.hasNext();){
						Attribute attrib = (Attribute)at.next();
	
						if(elt.getName().equals("operation") && attrib.getName().equals("name")){
							//System.out.println("Operation name = " + attrib.getValue());
							final_obj = obj;
						}
					}

					Object new_Obj = New_Operation_Obj(elt.getContent());
					if(new_Obj != null ) final_obj = new_Obj;
				}
			}
		}

		return final_obj;
	}


	public Object Update_Operation_Obj(Object obj, String name){
		Element elt = (Element)obj;
		List<?> attribs = elt.getAttributes();
		for (Iterator<?> at = attribs.iterator(); at.hasNext();){
			Attribute attrib = (Attribute)at.next();

			if(attrib.getName().equals("name")) attrib.setValue(name);
		}

		return obj;
	}


	public Object New_portType_Obj(List<?> Contents){
		Object final_obj = null;
		
		if(Contents != null){
			for (Iterator<?> it = Contents.iterator(); it.hasNext();){
				Object obj = it.next();
			
				if (obj instanceof Element){
					Element elt = (Element)obj;
					List<?> attribs = elt.getAttributes();
		
					for (Iterator<?> at = attribs.iterator(); at.hasNext();){
						Attribute attrib = (Attribute)at.next();
	
						if(elt.getName().equals("portType") && attrib.getName().equals("name")){
							//System.out.println("***** name = " + attrib.getValue());
							final_obj = obj;
						}
					}

					Object new_Obj = New_Operation_Obj(elt.getContent());
					if(new_Obj != null ) final_obj = new_Obj;
				}
			}
		}

		return final_obj;
	}


	public Object Update_portType_Obj(Object obj, String name){
		Element elt = (Element)obj;
		List<?> attribs = elt.getAttributes();
		for (Iterator<?> at = attribs.iterator(); at.hasNext();){
			Attribute attrib = (Attribute)at.next();

			if(attrib.getName().equals("name")) attrib.setValue(name);
		}

		return obj;
	}
}
