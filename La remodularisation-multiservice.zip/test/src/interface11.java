import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;













import java.util.HashSet;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;

import org.annolab.tt4j.Model;
import org.annolab.tt4j.TokenHandler;
import org.annolab.tt4j.TreeTaggerException;
import org.annolab.tt4j.TreeTaggerWrapper;

import edu.smu.tspell.wordnet.Synset;
import edu.smu.tspell.wordnet.SynsetType;
import edu.smu.tspell.wordnet.WordNetDatabase;
import rita.wordnet.RiWordnet;
import semantics.Compare;
import Services_Registry.Operation;
import Services_Registry.Registry;
import Services_Registry.Service;
import Services_Registry.Service_Provider;
import Services_Registry.portType;
import Services_Registry_Processor.Registry_Processor;
import Data_Structures.*;

import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

public class interface11 extends JFrame {
	 JComboBox comboBox;
	JButton bChange ;
	JList list_1 ;
	DefaultListModel listModel;
	double[][]  table_com;
	double[][]  table_seq;
	double[][]  table_sem;
	java.util.List<Operation>ListeTotale=new ArrayList<Operation>();
	List<Operation> operations = new List<Operation>();
	java.util.List<String>liste1;
	java.util.List<String>liste2;
	String totale [][];
	
	public interface11(String title) {
		super( title );
	    this.setSize(500, 500);
	    getContentPane().setLayout(null);
	    bChange = new JButton("interface1"); // construct a JButton
	    bChange.setBounds(0, 0, 0, 0);
	    getContentPane().add( bChange ); 

	    
	    final String Registry_name = new String("Service Registry");
		 final Registry_Processor RP = new Registry_Processor();


		 String usage = new String("Interface_Restructuring");
	     String provider_folder;
		 String operations_folder;
		  Service_Provider provider;
		 String operations_structure;
		 String operations_relationships;
		 double  distance;
	   
	    setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );   
	   
		this.getContentPane().setBackground(Color.PINK);
		this.setBackground(Color.ORANGE);
		this.setBounds(100, 100, 866, 499);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(null);
		
		JLabel lblSelectionnezUnService = new JLabel("Select a Service");
		lblSelectionnezUnService.setFont(new Font("Times New Roman", Font.BOLD, 13));
		lblSelectionnezUnService.setBounds(60, 57, 153, 50);
		this.getContentPane().add(lblSelectionnezUnService);
		
		
		
		final String[]Message={"http://www.xignite.com/xHistorical.asmx?WSDL","http://www.xignite.com/xregistration.asmx?wsdl","http://wsf.cdyne.com/WeatherWS/Weather.asmx?WSDL","http://eil.cs.txstate.edu/ServiceXplorer/wsdl_files/1353_Canada_FinancialFunctions.wsdl","http://www.xig//www.xigninite.com/xIndexComponents.asmx?WSDL","http://www.webservicex.net/CurrencyConvertor.asmx?WSDL" ,"http://www.webservicex.com/globalweather.asmx?wsdl", "http://www.xignite.com/xFinancials.asmx?WSDL","http://www.xignite.com/xestimates.asmx?WSDL","http:te.com/xestimates.asmx?WSDL"}; 
		 comboBox = new JComboBox(Message);
		 comboBox.setFont(new Font("Times New Roman", Font.BOLD, 14));
	
	
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				  myBox(e);

		
			
			}

			private void myBox(ActionEvent e) {
				// TODO Auto-generated method stub
				if (comboBox.getSelectedItem() != null) {
		        
		        }
				
			}});
		
		
		
		comboBox.setToolTipText("");
		comboBox.setMaximumRowCount(14);
		comboBox.setBounds(210, 57, 341, 50);
		this.getContentPane().add(comboBox);
		
		
		
		
		
		final JTextField Com = new JTextField();
		Com.setBounds(60, 264, 86, 20);
		this.getContentPane().add(Com);
		Com.setColumns(10);
		
		final JTextField Seq = new JTextField();
		Seq.setColumns(10);
		Seq.setBounds(261, 264, 86, 20);
		this.getContentPane().add(Seq);
		
		final JTextField Sem = new JTextField();
		Sem.setColumns(10);
		Sem.setBounds(465, 264, 86, 20);
		this.getContentPane().add(Sem);
		
		JButton btnSuivant = new JButton("Next");
		
		btnSuivant.setFont(new Font("Times New Roman", Font.BOLD, 14));
		
		JButton btnsequentielcohesion = new JButton("Locs");
		btnsequentielcohesion.setFont(new Font("Times New Roman", Font.BOLD, 14));
		
		
		
		
		
		
		
		
		
		
		
		btnsequentielcohesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
			
			 table_seq = new double[operations.length()][operations.length()];
			double somme_lack= 0.0; double possibilit�=0.0;
			for(int i=0;i<operations.length();i++){
				table_seq[i][i]=0.0;
				for(int j=i+1;j<operations.length() ;j++){
					double seq=Generate_Operation_Relationships_seq(i, j,operations);
					
				  
					table_seq[i][j]=seq;
					table_seq[j][i]=seq;
					
					somme_lack=somme_lack+(1-seq);
					possibilit�++;
				}
			}
			

			
			DecimalFormat df = new DecimalFormat();
		    df.setMaximumFractionDigits(2);
		  Seq.setText(String.valueOf(df.format(somme_lack/possibilit�)));	
					   
				
				
				}
		});
			
		btnsequentielcohesion.setBounds(225, 168, 158, 50);
		this.getContentPane().add(btnsequentielcohesion);
		
	
		
		
		JButton btnLacksemanticsimilarity = new JButton("Lack _Semantic-Similarity");
		btnLacksemanticsimilarity.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnLacksemanticsimilarity.setBounds(429, 168, 158, 50);
		this.getContentPane().add(btnLacksemanticsimilarity);

		btnLacksemanticsimilarity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
        System.out.println("************ le nombre des op�rations est "+operations.length());
				
				totale=new String[operations.length()][operations.length()];
				
					for(int i=0;i<operations.length();i++){
				
						java.util.List<String>ListTokenise=Tokonize(operations.get(i).get_name());
						
						
						java.util.List<String>List_sansStopWords=Stopwords(ListTokenise);
						java.util.List<String> Lemma =Lemmatisation(List_sansStopWords);
						
						for(int k=0;k<Lemma.size();k++){
							totale[i][k]=Lemma.get(k)	;
						}
						
				
						}
					
					
					
					 table_sem = new double[operations.length()][operations.length()];
						double somme_lack= 0.0; double possibilit�=0.0;
					for(int i=0;i<operations.length();i++){
						table_sem[i][i] = 1.0; 
						for(int j=i+1;j<operations.length();j++){	
							//System.out.println("**************on compare op " + operations.get(i).get_name()  + " op " +  operations.get(j).get_name() );
						
							liste1=remplir(totale,i);
							liste2=remplir(totale,j);
							java.util.List<String>listsanv1=new ArrayList<String>();
							java.util.List<String>listsanv2=new ArrayList<String>();
						
							for(int t=1;t<liste1.size();t++){
								listsanv1.add(liste1.get(t));
							
								
							}
							
							
							for(int t=1;t<liste2.size();t++){
								listsanv2.add(liste2.get(t));
								
							}
							
							
							int nbre_mot_ph1=listsanv1.size();
							int nbre_mot_ph2=listsanv2.size();
							int somme= nbre_mot_ph1+ nbre_mot_ph2;
							
							double N1=Comparrrre(listsanv1,listsanv2);
						    double N2=Comparrre_inverse(listsanv2,listsanv1);
						    
						   double  Similarit�= 0.5 *(N1+N2) / (somme-(N1+N2)/2);
						 
						   table_sem[i][j] =Similarit�;
						   table_sem[j][i] =Similarit�;
							
						   somme_lack=somme_lack+(1-Similarit�);
						   possibilit�++;
						
						}
					}
				
				//	System.out.println("la somme de lacks est " +somme_lack);
					//System.out.println("le nbre de possibilit� est " +possibilit�);
					DecimalFormat df = new DecimalFormat();
				    df.setMaximumFractionDigits(2);
				    double manque=somme_lack/possibilit�;
					System.out.println("le manque de similarit� semantique est  " +manque);
				   Sem.setText(String.valueOf(df.format(manque)));
					
					
								
							
							
							
							
						}
						}
					
					
				
				
				
			
			
			);
		
		
		
		
		
	
		btnSuivant.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			interface22 frame= new interface22(table_com,table_seq,table_sem, ListeTotale,totale);
			frame.lblNewLabel_1.setText((String) comboBox.getSelectedItem());
			frame.setVisible(true);
			

			
		
	
		
		}});
		
		Registry R = RP.Scan(Registry_name);
		List<Service_Provider> providers = R.get_providers();
		for(int p = 0; p < providers.length(); ++p){
	 provider = providers.get(p);

	List<Service> services = provider.get_Services();
	for(int s = 0; s < services.length(); ++s){
		Service service = services.get(s);
		List<portType> pTs = service.get_portTypes();
		for(int l = 0; l < pTs.length(); ++l){
			portType pT = pTs.get(l);
			operations.Insert(pT.get_Operations());
			
		}
	
	}}
		
		JButton btnCommunicationnalcohesion = new JButton("Locc");
		btnCommunicationnalcohesion.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnCommunicationnalcohesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			

				
			
			for(int i=0;i<operations.length();i++){
				ListeTotale.add(operations.get(i));	
			}
			
			
			 table_com = new double[operations.length()][operations.length()];
			
			double somme_lack= 0.0; double possibilit�=0.0;
			for(int i=0;i<operations.length();i++){
				table_com[i][i] = 1.0;  
				for(int j=i+1;j<operations.length() ;j++){
					
					double com=Generate_Operation_Relationships_com(i, j,operations); 
				
					
					table_com[i][j]=com;
					table_com[j][i]=com;
				
					
					somme_lack=somme_lack+(1-com);
					possibilit�++;
				}
			}
			
			//System.out.println("la somme de lacks est " +somme_lack);
			//System.out.println("le nbre de possibilit� est " +possibilit�);
			DecimalFormat df = new DecimalFormat();
		    df.setMaximumFractionDigits(2);
		   
		   Com.setText(String.valueOf(df.format(somme_lack/possibilit�)));
				  
						
							
				}}); 
		btnCommunicationnalcohesion.setBounds(26, 168, 158, 50);
		this.getContentPane().add(btnCommunicationnalcohesion);
		btnSuivant.setBounds(663, 319, 158, 50);
		this.getContentPane().add(btnSuivant);
		
		JButton btnOperationsList = new JButton("Operations List");
		btnOperationsList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				
				Registry R = RP.Scan(Registry_name);
				List<Service_Provider> providers = R.get_providers();
				for(int p = 0; p < providers.length(); ++p){
					Service_Provider provider = providers.get(p);
		List<Operation> operations = new List<Operation>();
			List<Service> services = provider.get_Services();
			for(int s = 0; s < services.length(); ++s){
				Service service = services.get(s);
				List<portType> pTs = service.get_portTypes();
				for(int l = 0; l < pTs.length(); ++l){
					portType pT = pTs.get(l);
					operations.Insert(pT.get_Operations());
				}
			
			}
				
			java.util.List<String>	Liste_op=new ArrayList<String>();	
			for(int i=0;i<operations.length();i++){
				Liste_op.add(operations.get(i).get_name());
				 
		    	listModel.addElement(operations.get(i).get_name()); 
			}
			
				
			}
				
				}
		});
		btnOperationsList.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnOperationsList.setBounds(625, 168, 158, 50);
		getContentPane().add(btnOperationsList);
		

		
		
		 listModel = new DefaultListModel();
		

	        list_1 = new JList(listModel);
	        list_1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		
	
		list_1.setLayoutOrientation(JList.VERTICAL);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(625, 240, 185, 50);
		getContentPane().add(scrollPane);
		scrollPane.setViewportView(list_1);
		
		JLabel lblNewLabel = new JLabel("Locc : Lack of comunicationnal cohesion");
		lblNewLabel.setFont(new Font("Times New Roman", Font.ITALIC, 13));
		lblNewLabel.setBounds(10, 338, 224, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Locs : Lack of sequentiel cohesion");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.ITALIC, 13));
		lblNewLabel_1.setBounds(10, 381, 203, 14);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("calculating lack of cohesion");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_2.setBounds(308, 11, 243, 14);
		getContentPane().add(lblNewLabel_2);
		
	
		
		
		
		
		
		
		
	}

	

	protected int Comparrre_inverse(java.util.List<String> liste22,
			java.util.List<String> liste12) {
		
		
		
		RiWordnet wordnet = new RiWordnet(null);
		int nbrtotaleMotPhrase2DansPhrase1=0;
		for(int l=0;l<liste22.size();l++){
			String ch=liste22.get(l);
			//System.out.println(" on compare " + ch + " avec la phrase1 ");
			if(wordnet.exists(ch)){
			if(Compare_mot_list(ch,liste12)){
				
				 nbrtotaleMotPhrase2DansPhrase1= nbrtotaleMotPhrase2DansPhrase1 +1;
			}
				
		}
			else{
				if(verifier(ch,liste12)){
					 nbrtotaleMotPhrase2DansPhrase1= nbrtotaleMotPhrase2DansPhrase1 + 1;
				}
			}
			
		}
	//System.out.println("le nbre de mots partag�s de ph2 dans ph1 " +nbrtotaleMotPhrase2DansPhrase1);
		return nbrtotaleMotPhrase2DansPhrase1;
		
	
	}







	protected double   Comparrrre(java.util.List<String> liste12, java.util.List<String> liste22li) {
		

		RiWordnet wordnet = new RiWordnet(null);
		double nbrtotaleMotPhrase1DansPhrase2=0.0;
		for(int l=0;l<liste12.size();l++){
			String ch=liste12.get(l);
			//System.out.println(" on compare " + ch + " avec la phrase2 ");
			if(wordnet.exists(ch)){
			if(Compare_mot_list(ch,liste22li)){
				
				 nbrtotaleMotPhrase1DansPhrase2= nbrtotaleMotPhrase1DansPhrase2  + 1.0;
			}
				
		}
			else{
				if(verifier(ch,liste22li)){
					 nbrtotaleMotPhrase1DansPhrase2= nbrtotaleMotPhrase1DansPhrase2  + 1.0;
				}
				
				
				
			}
			
		}
		//System.out.println("le nbre de mots partag�s de ph1 dans ph2 " +nbrtotaleMotPhrase1DansPhrase2);
		
		return nbrtotaleMotPhrase1DansPhrase2;
		
	}



	protected boolean verifier(String ch, java.util.List<String> liste22) {
		 boolean test=false;
		if(liste22.contains(ch)){
			 test=true;
				}
		
		return test;
		
	}



	private boolean Compare_mot_list(String ch, java.util.List<String> liste22) {
		RiWordnet wordnet = new RiWordnet(null);
		boolean test=false; 
		
	
		for(int i=0;i<liste22.size();i++){
			if(wordnet.exists(liste22.get(i))){
				if(is_synonyme(ch,liste22.get(i))){
					//System.out.println("on compare " + ch + "avec" +liste22.get(i));
					test=true;
					//System.out.println("le mot " + ch + " a un synonyme avec " + liste22);
				}
				
				/*else{
					System.out.println("le mot " + ch + " n'a pas un synonyme avec " + liste22);
					test=false;
				}*/
			
			}
			}
		return test;
			
	}



	


	
		
			


	

	

	protected boolean is_synonyme(String string, String string2) {
		boolean test=false;
		RiWordnet wordnet = new RiWordnet(null);
		
		String pos = wordnet.getBestPos(string2);
		String[] synonyms = wordnet.getAllSynonyms(string2,pos,40);
		java.util.List<String>Liste_synonyme=new ArrayList<>();
		Liste_synonyme.add(string2);
		if(synonyms!=null){
		for(int i=0;i<synonyms.length;i++){
			Liste_synonyme.add(synonyms[i]);
		}
		}
		
		if(Liste_synonyme.contains(string)){
			test=true;
		}
		
		return test;
	}



	protected java.util.List<String> remplir(String[][] totale, int i) {
		java.util.List<String>liste=new ArrayList<>();
		for(int k=0;k<totale.length;k++){
			if(totale[i][k]!= null){
			liste.add(totale[i][k]);
		}}
		return liste;
	}

	

	protected double Generate_Operation_Relationships_sem(int i, int j,
			List<Operation> operations) {
				
				
				
				
				Operation operation1 = operations.get(i); 
				String operation1_name=operation1.get_name();
				Operation operation2 = operations.get(j);
				String operation2_name=operation2.get_name();
			
				java.util.List<String>ListTokenise1=Tokonize(operation1_name);
				java.util.List<String>ListTokenise2=Tokonize(operation2_name);
				
				java.util.List<String>List1_sansStopWords=Stopwords(ListTokenise1);
				java.util.List<String>List2_sansStopWords=Stopwords(ListTokenise2);
				
				return j;
		
 		 			}
 		 		
		
	private java.util.List<String> Lemmatisation(java.util.List<String> list_sansStopWords) {
	
		java.util.List<String>liste=new ArrayList<String>();
 	 final java.util.List<String>liste1=new ArrayList<String>();
 		java.util.List<String>liste2=new ArrayList<String>();
 		java.util.List<String>taille1=new ArrayList<String>();
 		taille1.add("get");
		
 		
 	 	for(int ii=0; ii<list_sansStopWords.size();ii++){
		 		
		 		
		 		
		 		
		 	   System.setProperty("treetagger.home", "C:/Program Files/TreeTagger");
			    TreeTaggerWrapper tt = new TreeTaggerWrapper<String>();
			    
			   
			   try {
			         
			    	
			      tt.setModel("C:/Program Files/TreeTagger/models/en.par");
			        
			      tt.setHandler(new TokenHandler<String>() {
			    	  
			        public void token(String token, String pos, String lemma) {
			        	
			    
			      
			        	if(pos=="NNS" && lemma.endsWith("s")){
	 				    
	 				    	  liste1.add(lemma.substring(0, lemma.length()-1));
	 				    	  
	 				      }
	 				      else{
	 						liste1.add(lemma);
	 				      }		
	 						
	 				        }
	 				    	
	 				        
	 						
	 				      }
	 				      );
		 	
		 		try {
					tt.process((new String[] {list_sansStopWords.get(ii)}));
				} catch (TreeTaggerException e) {
			
					e.printStackTrace();
				}
		 	
		 	
		 	 	
		 	 	
		 
		 
		 } catch (IOException e) {
			
			e.printStackTrace();
		}		 		 

finally {

tt.destroy();


}
}
		 		
	if(liste1.size()==1){
		taille1.add(liste1.get(0));
		return taille1;
	}
	else{
		return liste1;
	}
		 	   

	 	
	
	}
		
		
		
	

	private java.util.List<String> Stopwords(java.util.List<String> listTokenise2) {

		
		java.util.List<String>stopWords=new ArrayList<>();
		
		stopWords.add("on");
		stopWords.add("of");
		stopWords.add("update");
		stopWords.add("by");
		stopWords.add("for");
		stopWords.add("off");
		stopWords.add("in");
		stopWords.add("or");
		stopWords.add("from");
		stopWords.add("to");
		stopWords.add("my");
		stopWords.add("all");
		stopWords.add("because");
		stopWords.add("if");
		stopWords.add("after");
		stopWords.add("or");
		stopWords.add("and");
		stopWords.add("with");
		stopWords.add("its");
		stopWords.add("is");
		stopWords.add("it");
		stopWords.add("here");
		stopWords.add("his");
		stopWords.add("her");
		stopWords.add("out");
		stopWords.add("other");
		stopWords.add("much");
		stopWords.add("only");
		stopWords.add("other");
		stopWords.add("down");
		stopWords.add("ours");
		stopWords.add("our");
		stopWords.add("must");
		stopWords.add("many");
		stopWords.add("up");
		stopWords.add("upon");
		stopWords.add("us");
		stopWords.add("very");
		stopWords.add("via");
	    stopWords.add("too");
		stopWords.add("these");
		stopWords.add("this");
		stopWords.add("last");
		stopWords.add("have");
		stopWords.add("had");
		stopWords.add("has");
		stopWords.add("become");
		stopWords.add("be");
		stopWords.add("back");
		stopWords.add("at");
		stopWords.add("as");
		stopWords.add("around");
		stopWords.add("are");
		stopWords.add("any");
		stopWords.add("another");
		stopWords.add("a");
		stopWords.add("and");
		stopWords.add("amount");
		stopWords.add("always");
		stopWords.add("although");
		stopWords.add("also");
		stopWords.add("already");
		stopWords.add("along");
		stopWords.add("alone");
		stopWords.add("almost");
		stopWords.add("against");
		stopWords.add("all");
		stopWords.add("again");
		stopWords.add("afterwards");
		stopWords.add("after");
		stopWords.add("across");
		stopWords.add("above");
		stopWords.add("about");
	
			
		
		 /*private String[] stopWord =  {"a", "about", "above", "above", "across", "after", "afterwards", "again", "against", "all", "almost",
			     "alone", "along", "already", "also", "although", "always", "am", "among", "amongst", "amoungst", "amount", "an", "and",
			     "another", "any", "anyhow", "anyone", "anything", "anyway", "anywhere", "are", "around", "as", "at", "back", "be", "became",
			     "because", "become", "becomes", "becoming", "been", "before", "beforehand", "behind", "being", "below", "beside", "besides",
			     "between", "beyond", "bill", "both", "bottom", "but", "by", "call", "can", "cannot", "cant", "co", "con", "could", "couldnt",
			     "cry", "de", "describe", "detail", "do", "done", "down", "due", "during", "each", "eg", "eight", "either", "eleven", "else",
			     "elsewhere", "empty", "enough", "etc", "even", "ever", "every", "everyone", "everything", "everywhere", "except", "few",
			     "fifteen", "fify", "fill", "find", "fire", "first", "five", "for", "former", "formerly", "forty", "found", "four", "from",
			     "front", "full", "further", "get", "give", "go", "had", "has", "hasnt",
			     "have", "he", "hence", "her", "here", "hereafter", "hereby", "herein", "hereupon", "hers", "herself",
			     "him", "himself", "his", "how", "however", "hundred", "ie", "if", "in", "inc", "indeed", "interest", "into",
			     "is", "it", "its", "itself", "keep", "last", "latter", "latterly", "least", "less", "ltd", "made", "many",
			     "may", "me", "meanwhile", "might", "mill", "mine", "more", "moreover", "most", "mostly", "move", "much", "must",
			     "my", "myself", "name", "namely", "neither", "never", "nevertheless", "next", "nine", "no", "nobody", "none",
			     "noone", "nor", "not", "nothing", "now", "nowhere", "of", "off", "often", "on", "once", "one", "only", "onto",
			     "or", "other", "others", "otherwise", "our", "ours", "ourselves", "out", "over", "own", "part", "per", "perhaps",
			     "please", "put", "rather", "re", "same", "see", "seem", "seemed", "seeming", "seems", "serious", "several", "she",
			     "should", "show", "side", "since", "sincere", "six", "sixty", "so", "some", "somehow", "someone", "something",
			     "sometime", "sometimes", "somewhere", "still", "such", "system", "take", "ten", "than", "that", "the", "their",
			     "them", "themselves", "then", "thence", "there", "thereafter", "thereby", "therefore", "therein", "thereupon",
			     "these", "they", "thickv", "thin", "third", "this", "those", "though", "three", "through", "throughout", "thru",
			     "thus", "to", "together", "too", "toward", "towards", "twelve", "twenty", "two", "un", "under", "until",
			     "up", "upon", "us", "very", "via", "was", "we", "well", "were", "what", "whatever", "when", "whence", "whenever",
			     "where", "whereafter", "whereas", "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while",
			     "whither", "who", "whoever", "whole", "whom", "whose", "why", "will", "with", "within", "without", "would", "yet",
			     "you", "your", "yours", "yourself", "yourselves", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "1.", "2.", "3.", "4.", "5.", "6.", "11",
			     "7.", "8.", "9.", "12", "13", "14", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
			     "terms", "CONDITIONS", "conditions", "values", "interested.", "care", "sure", ".", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "{", "}", "[", "]", ":", ";", ",", "<", ".", ">", "/", "?", "_", "-", "+", "=",
			     "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
			     "contact", "grounds", "buyers", "tried", "said,", "plan", "value", "principle.", "forces", "sent:", "is,", "was", "like",
			     "discussion", "tmus", "diffrent.", "layout", "area.", "thanks", "thankyou", "hello", "bye", "rise", "fell", "fall", "psqft.", "http://", "km", "miles"} ;
	    
		*/
		
		
		
		
		
		
		java.util.List<String>Liste_sans_stop=new ArrayList<>();
		for(int i=0;i<listTokenise2.size();i++){
			String mot=listTokenise2.get(i);
			if(!stopWords.contains(mot)) {
				Liste_sans_stop.add(mot);
				}
			
		}
		return Liste_sans_stop;
	}

	private java.util.List<String> Tokonize(String operation1_name) {
		
		 String g=""; java.util.List<String>liste=new ArrayList<>();
	 	 	for (String w : operation1_name.split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])")) {
	 	 		
	 	     
	 	        String ww=w.toLowerCase();
	 	        
	 	       g=g+" "	+ ww;
	 	      
	 	       
	 	       liste.add(ww);	
	}
			return liste;
	}
	protected double Generate_Operation_Relationships_seq(int i, int j,
			List<Operation> operations) {
		
		Operation operation1 = operations.get(i);    
		String operation1_name=operation1.get_name();
			Operation operation2 = operations.get(j);
			String operation2_name=operation2.get_name();

			
				
			 double cohesion=0.0; 
				double seq_coef = operation1.get_sequential_coefficient(operation2);
				
				 cohesion= seq_coef;
			
			return cohesion;
	}

	protected double Generate_Operation_Relationships_com(int i, int j,
			List<Operation> operations) {
		// TODO Auto-generated method stub
		Operation operation1 = operations.get(i);    
		String operation1_name=operation1.get_name();
			Operation operation2 = operations.get(j);
			String operation2_name=operation2.get_name();
				
				double cohesion=0.0;
				double com_coef = operation1.get_communicational_coefficient(operation2);
				cohesion = com_coef;
			
			return cohesion ;
			 
	}
}


