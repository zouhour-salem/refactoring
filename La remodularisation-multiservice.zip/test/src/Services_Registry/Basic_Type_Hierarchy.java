package Services_Registry;



public class Basic_Type_Hierarchy {

	//Constructor
	public Basic_Type_Hierarchy(){
		Find_Height_of_Hierarchy();
	}
	
	//Variables.
	private String[] Basic_Types = {"anyType",            //0
									"anySimpleType",      //1
									"string",             //2
									"boolean",            //3
									"base64Binary",       //4
									"hexBinary",          //5
									"float",              //6
									"decimal",            //7
									"double",             //8
									"anyURI",             //9
									"QName",              //10
									"NOTATION",           //11
									"duration",           //12
									"dateTime",           //13
									"time",               //14
									"date",               //15
									"gYearMonth",         //16
									"gYear",              //17
									"gMonthDay",          //18
									"gDay",               //19
									"gMonth",             //20
									"normalizedString",   //21
									"token",			  //22
									"language",			  //23
									"Name",				  //24
									"NMTOKEN",			  //25
									"NCName",			  //26
									"NMTOKENS",			  //27
									"ID",				  //28
									"IDREF",			  //29
									"ENTITY",			  //30
									"IDREFS",			  //31
									"ENTITIES",			  //32
									"integer",			  //33
									"nonPositiveInteger", //34
									"long",				  //35
									"nonNegativeInteger", //36
									"negativeInteger",	  //37
									"int",				  //38
									"unsignedLong",		  //39
									"positiveInteger",	  //40
									"short",			  //41
									"unsignedInt",		  //42
									"byte",				  //43
									"unsignedShort",	  //44
									"unsignedByte"};	  //45


	private int[] Parent_Basic_Type = {	0,//anyType                 has parent = anyType. 
										0,//anySimpleType           has parent = anyType.
										1,//string					has parent = anySimpleType.
										1,//boolean					has parent = anySimpleType.
										1,//base64Binary			has parent = anySimpleType.
										1,//hexBinary				has parent = anySimpleType.
										1,//float					has parent = anySimpleType.
										1,//decimal					has parent = anySimpleType.
										1,//double					has parent = anySimpleType.
										1,//anyURI					has parent = anySimpleType.
										1,//QName					has parent = anySimpleType.
										1,//NOTATION				has parent = anySimpleType.
										1,//duration				has parent = anySimpleType.
										1,//dateTime				has parent = anySimpleType.
										1,//time					has parent = anySimpleType.
										1,//date					has parent = anySimpleType.
										1,//gYearMonth				has parent = anySimpleType.
										1,//gYear					has parent = anySimpleType.
										1,//gMonthDay				has parent = anySimpleType.
										1,//gDay					has parent = anySimpleType.
										1,//gMonth					has parent = anySimpleType.
										2,//normalizedString		has parent = string.
										21,//token					has parent = normalizedString.
										22,//language				has parent = token.
										22,//Name					has parent = token.
										22,//NMTOKEN				has parent = token.
										24,//NCNAME					has parent = Name.
										25,//NMTOKENS				has parent = NMTOKEN.
										26,//ID						has parent = NCNAME.
										26,//IDREF					has parent = NCNAME.
										26,//ENTITY					has parent = NCNAME.
										29,//IDREFS					has parent = IDREF.
										30,//ENTITIES				has parent = ENTITY.
										7,//integer					has parent = decimal.
										33,//nonPositiveInteger		has parent = integer.
										33,//long					has parent = integer.
										33,//nonNegativeInteger		has parent = integer.
										34,//negativeInteger		has parent = nonPositiveInteger.
										35,//int					has parent = long.
										36,//unsignedLong			has parent = nonNegativeInteger.
										36,//positiveInteger		has parent = nonNegativeInteger.
										38,//short					has parent = int.
										39,//unsignedInt			has parent = unsignedLong.
										41,//byte					has parent = short.
										42,//unsignedShort			has parent = unsignedInt.
										44};//unsignedByte			has parent = unsignedShort.
	private float Height;

	//Operations.
	public float get_Height(){
		return Height;
	}


	public int get_Parent_Basic_Type(int i){
		return Parent_Basic_Type[i];
	}


	public String get_Basic_Type(int i){
		return Basic_Types[i];
	}


	public boolean Contains_Basic_Type(String name){
		for(int i = 0; i < Basic_Types.length; ++i){
			int index = name.toUpperCase().indexOf(Basic_Types[i].toUpperCase());	
			if(index > 0) return true;
		}
		return false;
	}


	public boolean Is_Basic_Type(String type){
		for(int i = 0; i < Basic_Types.length; ++i) if(type != null && type.toUpperCase().equals(Basic_Types[i].toUpperCase())) return true;
		return false;
	}


	public int get_Index_of_Basic_Type(String type){
		int i = 0;
		for(i = 0; i < Basic_Types.length; ++i) if(Basic_Types[i].equals(type)) return i;
		return 0;
	}


	public String[] get_Path(String type){
		String[] path = null;
		int len = 1;
		
		int i = get_Index_of_Basic_Type(type);
		while (i != 0){
			i = Parent_Basic_Type[i];
			++len;
		}

		path = new String[len];
		int c = 0;

		path[c] = type;
		i = get_Index_of_Basic_Type(type);
		while (i != 0){
			i = Parent_Basic_Type[i];
			++c;
			path[c] = new String(Basic_Types[i]);
		}

		return path;
	}


	public boolean Belongs_To_Path(String type, String[] path){
		boolean belongs_to = false;
		for(int i = 0; i < path.length; ++i) if(path[i].equals(type)) belongs_to = true; 
		return belongs_to;
	}
	
	
	public void Find_Height_of_Hierarchy(){
		String the_most_specific_type = new String("ENTITIES");
		String[] path = get_Path(the_most_specific_type);
		Height = path.length - 1;
	}
}