package Services_Registry;

import Basic_Algorithms.ConceptualDistance;
import Data_Structures.List;


public class Operation {
	
	//Constructor.
	public Operation(String cname){
	    name = cname;
	    com_weight = -1.0;
	    seq_weight = -1.0;
	    name_weight = -1.0;
	    is_singleton = false;
	    checked_as_splinter = false;

	    FunctionalCoefficients = new List<Double>();
	    OperationNamesForFuncCoef = new List<String>();
	    HybridCoefficients = new List<Double>();
	    OperationNamesForHybridCoef = new List<String>();
	    ComCoefficients = new List<Double>();
	    OperationNamesForComCoef = new List<String>();
	    SeqCoefficients = new List<Double>();
	    OperationNamesForSeqCoef = new List<String>();
	}
	
	//Variables.
	private String name;
	private Message In_Msg;
	private Message Out_Msg;
	private boolean is_singleton;
	private boolean checked_as_splinter;

	private double com_weight;
	private double seq_weight;
	private double name_weight;
	private boolean remove_prefix;
	private boolean exclude_min_of_com_or_seq;
	private List<Double> FunctionalCoefficients;
	private List<String> OperationNamesForFuncCoef;
	private List<Double> HybridCoefficients;
	private List<String> OperationNamesForHybridCoef;
	private List<Double> ComCoefficients;
	private List<String> OperationNamesForComCoef;
	private List<Double> SeqCoefficients;
	private List<String> OperationNamesForSeqCoef;


	//Operations.
	private int SearchConceptualCoefficients(String OperationName){
		int len = OperationNamesForFuncCoef.length();
		for(int i = 0; i < len; ++i) if(OperationNamesForFuncCoef.get(i).equals(OperationName)) return i;
		return -1;
	}


	public double getConceptualCoefficient(Operation operation2, double name_weight, double com_weight, double seq_weight, boolean exclude_min_of_com_or_seq, boolean remove_prefix){
		int i = SearchConceptualCoefficients(operation2.get_name());
		if(i != -1 && this.name_weight == name_weight && this.com_weight == com_weight && this.seq_weight == seq_weight && this.exclude_min_of_com_or_seq == exclude_min_of_com_or_seq && this.remove_prefix == remove_prefix)
			return FunctionalCoefficients.get(i);

		//double names_coef = 1.0 - EditDistance.CalculateNED(name, operation2.get_name(), remove_prefix_verb);
		ConceptualDistance CD = new ConceptualDistance();
		CD.Calculate("ListAllFulfillmentByNextToken", "ListAll", true);
		double names_coef = 1.0 - CD.Calculate(name, operation2.get_name(), remove_prefix);

		double com_coef = get_communicational_coefficient(operation2);
		double seq_coef = get_sequential_coefficient(operation2);

		if(exclude_min_of_com_or_seq == true){
			if(com_coef > seq_coef){
				seq_weight = 0.0;
				com_weight = 1.0 - name_weight;
			}
			else{
				com_weight = 0.0;
				seq_weight = 1.0 - name_weight;
			}
		}

		double coef = name_weight*names_coef + com_weight*com_coef + seq_weight*seq_coef;

		if(i != -1 && (this.name_weight != name_weight || this.com_weight != com_weight || this.seq_weight != seq_weight || this.exclude_min_of_com_or_seq != exclude_min_of_com_or_seq || this.remove_prefix != remove_prefix)){
			this.name_weight = name_weight;
			this.com_weight = com_weight;
			this.seq_weight = seq_weight;
			this.exclude_min_of_com_or_seq = exclude_min_of_com_or_seq;
			this.remove_prefix = remove_prefix;

			FunctionalCoefficients.Remove(i);
			OperationNamesForFuncCoef.Remove(i);
			FunctionalCoefficients.Insert(coef);
			OperationNamesForFuncCoef.Insert(operation2.get_name());
		}

		if(i == -1){
			FunctionalCoefficients.Insert(coef);
			OperationNamesForFuncCoef.Insert(operation2.get_name());
		}

		return coef;
	}


	private int SearchHybridCoefficients(String OperationName){
		int len = OperationNamesForHybridCoef.length();
		for(int i = 0; i < len; ++i) if(OperationNamesForHybridCoef.get(i).equals(OperationName)) return i;
		return -1;
	}


	public double get_hybrid_coefficient(Operation operation2){
		int i = SearchHybridCoefficients(operation2.get_name());
		if(i != -1) return HybridCoefficients.get(i);

		double com_coef = get_communicational_coefficient(operation2);
		double seq_coef = get_sequential_coefficient(operation2);

		double coef = 0.0;
		if(com_coef > seq_coef) coef = com_coef;
		else coef = seq_coef;

		HybridCoefficients.Insert(coef);
		OperationNamesForHybridCoef.Insert(operation2.get_name());

		return coef;
	}


	private int SearchComCoefficients(String OperationName){
		int len = OperationNamesForComCoef.length();
		for(int i = 0; i < len; ++i) if(OperationNamesForComCoef.get(i).equals(OperationName)) return i;
		return -1;
	}


	public double get_communicational_coefficient(Operation operation2){
		int i = SearchComCoefficients(operation2.get_name());
		if(i != -1) return ComCoefficients.get(i);

		double sim_in_in = In_Msg.get_Similarity_Degree(operation2.get_Input_Msg());
		double sim_out_out = Out_Msg.get_Similarity_Degree(operation2.get_Output_Msg());

		double order_union_in_in = In_Msg.get_Order_of_Union(operation2.get_Input_Msg());
		double order_union_out_out = Out_Msg.get_Order_of_Union(operation2.get_Output_Msg());

		double msg_coef_in_in = get_Similarity_Coefficient(sim_in_in, order_union_in_in);
		double msg_coef_out_out = get_Similarity_Coefficient(sim_out_out, order_union_out_out);

		double com_coef = (msg_coef_in_in + msg_coef_out_out)/2;

		ComCoefficients.Insert(com_coef);
		OperationNamesForComCoef.Insert(operation2.get_name());

		return com_coef;
	}


	private int SearchSeqCoefficients(String OperationName){
		int len = OperationNamesForSeqCoef.length();
		for(int i = 0; i < len; ++i) if(OperationNamesForSeqCoef.get(i).equals(OperationName)) return i;
		return -1;
	}


	public double get_sequential_coefficient(Operation operation2){
		int i = SearchSeqCoefficients(operation2.get_name());
		if(i != -1) return SeqCoefficients.get(i);

		double sim_in_out = In_Msg.get_Similarity_Degree(operation2.get_Output_Msg());
		double sim_out_in = Out_Msg.get_Similarity_Degree(operation2.get_Input_Msg());

		double order_union_in_out = In_Msg.get_Order_of_Union(operation2.get_Output_Msg());
		double order_union_out_in = Out_Msg.get_Order_of_Union(operation2.get_Input_Msg());

		double msg_coef_in_out = get_Similarity_Coefficient(sim_in_out, order_union_in_out);
		double msg_coef_out_in = get_Similarity_Coefficient(sim_out_in, order_union_out_in);

		double seq_coef = (msg_coef_in_out + msg_coef_out_in)/2;

		SeqCoefficients.Insert(seq_coef);
		OperationNamesForSeqCoef.Insert(operation2.get_name());

		return seq_coef;
	}


	public String get_name(){
		return name;
	}


	public void Singleton(boolean cis_singleton){
		is_singleton = cis_singleton;
	}


	public boolean Is_Singleton(){
		return is_singleton;
	}


	public boolean get_checked(){
		return checked_as_splinter;
	}


	public void set_checked(boolean cchecked_as_splinter){
		checked_as_splinter = cchecked_as_splinter;
	}


	public Message get_Input_Msg(){
		return In_Msg;
	}


	public Message get_Output_Msg() {
		return Out_Msg;
	}


	public Message Insert_Input_Msg(String cIn_msg_name) {
		In_Msg = new Input_Msg(cIn_msg_name);
		return In_Msg;
	}


	public Message Insert_Output_Msg(String cOut_msg_name) {
		Out_Msg = new Output_Msg(cOut_msg_name);
		return Out_Msg;
	}


	public double get_avg_com_seq_coefficient(Operation operation2){
		double coef = 0.0;

		double com_coef = get_communicational_coefficient(operation2);
		double seq_coef = get_sequential_coefficient(operation2);
		coef = (com_coef + seq_coef)/2.0;

		return coef;
	}


	private double get_Similarity_Coefficient(double sim, double order_union){
		double msg_coef = sim/order_union;
		//System.out.println("Similarity Coefficient = " + msg_coef);

		return msg_coef;
	}


	public void Print(){
		//System.out.println(name);		
		if(In_Msg != null){
			//System.out.print("\t\t\t\tInput message : ");
			In_Msg.Print();
		}
		if(Out_Msg != null){
			//System.out.print("\t\t\t\tOutput message : ");
			Out_Msg.Print();
		}
	}
}