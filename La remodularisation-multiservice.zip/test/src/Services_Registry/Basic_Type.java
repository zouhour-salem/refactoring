package Services_Registry;

public class Basic_Type {
	
	//Constructor.
	public Basic_Type(Object x, String ctype, String cname){
		Basic_Type = x;
		type = ctype;
		name = cname;
	}


	//Variables.
	private Object Basic_Type;
	private String type;
	private String name;


	//Operations.
	public String get_Basic_Type(){return type;}
	public String get_Basic_Name(){return name;}
	public Object get_Basic_Type_Obj(){return Basic_Type;}
}