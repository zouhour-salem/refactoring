package Services_Registry;

public class Part {
	
	//Constructor.
	public Part(String cname, XML_Type cXML_type){
		name = cname;
		XML_type = cXML_type;
	}
	
	
	//Variables.
	private String name;
	private XML_Type XML_type;
	private double total_portType_importance;
	private double total_provider_importance;
	private double input_msg_portType_importance;
	private double input_msg_provider_importance;
	private double output_msg_portType_importance;
	private double output_msg_provider_importance;
	
	
	//Operations.
	public void set_importance(double cimportance, String importance_type, String scale_type) {
		if(importance_type.equals("input")){
			if(scale_type.equals("portType")) input_msg_portType_importance = cimportance;
			else input_msg_provider_importance = cimportance;
		}
		else if(importance_type.equals("output")){
			if(scale_type.equals("portType")) output_msg_portType_importance = cimportance;
			else output_msg_provider_importance = cimportance;
		}
		else{
			if(scale_type.equals("portType")) total_portType_importance = cimportance;
			else total_provider_importance = cimportance;
		}
	}


	public double get_importance(String importance_type, String scale_type) {
		if(importance_type.equals("input")){
			if(scale_type.equals("portType")) return input_msg_portType_importance;
			else return input_msg_provider_importance;
		}
		else if(importance_type.equals("output")){
			if(scale_type.equals("portType")) return output_msg_portType_importance;
			else return output_msg_provider_importance;
		}
		else{
			if(scale_type.equals("portType")) return total_portType_importance;
			else return total_provider_importance;
		}
	}


	public String get_name(){
		return name;
	}


	public XML_Type get_XML_Type(){
		return XML_type;
	}


	public void set_XML_type(XML_Type x) {
		XML_type = x;
	}


	public void Print(){
		//System.out.println(name);
		//System.out.println("\t\t\t\t\t\tXML_Type : ");
		if(XML_type != null) XML_type.Print();
	}
}