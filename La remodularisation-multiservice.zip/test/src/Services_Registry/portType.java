package Services_Registry;

import java.text.DecimalFormat;
import Data_Structures.List;

public class portType{

	//Constructor.
	public portType(String cname, boolean cis_abstraction){
	    name = cname;
	    print = false;
	    is_singleton = false;
	    is_abstraction = cis_abstraction;
	    operations = new List<Operation>();
	    twoDForm = new DecimalFormat("#.##");
	}


	//Variables.
	private int id;						//Is is used by the Abstraction Recovery algorithm.
	private String name;
	private boolean print;
	DecimalFormat twoDForm;
	private boolean is_singleton;
	private boolean is_abstraction;
	private int Coupling_Reduction;
	private List<Operation> operations;


	//Operations.
	public void Singleton(boolean cis_singleton){
		is_singleton = cis_singleton;
	}


	public boolean Is_Singleton(){
		return is_singleton;
	}


	public double get_LoC(String cohesion_type, double name_weight, double com_weight, double seq_weight, boolean exclude_min_of_com_or_seq, boolean remove_prefix_verb){
		double LoC = 0.0;

		if(print) System.out.println("Calculating cohesion for the portType = " + name);

		if(operations.length() == 0 || operations.length() == 1) LoC = -1.0;
		else{
			int counter = 0;
			double sum = 0.0;
			int C = operations.length() * (operations.length() - 1)/2;

			for(int op1 = 0; op1 < operations.length(); ++op1){
				for(int op2 = 0; op2 < operations.length(); ++op2){
					if(op1 < op2){
						counter++;
						Operation operation1 = operations.get(op1);
						Operation operation2 = operations.get(op2);

						double coef = 0.0;

						if(cohesion_type.equals("sequential")) coef = operation1.get_sequential_coefficient(operation2);
						else if(cohesion_type.equals("avg_com_seq")) coef = operation1.get_avg_com_seq_coefficient(operation2);
						else if(cohesion_type.equals("communicational")) coef = operation1.get_communicational_coefficient(operation2);
						else if(cohesion_type.equals("functional")) coef = operation1.getConceptualCoefficient(operation2, name_weight, com_weight, seq_weight, exclude_min_of_com_or_seq, remove_prefix_verb);
						else if(cohesion_type.equals("hybrid")) coef = operation1.get_hybrid_coefficient(operation2);

						sum += coef;
					}
				}
			}

			LoC = 1.0 - (double)sum / (double)C;
		}

		return LoC;
	}


	public double get_LoC_by_Excluding_Operation(String cohesion_type, String operation_name, double name_weight, double com_weight, double seq_weight, boolean exclude_min_of_com_or_seq, boolean remove_prefix_verb){
		double LoC = 0.0;

		if(print) System.out.println("Calculating cohesion for the portType = " + name + " by excluding the operation = " + operation_name);

		if(operations.length() - 1 == 0 || operations.length() - 1 == 1) LoC = -1.0;
		else{
			int counter = 0;
			double sum = 0.0;
			int C = (operations.length() - 1) * (operations.length() - 2)/2;

			for(int op1 = 0; op1 < operations.length(); ++op1){
				for(int op2 = 0; op2 < operations.length(); ++op2){
					if(op1 < op2){
						Operation operation1 = operations.get(op1);
						Operation operation2 = operations.get(op2);

						if(!operation1.get_name().equals(operation_name) && !operation2.get_name().equals(operation_name)){
							counter++;
							//System.out.println("portType - get_LoC_Excluding_Operation: Combination (" + counter + "/" + C + ") = (" + operation1.get_name() + ", " + operation2.get_name() + ").");

							double coef = 0.0;

							if(cohesion_type.equals("sequential")) 
								coef = operation1.get_sequential_coefficient(operation2);
							else if(cohesion_type.equals("avg_com_seq")) 
								coef = operation1.get_avg_com_seq_coefficient(operation2);
							else if(cohesion_type.equals("communicational")) 
								coef = operation1.get_communicational_coefficient(operation2);
							else if(cohesion_type.equals("functional"))
								coef = operation1.getConceptualCoefficient(operation2, name_weight, com_weight, seq_weight, exclude_min_of_com_or_seq, remove_prefix_verb);
							else if(cohesion_type.equals("hybrid"))
								coef = operation1.get_hybrid_coefficient(operation2);

							sum += coef;
						}
					}
				}
			}

			LoC = 1.0 - (double)sum / (double)C;
		}

		return LoC;
	}


	public double get_LoC_by_Adding_Operation(String cohesion_type, Operation operation, double name_weight, double com_weight, double seq_weight, boolean exclude_min_of_com_or_seq, boolean remove_prefix_verb){
		double sum = 0.0;

		if(print) System.out.println("Calculating cohesion for the portType = " + name + " by adding the operation = " + operation.get_name());

		int C = (operations.length() + 1) * (operations.length())/2;

		for(int op1 = 0; op1 < operations.length() + 1; ++op1){
			for(int op2 = 0; op2 < operations.length() + 1; ++op2){
				if(op1 > op2){
					Operation operation1;
					Operation operation2 = operations.get(op2);

					if(op1 == operations.length()) operation1 = operation;
					else operation1 = operations.get(op1);

					double coef = 0.0;

					if(cohesion_type.equals("sequential")) coef = operation1.get_sequential_coefficient(operation2);
					else if(cohesion_type.equals("avg_com_seq")) coef = operation1.get_avg_com_seq_coefficient(operation2);
					else if(cohesion_type.equals("communicational")) coef = operation1.get_communicational_coefficient(operation2);
					else if (cohesion_type.equals("functional")) coef = operation1.getConceptualCoefficient(operation2, name_weight, com_weight, seq_weight, exclude_min_of_com_or_seq, remove_prefix_verb);
					else if(cohesion_type.equals("hybrid")) coef = operation1.get_hybrid_coefficient(operation2);

					sum += coef;
				}
			}
		}

		double LoC = 1.0 - (double)sum / (double)C;
		return LoC;
	}


	public double get_LoC_by_Adding_List_of_Operations(String cohesion_type, List<Operation> adding_operations, double name_weight, double com_weight, double seq_weight, boolean exclude_min_of_com_or_seq, boolean remove_prefix_verb){
		List<Operation> merged_operations = new List<Operation>();
		merged_operations.Insert(adding_operations);
		merged_operations.Insert(operations);

		if(print) System.out.println("Calculating cohesion for the portType = " + name + " by adding operations.");

		double sum = 0.0;
		int C = merged_operations.length() * (merged_operations.length() - 1)/2;

		for(int op1 = 0; op1 < merged_operations.length(); ++op1){
			for(int op2 = 0; op2 < merged_operations.length(); ++op2){
				if(op1 < op2){
					Operation operation1 = merged_operations.get(op1);
					Operation operation2 = merged_operations.get(op2);

					double coef = 0.0;

					if(cohesion_type.equals("sequential")) coef = operation1.get_sequential_coefficient(operation2);
					else if(cohesion_type.equals("avg_com_seq")) coef = operation1.get_avg_com_seq_coefficient(operation2);
					else if(cohesion_type.equals("communicational")) coef = operation1.get_communicational_coefficient(operation2);
					else if(cohesion_type.equals("functional")) coef = operation1.getConceptualCoefficient(operation2, name_weight, com_weight, seq_weight, exclude_min_of_com_or_seq, remove_prefix_verb);
					else if(cohesion_type.equals("hybrid")) coef = operation1.get_hybrid_coefficient(operation2);

					sum += coef;
				}
			}
		}

		double LoC = 1.0 - (double)sum / (double)C;
		return LoC;
	}


	public boolean Check_Relationships(String cohesion_type, Operation operation, double name_weight, double com_weight, double seq_weight, boolean exclude_min_of_com_or_seq, boolean remove_prefix_verb){
		boolean relevant = false;

		if(operations.length() == 1) relevant = true;

		String name = operation.get_name();
		for(int i = 0; i < operations.length(); ++i){
			Operation tmp_operation = operations.get(i);
			String tmp_name = tmp_operation.get_name();

			if(!tmp_name.equals(name)){
				double coef = 0.0;
				if(cohesion_type.equals("sequential")) coef = operation.get_sequential_coefficient(tmp_operation);
				else if(cohesion_type.equals("avg_com_seq")) coef = operation.get_avg_com_seq_coefficient(tmp_operation);
				else if(cohesion_type.equals("communicational")) coef = operation.get_communicational_coefficient(tmp_operation);
				else if(cohesion_type.equals("functional")) coef = operation.getConceptualCoefficient(tmp_operation, name_weight, com_weight, seq_weight, exclude_min_of_com_or_seq, remove_prefix_verb);
				else if(cohesion_type.equals("hybrid")) coef = operation.get_hybrid_coefficient(tmp_operation);

				if(coef > 0.0) relevant = true;
			}
		}

		return relevant;
	}


	public String get_info(String cohesion_type, double name_weight, double com_weight, double seq_weight, boolean exclude_min_of_com_or_seq, boolean remove_prefix_verb){
		String info = name + "\n";
		double LoC = Double.valueOf(twoDForm.format(get_LoC(cohesion_type, name_weight, com_weight, seq_weight, exclude_min_of_com_or_seq, remove_prefix_verb)));
		if(LoC != -1.0) info = name + "(" + LoC + ")\n";

		for(int i = 0; i < operations.length(); ++i){
			Operation Op = operations.get(i);
			info += "\n" + Op.get_name() + "()";
		}

		return info;
	}
	/*************************Operations tha calculate LoC for communicational or sequential cohesion - END.*************************/


	public boolean Is_Abstraction(){
		return is_abstraction;
	}


	public int get_Coupling_Reduction(){
		return Coupling_Reduction;
	}


	public void set_Coupling_Reduction(int coupling_reduction){
		Coupling_Reduction = coupling_reduction;
	}


	public void set_id(int cid){
		id = cid;
	}


	public int get_id(){
		return id;
	}


	public String get_name(){
		return name;
	}


	public List<Operation> get_Operations() {
		return operations;
	}


	public Operation Insert(String operation_name){
		Operation op = new Operation(operation_name);
		operations.Insert(op);
		return op;
	}


	public void set_Operations(List<Operation> x){
		operations = x;
	}


	public void Insert(Operation operation){
		operations.Insert(operation);
	}


	public void Remove(String operation_name){
		for(int i = 0; i < operations.length(); ++i){
			Operation operation2 = operations.get(i);
			if(operation2.get_name().equals(operation_name))operations.Remove(i);
		}
	}


	public void Print(){
		//System.out.println(name);
		for(int i = 0; i < operations.length(); ++i){
			//System.out.print("\t\t\tOperation (" + i + ") : ");
	    	operations.get(i).Print();
	    }
	}
}
