package Services_Registry;

import Data_Structures.*;

public class Service_Provider {

	//Constructor.
	public Service_Provider(String cname){
		name = cname;
		print = true;
		services = new List<Service>();
		segregated_portTypes = new Tree_Forest();
	}


	//Variables.
	private String name;
	private boolean print;
	private List<Service> services;
	private Tree_Forest segregated_portTypes;


	//Functions.
	/********** Excluded Elements per provider **********/ 
	public void Identify_Excluded_Elements(){
		List<Message> all_input_messages = get_Messages("input");
		//if(print) System.out.println("provider = " + name + " - Total number of input messages = " + all_input_messages.length());
		Identify_Excluded_Elements(all_input_messages);

		List<Message> all_output_messages = get_Messages("output");
		//if(print) System.out.println("provider = " + name + " - Total number of output messages = " + all_output_messages.length());
		Identify_Excluded_Elements(all_output_messages);

		Print_Excluded_Elements(all_input_messages);
		Print_Excluded_Elements(all_output_messages);
	}


	private List<Message> get_Messages(String importance_type){
		List<Message> all_messages = new List<Message>();

		for(int i = 0; i < services.length(); ++i){
			Service service = services.get(i);
			List<portType> pTs = service.get_portTypes();
			for(int p = 0; p < pTs.length(); ++p){
				portType pT = pTs.get(p);
				List<Operation> ops = pT.get_Operations();
				for(int op = 0; op < ops.length(); ++op){
					Operation operation = ops.get(op);

					if(importance_type.equals("input")) all_messages.Insert(operation.get_Input_Msg());
					else if(importance_type.equals("output")) all_messages.Insert(operation.get_Output_Msg());
				}
			}
		}

		return all_messages;
	}


	private void Identify_Excluded_Elements(List<Message> all_messages){
		for(int i = 0; i < all_messages.length(); ++i){
			Message message = all_messages.get(i);

			String message_name = message.get_name();
			//if(print) System.out.println("Message = " + message_name);

			String[] vertices_names = message.get_vertices_names();
			for(int id = 0; id < vertices_names.length; id++){
				String vertex_name = vertices_names[id];

				long heapSize = Runtime.getRuntime().totalMemory();
		        long freeHeapSize = Runtime.getRuntime().freeMemory();
		 
		        //Print the jvm heap size.
		       // System.out.println("Heap Size = " + heapSize + " Free = " + freeHeapSize);

		        Runtime.getRuntime().gc();		//Call garbage collector.

				int occurences = Find_Occurrences_in_other_Messages(vertex_name, message_name, all_messages);
				if(occurences == all_messages.length()) message.Excluded(id, true);
				else message.Excluded(id, false);

				heapSize = Runtime.getRuntime().totalMemory();
		        freeHeapSize = Runtime.getRuntime().freeMemory();

		        //Print the jvm heap size.
		       // System.out.println("Heap Size = " + heapSize + " Free = " + freeHeapSize);

				Runtime.getRuntime().gc();		//Call garbage collector.

				//if(print) System.out.println("\tname = " + vertex_name + " - occurences = " + occurences + " - Excluded = " + message.Is_Excluded(id));
			}

			Runtime.getRuntime().gc();		//Call garbage collector.
		}
	}


	private int Find_Occurrences_in_other_Messages(String vertex_name, String message_name, List<Message> all_messages){
		int occurences = 1;

		for(int i = 0; i < all_messages.length(); ++i){
			Message compared_message = all_messages.get(i);

			String compared_message_name = compared_message.get_name();
			if(!compared_message_name.equals(message_name)){
				//if(print) System.out.println("Psaxnw ton vertex = " + vertex_name + " kai to sigrinw me to message = " + compared_message_name);

				long heapSize = Runtime.getRuntime().totalMemory();
		        long freeHeapSize = Runtime.getRuntime().freeMemory();

		        //Print the jvm heap size.
		       // System.out.println("Heap Size = " + heapSize + " Free = " + freeHeapSize);

		        Runtime.getRuntime().gc();		//Call garbage collector.

				String[] vertices_names = compared_message.get_vertices_names();
				for(int id = 0; id < vertices_names.length; id++){
					String compared_vertex_name = vertices_names[id];
					//if(print) System.out.println("Psaxnw ton vertex = " + vertex_name + " kai to sigrinw me to type = " + compared_vertex_name);

					if(compared_vertex_name.equals(vertex_name)){
						occurences++;
						break;
					}
				}
			}
		}

		return occurences;
	}


	private void Print_Excluded_Elements(List<Message> all_messages){
		for(int i = 0; i < all_messages.length(); ++i){
			Message message = all_messages.get(i);

			String message_name = message.get_name();
			//if(print) System.out.println("Message = " + message_name);

			String[] vertices_names = message.get_vertices_names();
			for(int id = 0; id < vertices_names.length; id++){
				String vertex_name = vertices_names[id];

				//if(print) System.out.println("\tname = " + vertex_name + " - Excluded = " + message.Is_Excluded(id));
			}
		}
	}

	/********** Excluded Elements per provider **********/


	public String get_name(){
		return Remove_Suffix(name);
	}


	public List<Service> get_Services(){
		return services;
	}


	public Service Insert(String cname){
		Service service = new Service(cname);
		services.Insert(service);
		return service;
	}


	public Tree_Forest get_segregated_portTypes(){
		return segregated_portTypes;
	}


	public int get_last_index_of_segregated_portTypes(){
		return segregated_portTypes.get_nodes_id().length();
	}


	public Integer Insert_segregated_portType(String segregated_portType){
		return segregated_portTypes.Insert_Node(segregated_portType);
	}


	public Integer Insert_segregated_portType(String segregated_portType, Integer parent){
		return segregated_portTypes.Insert_Node(segregated_portType, parent);
	}


	private String Remove_Suffix(String s){
		int index = s.indexOf(".");
		if(index > 0) s = s.substring(0, index);
		return s;
	}


	public void Print(){
		System.out.println("------------------------------------------------------------------");
		//System.out.println("Service Provider : " + name);
	    for(int i = 0; i < services.length(); ++i){
	    //	System.out.print("\tService(" + i + ") : ");
	    	services.get(i).Print();
	    }

	    System.out.println("------------------------------------------------------------------");
	}
}
