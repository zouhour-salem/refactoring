package Services_Registry;

public class Output_Msg extends Message {

	//Constructor.
	public Output_Msg(String cname) {
		super(cname);
	}
}
