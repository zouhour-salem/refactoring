package Services_Registry;

import Data_Structures.List;

public class Registry {

	//Constructor.
	public Registry(){
		providers = new List<Service_Provider>();
	}

	//Variables.
	private List<Service_Provider> providers;


	//Operations.
	public void Insert(Service_Provider provider){
		providers.Insert(provider);
	}


	public List<Service_Provider> get_providers(){
		return providers;
	}


	public portType_List Make_List_of_PortTypes_from_Registry(){
		portType_List pT_List = new portType_List();

		/*int count = 0;
		Service[] S = get_Services();//Find the number of all portTypes in Registry R.
		for(int i = 0; i < get_Size(); ++i)
			for(int j = 0; j < S[i].get_Size(); ++j)
				++count;

		//System.out.println("Registry - Make_List_of_PortTypes_from_Registry : Number of portTypes in Registry = " + count);

		if(count > 0){
			for(int i = 0; i < get_Size(); ++i){//Make the list of portTypes in Registry R.
				portType[] pT = S[i].get_portTypes();
				for(int j = 0; j < S[i].get_Size(); ++j){
					pT_List.Insert(pT[j]);
				}
			}
		}*/

		return pT_List;
	}


	public void Print(){
	    for(int i = 0; i < providers.length(); ++i){
	    	providers.get(i).Print();
	    }
	}
}
