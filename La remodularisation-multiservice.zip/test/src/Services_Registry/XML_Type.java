package Services_Registry;

import Data_Structures.*;

public class XML_Type {

	//1st Constructor.
	public XML_Type(int cid, Object x, String cname, XML_Type cparent_type){//I keep the object temporary in order to check if this XML is built-in type.
		id = cid;
		name = cname;
		type_obj = x;								//After this, I'll free it.
		print = false;
		parent_type = cparent_type;
		sub_types = new List<XML_Type>();
	}


	//2nd Constructor.
	public XML_Type(String cname, String ctype, XML_Type cparent_type){//This constructor is for built-in types.
		id = -1;
		name = cname;
		type = ctype;
		print = false;
		is_ref = false;
		is_basic_type = true;
		parent_type = cparent_type;				//If parent_type = null, then it has not parent type: (1)1st level XML type; (2) the type of a part.
		sub_types = new List<XML_Type>();
	}


	//Variables.
	private int id;
	private String name;
	private String type;
	private boolean print;
	private boolean is_ref;
	private Object type_obj;
	private boolean is_excluded;		//Excluded in intersection and union of two messages.
	private XML_Type parent_type;
	private boolean is_basic_type;
	private List<XML_Type> sub_types;


	//Operations.
	public int get_id() {
		return id;
	}


	public int set_id(int cid) {
		id = cid;
		return id;
	}


	public void Excluded(boolean cis_excluded){
		is_excluded = cis_excluded;
	}


	public boolean Is_Excluded(){
		return is_excluded;
	}


	public void set_is_ref(boolean cis_ref) {
		is_ref = cis_ref;
	}


	public boolean Is_Ref() {
		return is_ref;
	}


	public XML_Type get_parent_type() {
		return parent_type;
	}


	public void set_parent_type(XML_Type x) {
		parent_type = x;
	}


	public Object get_type_obj() {
		return type_obj;
	}


	public void set_type_obj(Object x) {
		type_obj = x;
	}


	public void Remove_sub_type(XML_Type ref_type) {
		List<XML_Type> tmp_types = new List<XML_Type>();
		for(int i = 0; i < sub_types.length(); ++i) if(sub_types.get(i).get_name().equals(ref_type.get_name()) == false) tmp_types.Insert(sub_types.get(i));
		sub_types = tmp_types;
	}


	public void Add_sub_type(XML_Type x) {
		sub_types.Insert(x);
		//if(print) System.out.println("\tXML_Type - Add_sub_type : sub_type = " + x.get_name());
	}


	public void set_sub_types(List<XML_Type> x) {
		sub_types = x;
		//if(print) for(int i = 0; i < sub_types.length(); ++i) System.out.println("\tXML_Type - set_sub_types : sub_type(" + i + ") = " + sub_types.get(i).get_name());
	}


	public boolean Is_Basic_Type() {
		return is_basic_type;
	}


	public void set_is_basic_type(boolean x) {
		is_basic_type = x;
	}


	public void set_type(String x) {
		type = x;
	}


	public String get_type() {
		return type;
	}


	public List<XML_Type> get_sub_types() {
		return sub_types;
	}


	public String get_name(){
		return name;
	}
	
	
	public void Free_XML_type_obj(){//Free the local type_obj and the type_objs of all subtypes recursively.
		type_obj = null;

		Queue<XML_Type> Q = new Queue<XML_Type>();
		Q.Enqueue(sub_types);
		while(Q.isEmpty() == false){
			XML_Type type = Q.Dequeue();
			type.set_type_obj(null);
			List<XML_Type> sub_types = type.get_sub_types();
			Q.Enqueue(sub_types);
		}
	}


	public void Print(){
		//System.out.print(name);
		for(int i = 0; i < sub_types.length(); ++i){
			//System.out.print("\t\t\t\t\t\tXML_Type (" + i + ") : ");
			sub_types.get(i).Print();
		}
	}
}