package Services_Registry;

import Data_Structures.List;

public class Service {
	
	//Constructor.
	public Service(String cname){
		name = cname;
		portTypes = new List<portType>();
	}


	//Variables.
	private String name;
	private List<portType> portTypes;
	private List<Double> QoS;


	//Operations.
	public void set_portTypes(List<portType> x) {
		portTypes = x;
	}


	public List<portType> get_portTypes() {
		return portTypes;
	}


	public String get_name(){
		return name;
	}


	public portType Insert(String cname){
		portType pT = new portType(cname, false);
		portTypes.Insert(pT);
		return pT;
	}


	public void Remove(String pT_name){
		for(int i = 0; i < portTypes.length(); ++i){
			String tmp_pT_name = portTypes.get(i).get_name();
			if(tmp_pT_name.equals(pT_name)) portTypes.Remove(i);
		}
	}


	public void Print(){
		//System.out.println(name);
	    for(int i = 0; i < portTypes.length(); ++i){
	    	//System.out.print("\t\tPortType (" + i + ") : ");
	    	portTypes.get(i).Print(); 
	    }
	}
}