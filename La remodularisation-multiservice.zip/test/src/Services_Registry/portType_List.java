package Services_Registry;

public class portType_List {

	//Constructor.
	public portType_List(){
		count = 0;
		id = 0;
		portTypes = Initialize(1);
	}


	//Variables.
	int count;
	static long id;
	portType[] portTypes;


	//Operations
	public static long get_id(){return ++id;}
	public int get_Size(){return count;}
	public portType get_portType(int i){return portTypes[i];};


	public void Insert(portType pT){
		++count;
		portType[] old_pool = portTypes;
		portTypes = Initialize(count);
		System.arraycopy(old_pool, 0, portTypes, 0, old_pool.length);
		portTypes[count - 1] = pT;
		
		long cid = portType_List.get_id();
		//TODO //pT.set_id(cid);//Give an id to portType.
	}
	
	
	private portType[] Initialize(int size){
		boolean Is_Abstraction = false;
		portType[] pT_List = new portType[size];
		//TODO //for(int i = 0; i < size; ++i) pT_List[i] = new portType(new Object(), "", Is_Abstraction, Print_Msg, Fp);
		return pT_List;
	}


	public int Delete(portType pT){
		int index = -1;
		boolean belongs = false;
		portType[] new_portTypes = null;

		if(count == 1) new_portTypes = Initialize(1);
		else new_portTypes = Initialize(count - 1);

		for(int p = 0; p < count; ++p){
			if(portTypes[p].get_id() == pT.get_id()){
				index = p;
				belongs = true;
				break;
			}
		}

		if(belongs == true){
			int i = 0;
			for(int p = 0; p < count; ++p){
				if(portTypes[p].get_id() != pT.get_id()){
					new_portTypes[i] = portTypes[p];
					++i;
				}
			}

			portTypes = new_portTypes;
			--count;
		}

		return index;
	}

	
	public String Print(){
		String Local_Msg = new String("");

		for(int i = 0; i < count; ++i){
		    	int k = i + 1;
		    	Local_Msg += "\n\n\t\tPortType (" + k + ") : (" + portTypes[i].get_name() + ", " + portTypes[i].get_id() + ").";
		    	//System.out.println("\n\n\t\tPortType (" + k + ") : " + portTypes[i].get_id());
		    	//Local_Msg += portTypes[i].Print();
		}
			
		return Local_Msg;
	}
	
	
	public void Print_StdOut(){
		for(int i = 0; i < count; ++i){
		    	int k = i + 1;
		    	System.out.println("\t\tPortType (" + k + ") : (" + portTypes[i].get_name() + ", " + portTypes[i].get_id() + ").");
		}
	}
}