package Services_Registry;

public class Input_Msg extends Message {

	//Constructor.
	public Input_Msg(String cname) {
		super(cname);
	}
}
