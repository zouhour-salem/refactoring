package Services_Registry;

import Basic_Algorithms.Intersection;
import Basic_Algorithms.Union;
import Data_Structures.List;
import Data_Structures.Queue;

public abstract class Message {

	//Constructor.
	public Message(String cname){
		id = -1;
		name = cname;
		print = false;
		total_id = -1;
		parts = new List<Part>();
	}

	
	//Variables.
	private int id;						//id is unique only for this message.
	private String name;
	private int total_id;
	private boolean print;
	private List<Part> parts;
	private int[] parent_matrix;
	private boolean is_excluded;		//Excluded in intersection and union of two messages.
	private String[] vertices_names;


	//Operations.
	private int increase_id(){
		return ++total_id;
	}


	public int[] get_parent_matrix(){
		return parent_matrix;
	}


	public String[] get_vertices_names(){
		return vertices_names;
	}


	public void Generate_Parent_Matrix(){
		Init_Parent_Matrix();

		id = increase_id();
		parent_matrix[id] = id;
		vertices_names[id] = name;

		for(int i = 0; i < parts.length(); ++i){
			Part p = parts.get(i);
			XML_Type type = p.get_XML_Type();

			int id2 = type.set_id(increase_id());
			parent_matrix[id2] = id;

			//if(print) System.out.println("(" + name + " - " + type.get_name() + ") = (" + id + ", " + id2 + ").");

			if(type.Is_Basic_Type()) vertices_names[id2] = type.get_name() + ": " + type.get_type();
			else vertices_names[id2] = type.get_name();

			Queue<XML_Type> Q = new Queue<XML_Type>();
			Q.Enqueue(type);

			while(!Q.isEmpty()){
				type = Q.Dequeue();
				int id1 = type.get_id();

				List<XML_Type> sub_types = type.get_sub_types();
				for(int j = 0; j < sub_types.length(); ++j){
					if(sub_types.get(j).Is_Ref()){
						XML_Type ref = sub_types.get(j);
						List<XML_Type> sub_types_of_ref = ref.get_sub_types();
						XML_Type hard_type = sub_types_of_ref.get(0);	//It has only one sub_type: the hard type.

						id2 = hard_type.set_id(increase_id());
						parent_matrix[id2] = id1;
						vertices_names[id2] = hard_type.get_name();
						Q.Enqueue(hard_type);

						//if(print) System.out.println("(" + type.get_name() + " - " + hard_type.get_name() + ") = (" + id1 + ", " + id2 + ").");
					}
					else{
						id2 = sub_types.get(j).set_id(increase_id());
						parent_matrix[id2] = id1;
						if(sub_types.get(j).Is_Basic_Type()) vertices_names[id2] = sub_types.get(j).get_name() + " : " + sub_types.get(j).get_type();
						else vertices_names[id2] = sub_types.get(j).get_name();
						Q.Enqueue(sub_types.get(j));

						//if(print) System.out.println("(" + type.get_name() + " - " + sub_types.get(j).get_name() + ") = (" + id1 + ", " + id2 + ").");
					}
				}
			}
		}
	}


	private void Init_Parent_Matrix(){
		int num = 1;									//One is the message.

		for(int i = 0; i < parts.length(); ++i){
			Part p = parts.get(i);
			XML_Type type = p.get_XML_Type();

			++num;

			Queue<XML_Type> Q = new Queue<XML_Type>();
			Q.Enqueue(type);

			while(!Q.isEmpty()){
				type = Q.Dequeue();

				List<XML_Type> sub_types = type.get_sub_types();
				for(int j = 0; j < sub_types.length(); ++j){
					if(sub_types.get(j).Is_Ref()){
						XML_Type ref = sub_types.get(j);
						List<XML_Type> sub_types_of_ref = ref.get_sub_types();
						XML_Type hard_type = sub_types_of_ref.get(0);	//It has only one sub_type: the hard type.

						Q.Enqueue(hard_type);
						++num;
					}

					else{
						Q.Enqueue(sub_types.get(j));
						++num;
					}
				}
			}
		}

	//	if(print) System.out.println("Num of vertices of message = " + name + " is: " + num);
		
		vertices_names = new String[num];
		parent_matrix = new int[num];
	}


	public int get_id() {
		return id;
	}


	public void set_Parts(List<Part> cparts) {
		parts = cparts;
	}


	public List<Part> getParts() {
		return parts;
	}


	public String get_name() {
		return name;
	}


	public Part Insert(String cname, XML_Type cXML_type){
		Part part = new Part(cname, cXML_type);
		parts.Insert(part);
		return part;
	}


	public boolean Is_Excluded(int vertex_id){
		if(id == vertex_id) return is_excluded;

		for(int i = 0; i < parts.length(); ++i){
			Part part = parts.get(i);

			XML_Type type = part.get_XML_Type();
			int id = type.get_id();
			if(id == vertex_id) return type.Is_Excluded();

			Queue<XML_Type> Q = new Queue<XML_Type>();
			Q.Enqueue(type);
			while(!Q.isEmpty()){
				type = Q.Dequeue();

				id = type.get_id();
				if(id == vertex_id) return type.Is_Excluded();

				List<XML_Type> sub_types = type.get_sub_types();
				Q.Enqueue(sub_types);
			}
		}

		return true;
	}


	private int Get_Vertex_Id_into_Message_Tree(String vertex_name){
		int vertex_id = 0;
		for(vertex_id = 0; vertex_id < vertices_names.length; ++vertex_id) if(vertices_names[vertex_id].equals(vertex_name)) break;
		if(vertex_id == vertices_names.length) return -1;
		return vertex_id;
	}


	public void Excluded(int vertex_id, boolean cis_excluded){
		if(id == vertex_id){
			is_excluded = cis_excluded;
			return;
		}

		for(int i = 0; i < parts.length(); ++i){
			Part part = parts.get(i);

			XML_Type type = part.get_XML_Type();
			int id = type.get_id();
			if(id == vertex_id){
				type.Excluded(cis_excluded);
				return;
			}

			Queue<XML_Type> Q = new Queue<XML_Type>();
			Q.Enqueue(type);
			while(!Q.isEmpty()){
				type = Q.Dequeue();

				id = type.get_id();
				if(id == vertex_id){
					type.Excluded(cis_excluded);
					return;
				}

				List<XML_Type> sub_types = type.get_sub_types();
				Q.Enqueue(sub_types);
			}

			Runtime.getRuntime().gc();		//Call garbage collector.
		}
	}


	public double get_Similarity_Degree(Message M2){
		double sim = 0.0;

		String[] vertices_names1 = get_vertices_names();
		String[] vertices_names2 = M2.get_vertices_names();

		Intersection intersection = new Intersection();		//TODO: It must be substituted by the isomorphic subtree determination.
		List<String> vertices_names = intersection.Find(vertices_names1, vertices_names2);

		//if(print) System.out.println("Intersection of (" + name + ", " + M2.get_name() + "):");
		for(int i = 0; i < vertices_names.length(); ++i){
			String vertex_name = vertices_names.get(i);
			int vertex_id_in_M1 = Get_Vertex_Id_into_Message_Tree(vertex_name);
			if(!Is_Excluded(vertex_id_in_M1)) sim += 1.0;
			//if(print) System.out.println("\ttype = " + vertex_name + ", Excluded = " + Is_Excluded(vertex_id_in_M1));
		}

		//if(print) System.out.println("Intersection of (" + name + ", " + M2.get_name() + ") = " + sim);	

		return sim;
	}


	public double get_Order_of_Union(Message M2){
		double order_union = 0.0;

		String[] vertices_names1 = get_vertices_names();
		String[] in_vertices_names2 = M2.get_vertices_names();

		Union union = new Union();
		List<String> vertices_names = union.Find(vertices_names1, in_vertices_names2);

		//if(print) System.out.println("Union of (" + name + ", " + M2.get_name() + "):");
		for(int i = 0; i < vertices_names.length(); ++i){
			String vertex_name = vertices_names.get(i);
			boolean excluded;
			int vertex_id_in_M1 = Get_Vertex_Id_into_Message_Tree(vertex_name);
			int vertex_id_in_M2 = M2.Get_Vertex_Id_into_Message_Tree(vertex_name);
			if(vertex_id_in_M1 != -1) excluded = Is_Excluded(vertex_id_in_M1);
			else excluded = M2.Is_Excluded(vertex_id_in_M2);

			if(!excluded) order_union += 1.0;

			if(print){
				//if(vertex_id_in_M1 != -1) System.out.println("\ttype = " + vertex_name + ", Excluded = " + Is_Excluded(vertex_id_in_M1));
				//else System.out.println("\ttype = " + vertex_name + ", Excluded = " + Is_Excluded(vertex_id_in_M2));
			}
		}

		//if(print) System.out.println("Union of (" + name + ", " + M2.get_name() + ") = " + order_union);

		return order_union;
	}


	public void Print(){
		//System.out.println(name);
		for(int i = 0; i < parts.length(); ++i){
			//System.out.print("\t\t\t\t\tPart (" + i + ") : ");
	    	parts.get(i).Print();
	    }
	}
}
