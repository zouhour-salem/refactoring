package Data_Structures;

public class Tree_Forest {

	//Constructor.
	public Tree_Forest(){
		parents = new List<Integer>();
		nodes_id = new List<Integer>();
		nodes_label = new List<String>();
	}


	//Variables.
	private List<Integer> parents;
	private List<Integer> nodes_id;
	private List<String> nodes_label;


	//Operations.
	public List<Integer> get_parents(){
		return parents;
	}


	public List<Integer> get_nodes_id(){
		return nodes_id;
	}


	public List<String> get_nodes_label(){
		return nodes_label;
	}


	public Integer Insert_Node(String node_label){
		nodes_label.Insert(node_label);
		parents.Insert(nodes_label.length() - 1);			//Parent is myself.
		nodes_id.Insert(nodes_label.length() - 1);

		return nodes_label.length() - 1;
	}


	public Integer Insert_Node(String node_label, Integer parent){
		nodes_label.Insert(node_label);
		parents.Insert(parent);
		nodes_id.Insert(nodes_label.length() - 1);

		return nodes_id.length() - 1;
	}
}
