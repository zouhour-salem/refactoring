package Data_Structures;

import java.util.Iterator;
import java.util.NoSuchElementException;
	
public class List<Item> implements Iterable<Item> {

	//Constructor.
	public List() {
		N = 0;
	    first = null;
	}


	//Variables.
	private int N;         // number of elements on list.
	private Node first;    // beginning of list.


	// helper linked list class
	private class Node {
		private Item item;
	    private Node next;
	}


	public boolean isEmpty(){
		return first == null;
	}


	public int length(){
		return N;
	}


	public void Insert(Item item) {
		Node x = new Node();
	    x.item = item;
	    if (isEmpty()){
	    	first = x;
	    	first.next = null;
	    }
	    else{
	    	x.next = first;
	    	first = x;
	    }
	    
	    N++;
	}


	public Item get(int pos) {
	    Item item = first.item;
	    Node tmp = first;
	    for (int i = 0; i < pos; ++i){
	    	tmp = tmp.next;
	    	item = tmp.item;
	    }

	    return item;
	}
	
	
	private Node get_Node(int pos) {
	    Node tmp = first;
	    for (int i = 0; i < pos; ++i) tmp = tmp.next;

	    return tmp;
	}


	public void Remove(int pos) {
		if (pos == 0) first = first.next;
		else{
			Node prev = get_Node(pos - 1);
			Node cur = get_Node(pos);
			prev.next = cur.next;
		}

		N--;
	}


	public void Insert(List<Item> items) {
		int len = 0;
		if(items != null) len = items.N;
	    for(int i = 0; i < len; ++i) Insert(items.get(i));
	}


	public Iterator<Item> iterator(){
		return new ListIterator();
	}


	private class ListIterator implements Iterator<Item> {
		private Node current = first;
	    public boolean hasNext()  { return current != null; }
	    public void remove() { throw new UnsupportedOperationException(); }
	    public Item next() {
	    	if (!hasNext()) throw new NoSuchElementException();
	        Item item = current.item;
	        current = current.next; 
	        return item;
	    }
	}
}