package Data_Structures;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Queue<Item> implements Iterable<Item> {

	//Constructor.
    public Queue() {
    	first = null;
        last  = null;
    }


	//Variables.
    private int N;         // number of elements on queue
    private Node first;    // beginning of queue
    private Node last;     // end of queue


    // helper linked list class
    private class Node {
        private Item item;
        private Node next;
    }


    public boolean isEmpty(){
    	return first == null;
    }


    public int length(){
    	return N;
    }


    public void Enqueue(Item item) {
        Node x = new Node();
        x.item = item;
        if (isEmpty()){
        	first = x;
        	last = x;
        }
        else{
        	last.next = x;
        	last = x;
        }

        N++;
    }


    public void Enqueue(List<Item> items) {
    	int len = 0;
    	if(items != null) len = items.length();
    	for(int i = 0; i < len; ++i) Enqueue(items.get(i));
    }


    public Item Dequeue() {
        if (!isEmpty()){
        	Item item = first.item;
        	first = first.next;
        	N--;
        	return item;
        }

        return null;
    }


     public Item get_Item(int p) {
    	Item item = first.item;
        Node tmp = first;
    	for (int i = 0; i < p; ++i){
    		tmp = tmp.next;
    		item = tmp.item;
    	}

        return item;
    }


    public String toString() {
        String s = "";
        for (Node x = first; x != null; x = x.next) s += x.item + " ";
        return s;
    }


    public Iterator<Item> iterator(){
    	return new QueueIterator();
    }


    private class QueueIterator implements Iterator<Item> {
        private Node current = first;
        public boolean hasNext()  { return current != null; }
        public void remove() { throw new UnsupportedOperationException(); }
        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            Item item = current.item;
            current = current.next; 
            return item;
        }
    }
}