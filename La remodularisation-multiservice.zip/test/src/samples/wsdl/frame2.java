package samples.wsdl;


import java.util.ArrayList;
import java.util.List;

import com.predic8.schema.Element;
import com.predic8.schema.TypeDefinition;
import com.predic8.wsdl.*;

import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.Font;

import javax.swing.JList;
import javax.swing.JComboBox;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JButton;

import java.awt.Color;

import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;


public class frame2 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame2 window = new frame2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frame2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBackground(Color.ORANGE);
		frame.setBounds(100, 100, 866, 499);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSelectionnezUnService = new JLabel("Selectionnez un service");
		lblSelectionnezUnService.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSelectionnezUnService.setBounds(46, 57, 153, 50);
		frame.getContentPane().add(lblSelectionnezUnService);
		
		String[]Message={ "http://www.webservicex.com/globalweather.asmx?wsdl", "http://www.xignite.com/xFinancials.asmx?WSDL","http://www.xignite.com/xestimates.asmx?WSDL"};
		JComboBox comboBox = new JComboBox(Message);
	
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		comboBox.setToolTipText("");
		comboBox.setMaximumRowCount(14);
		comboBox.setBounds(210, 57, 341, 50);
		frame.getContentPane().add(comboBox);
		
		JButton btnCommunicationnalcohesion = new JButton("Communicationnal-Cohesion ");
		btnCommunicationnalcohesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
			
				/* Copyright 2012 predic8 GmbH, www.predic8.com

				   Licensed under the Apache License, Version 2.0 (the "License");
				   you may not use this file except in compliance with the License.
				   You may obtain a copy of the License at

				   http://www.apache.org/licenses/LICENSE-2.0

				   Unless required by applicable law or agreed to in writing, software
				   distributed under the License is distributed on an "AS IS" BASIS,
				   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
				   See the License for the specific language governing permissions and
				   limitations under the License. */

				

				
				    WSDLParser parser = new WSDLParser();
				    
				    double average_communicational_cohesion=0;
				    
					double lack_of_com_cohesion=0;

				 //Definitions defs = parser
				 // .parse("http://www.xignite.com/xHistorical.asmx?WSDL");
				    //Definitions defs = parser
				    //	.parse("http://www.xignite.com/xestimates.asmx?WSDL");
				   
				 Definitions defs = parser
				 .parse("https://webservices.amazon.com/AWSECommerceService/AWSECommerceService.wsdl");
				//   

				    
				    
				    List<Operation>ListTotale=  new ArrayList<Operation>();
				    
				    for (PortType pt : defs.getPortTypes()) {
				    	List<Operation>ListOpParPortype=new ArrayList<Operation>();
				    	//System.out.println("PortTypeName:"+pt.getName());
				   
				      for (Operation op : pt.getOperations()) {
				    	  ListOpParPortype.add(op);
				    	
				    	  
				       // System.out.println(" -" + op.getName());
				       // System.out.println(" ** "+" Operation Name: " + op.getName());
				      }
				      
				    	
				    	
				    //	System.out.println("le nbre des op�rations dans ce portype est "+ ListOpParPortype.size() +"qui sont");
				    	for(int i=0 ; i<ListOpParPortype.size() ;i++){
				    	//	System.out.println(" ** "+" Operation Name: " + ListOpParPortype.get(i).getName());
				    		ListTotale.add(ListOpParPortype.get(i));
				    		
				    	}
				    	
				    
				       // for(int i=0 ; i<ListTotale.size(); i++){
				        	//System.out.println("Op�ration est " + ListTotale.get(i).getName());
				    	
				    	
				    	
				    	
				   // }
				    }
				    
				    double[][] multiples = new double[ListTotale.size()][ListTotale.size()];
				    
				    
				////	System.out.println("le nbre totales des op�rations est "+ ListTotale.size()); 
					int ensemble_operation=0;
					for(int i=0 ; i<ListTotale.size(); i++){
						///System.out.println("opName:"+ListTotale.get(i).getName());
					}
				        for(int i =0 ; i<ListTotale.size(); i++){
				       	 int vble=i; 
				       	
				       	 for(int k= vble+1 ; k<ListTotale.size();k++){
				       		
				       		 //ListOprt1.add(ListOprt.get(k));
				       	///	 System.out.println(" ***on compare les op�rations num  " + (vble)   + ListTotale.get  (vble)  .getName() + "  et num  "  + (k)   + ListTotale.get (k)  .getName());	  
				       		 Operation op1=ListTotale.get(vble);
				       		 Operation op2=ListTotale.get(k);
				       		
				       		 
				       	 
				       	 
				       	//System.out.println("on compare les op�rations num  "  + (vble) +   ListOprt.get(vble).getName()  +  "  et num  "  + (k) + ListOprt.get(k).getName());	  
				      	double rslt=compare(op1,op2);
				      	ensemble_operation++;
				      	multiples[i][k]=rslt;
				       	
				       	 } 
				       	 // System.out.println(" ** "+" Operation Name ( " + i + " ): " + ListOprt.get(i));  
				        
				         
				       

				       //ListOprt1.clear();
				      
				         }
				    	
				    ///	System.out.println("l'ensemble des op�rations est"+ ensemble_operation);
				        
				        
				        
				    	for(int i=0; i<multiples.length ;i++){
				    		for(int j=0; j<multiples.length;j++){
				    		///System.out.println("similarit� entre " + i + "et" + j +"est"+ multiples[i][j]);	
				    		average_communicational_cohesion=average_communicational_cohesion+multiples[i][j];
						}
					}
					
					
				lack_of_com_cohesion=1-( (average_communicational_cohesion/ensemble_operation) *0.5 );
				//System.out.println("le manque de coh�sion sequentiel est" +lack_of_com_cohesion);
				    	
				    		
				JOptionPane.showMessageDialog(null, "le manque de coh�sion communicational est" +lack_of_com_cohesion);    	
				    	
				    	
				    	
				    	
				    	
				    	
				    	
				    	
				       
						
				  }

				private double compare(Operation op1, Operation op2) {
					// TODO Auto-generated method stub
					
					
					
					
						// TODO Auto-generated method stub
						//compareinput(op1, op2);
						//System.out.println("ces types output");
						//// compareoutput(op1,op2);
						// System.out.println("cccccccccccccccccc");
						 double Similarit�_input=compareinput(op1, op2);
						/// System.out.println("ces types output");
						double Similarit�_output=compareoutput(op1, op2);
						 
						 //int avrg_input=Similarit�_input/2 ;
						// int avrg_output=Similarit�_output/2 ;
						 //int Similarit�_output=compareoutput(op1, op2);
						
						 double Similarit�_Communicationnelle=  (Similarit�_input*0.5) +( Similarit�_output*0.5)   ;
						//double avrg_input=Similarit�_input/ 2 ;
						//double avrg_output=Similarit�_output/2 ;
						/// System.out.println("La Similarit�_Communicationnellee de ces op�rations est "+ Similarit�_input + "et"+ Similarit�_output +" est �gal � " +Similarit�_Communicationnelle);
						return Similarit�_Communicationnelle;
					
						//if( Similarit�_Communicationnelle==1){
							//System.out.println("---> ces deux op�rations ont une similarit� maximale");
							//System.out.println(""+ op1.getName());
							//System.out.println(""+ op2.getName());
							
						//} 
						 
						 
						 
					}


					private double compareoutput(Operation op1, Operation op2) {
						// TODO Auto-generated method stub
						double Similarit�_output=0;
						List<String>liste3=new ArrayList<String>();
						List <String> liste1=typedistingueoutput(op1);
						List <String> liste2=typedistingueoutput(op2);
						double nbrevblecommuntotaleoutput=0;

						//System.out.println("ces types output");
						for(int i=0; i< liste1.size() ; i++){
							////System.out.println("TypeOutputop1 : "+ liste1.get(i));
							if(!liste3.contains(liste1.get(i))){
							liste3.add(liste1.get(i));
							//String s=liste1.get(i);
							
							
						}
						}
						for(int j=0; j< liste2.size() ; j++){
						////	System.out.println("TypeOutputop2 : "+ liste2.get(j));
							if(!liste3.contains(liste2.get(j))){
								liste3.add(liste2.get(j));
							}
							//String s1=liste2.get(j);
							
						}
						
						
						for(int i=0; i<liste1.size();i++){
							if(liste2.contains(liste1.get(i))){
								 nbrevblecommuntotaleoutput++;
							}
						}

					


						///System.out.println("le nbre de type commun input de deux op�rations est"+ nbrevblecommuntotaleoutput);
						///System.out.println("le nbre de type distingue input totale de deux op�rations est"+ liste3.size());

							if(liste3.size()>0){
							///System.out.println("le nbre totale de type commun output entre ces deux op�rations est"+ nbrevblecommuntotaleoutput);
							//System.out.println("le nbre de type distingue output totale de deux op�rations est "+liste5.size());
						     
							
							///	System.out.println("la similarit� (parametre)entre ces op�rations est" + nbrevblecommuntotaleoutput/liste3.size());
							
								return nbrevblecommuntotaleoutput/liste3.size();
							
							}
							
								
							else{
								Similarit�_output=0;
								/// System.out.println("la similarit� (parametre)--------entre ces op�rations est" + Similarit�_output);
								 return Similarit�_output;
							}
							
								//System.out.println("la similarit� (type de retour)entre ces op�rations est" + Similarit�_output);

							

							//for(int i=0 ; i<l.size();i++){
//								System.out.println("type " +  l.get(i));
							//}
							//for(int i=0 ; i<l1.size();i++){
//								System.out.println("type " +  l1.get(i));
							//}	
							//System.out.println("le nbre des elements pour la premiere op�ration est " +l.size())	;
							//System.out.println("le nbre des elements pour la deuxieme op�ration est " +l1.size())	;
							 
							//System.out.println("SIDC est �gal � "+ nbrevblecommuntotaleoutput/liste5.size()  );
							
								
							}
						
					private List<String> typedistingueoutput(Operation op2) {
						// TODO Auto-generated method stub
						List<Part> list = new ArrayList<Part>();
						 List<String> listString=new ArrayList<String>();
						  List<String> listD=new ArrayList<String>();
						 
					   //System.out.println(" ** "+" Operation Name: " + operation.getName());
					 
					   //System.out.println("         Operation Input Message: "
						 //   + op.getInput().getMessage().getName().toString());
					   Message msg_input=op2.getOutput().getMessage();
					 
						//System.out.println("              Message Parts: ");
						
						
						for (Part part : msg_input.getParts()) {
						
							list.add(part);
							
						}
						

						//Message msg_out=operation.getOutput().getMessage();
					  //System.out.println("              Message Parts: ");
						
						//for (Part part : msg_out.getParts()) {
							
							////list.add(part);
						
							//String ch1=part.getElement().getQname().getQualifiedName();
							//if(ch1!=null){
								//listString.add(ch1);
							
						//}
							//String ch2=part.getType().getQname().getQualifiedName();
							//if(ch2!=null){
							//	listString.add(ch2);
							//}
							////}
						
						for( int i=0;i< list.size();i++){
						
						
						
								
						Element ch=list.get(i).getElement();
						

						
						if(ch!=null){
							String s= "s:"+ ch.getQname().getQualifiedName();
						//System.out.println("element: "+s);
						//if(s.equals("s:string")){
							//System.out.println("un element simple");
						//}
						listString.add(s);
						
						
						}
						}
						
						for( int i=0;i< list.size();i++){
							TypeDefinition t=list.get(i).getType();
							
							if(t!=null){
								String s1= t.getQname().getQualifiedName();
								//System.out.println("type: "+ s1);
								listString.add(s1);
							}
						}
						
						
						
						
						//System.out.println("le nbre des elements est "+listString.size());
						
						for(int i=0;i<listString.size();i++){
							//int j=i+1;
						
						//System.out.println("l'�lement num�ro "+ j + " est "+listString.get(i));
						
						if(! listD.contains(listString.get(i))){
							listD.add(listString.get(i));
						}
						
						}
						
						
						//System.out.println("le nbre des elements distingues pour cette op�ration est "+ listD.size());
						
						//for(int i=0 ; i<listD.size();i++){
							//System.out.println(listD.get(i));
						//}
						return listD;
						
						
						
						
					}	



					private double compareinput(Operation operation, Operation operation2) {
						double Similarit�_input=0;
						// TODO Auto-generated method stub
					List<String>liste3=new ArrayList<String>();
					List <String> liste1=typedistingueinput(operation);
					List <String> liste2=typedistingueinput(operation2);
					double nbrevblecommuntotaleinput=0;

					
					///System.out.println("ces types input");
					for(int i=0; i< liste1.size() ; i++){

						///System.out.println("TypeInPutop1 : "+ liste1.get(i));
						if(!liste3.contains(liste1.get(i))){
						
						liste3.add(liste1.get(i));
						
					}
					}
					
					for(int j=0; j< liste2.size() ; j++){
						///System.out.println("TypeInPutop2 : "+ liste2.get(j));
						if(!liste3.contains(liste2.get(j))){
							liste3.add(liste2.get(j));
						}
						
					}
					
					
					for(int i=0; i<liste1.size();i++){
						if(liste2.contains(liste1.get(i))){
							 nbrevblecommuntotaleinput++;
						}
					}



				///System.out.println("le nbre de type commun input de deux op�rations est"+ nbrevblecommuntotaleinput);
				///System.out.println("le nbre de type distingue input totale de deux op�rations est"+ liste3.size());

					if(liste3.size()>0){
					///System.out.println("le nbre totale de type commun output entre ces deux op�rations est"+ nbrevblecommuntotaleoutput);
					//System.out.println("le nbre de type distingue output totale de deux op�rations est "+liste5.size());
				     
					
					///	System.out.println("la similarit� (parametre)entre ces op�rations est" + nbrevblecommuntotaleinput/liste3.size());
					
						return nbrevblecommuntotaleinput/liste3.size();
					
					}
					
						
					else{
						/// System.out.println("la similarit� (parametre)--------entre ces op�rations est" + Similarit�_input);
						 return Similarit�_input;
					}
					
						//System.out.println("la similarit� (type de retour)entre ces op�rations est" + Similarit�_output);

					

					//for(int i=0 ; i<l.size();i++){
//						System.out.println("type " +  l.get(i));
					//}
					//for(int i=0 ; i<l1.size();i++){
//						System.out.println("type " +  l1.get(i));
					//}	
					//System.out.println("le nbre des elements pour la premiere op�ration est " +l.size())	;
					//System.out.println("le nbre des elements pour la deuxieme op�ration est " +l1.size())	;
					 
					//System.out.println("SIDC est �gal � "+ nbrevblecommuntotaleoutput/liste5.size()  );
					
						
					}

					private List<String> typedistingueinput(Operation operation) {
						// TODO Auto-generated method stub
						 List<Part> list = new ArrayList<Part>();
						 List<String> listString=new ArrayList<String>();
						  List<String> listD=new ArrayList<String>();
						 
					    //System.out.println(" ** "+" Operation Name: " + operation.getName());
					  
					    //System.out.println("         Operation Input Message: "
						 //   + op.getInput().getMessage().getName().toString());
					    Message msg_input=operation.getInput().getMessage();
					  
						//System.out.println("              Message Parts: ");
						
						
						for (Part part : msg_input.getParts()) {
						
							list.add(part);
							
						}
						

						//Message msg_out=operation.getOutput().getMessage();
					   //System.out.println("              Message Parts: ");
						
						//for (Part part : msg_out.getParts()) {
							
							////list.add(part);
						
							//String ch1=part.getElement().getQname().getQualifiedName();
							//if(ch1!=null){
								//listString.add(ch1);
							
						//}
							//String ch2=part.getType().getQname().getQualifiedName();
							//if(ch2!=null){
							//	listString.add(ch2);
							//}
							////}
						
						for( int i=0;i< list.size();i++){
						
						
						
								
						Element ch=list.get(i).getElement();
						

						
						if(ch!=null){
							String s= "s:"+ ch.getQname().getQualifiedName();
						//System.out.println("element: "+s);
						//if(s.equals("s:string")){
							//System.out.println("un element simple");
						//}
						listString.add(s);
						
						
						}
						}
						
						for( int i=0;i< list.size();i++){
							TypeDefinition t=list.get(i).getType();
							
							if(t!=null){
								String s1= t.getQname().getQualifiedName();
								//System.out.println("type: "+ s1);
								listString.add(s1);
							}
						}
						
						
						
						
						//System.out.println("le nbre des elements est "+listString.size());
						
						for(int i=0;i<listString.size();i++){
							//int j=i+1;
						
						//System.out.println("l'�lement num�ro "+ j + " est "+listString.get(i));
						
						if(! listD.contains(listString.get(i))){
							listD.add(listString.get(i));
						}
						
						}
						
						
						//System.out.println("le nbre des elements distingues pour cette op�ration est "+ listD.size());
						
						//for(int i=0 ; i<listD.size();i++){
							//System.out.println(listD.get(i));
						//}
						return listD;
						
							
						
						
							
					}}); 
		btnCommunicationnalcohesion.setBounds(21, 157, 138, 50);
		frame.getContentPane().add(btnCommunicationnalcohesion);
		
		JButton button = new JButton("Sequentiel-Cohesion");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
					    WSDLParser parser = new WSDLParser();

					    double average_sequentiel_cohesion=0;
					    
						double lack_of_seq_cohesion=0;
					 //Definitions defs = parser
					// .parse("http://www.xignite.com/xHistorical.asmx?WSDL");
						//Definitions defs = parser
						//.parse("http://www.xignite.com/xestimates.asmx?WSDL");
					   
				Definitions defs = parser
					      .parse("http://www.webservicex.com/globalweather.asmx?wsdl");
					//   
					    
					    List<Operation>ListTotale=  new ArrayList<Operation>();
					    
					    for (PortType pt : defs.getPortTypes()) {
					    	List<Operation>ListOpParPortype=new ArrayList<Operation>();
					    	//System.out.println("PortTypeName:"+pt.getName());
					   
					      for (Operation op : pt.getOperations()) {
					    	  ListOpParPortype.add(op);
					    	
					    	  
					       // System.out.println(" -" + op.getName());
					       // System.out.println(" ** "+" Operation Name: " + op.getName());
					       
					      
								
					    	}
					    	
					    	//System.out.println("le nbre des op�rations dans ce portype est "+ ListOpParPortype.size() +"qui sont");
					    	for(int i=0 ; i<ListOpParPortype.size() ;i++){
					    		//System.out.println(" ** "+" Operation Name: " + ListOpParPortype.get(i).getName());
					    		ListTotale.add(ListOpParPortype.get(i));
					    		
					    	}
					    	
					    
					       // for(int i=0 ; i<ListTotale.size(); i++){
					        	//System.out.println("Op�ration est " + ListTotale.get(i).getName());
					    	
					    	
					    	
					    	
					   // }
					    }
					    double[][] multiples = new double[ListTotale.size()][ListTotale.size()];
						//System.out.println("le nbre totales des op�rations est "+ ListTotale.size());  
						int ensemble_operation=0;
						for(int i=0 ; i<ListTotale.size(); i++){
							//System.out.println("opName:"+ListTotale.get(i).getName());
						}
					        for(int i =0 ; i<ListTotale.size(); i++){
					       	 int vble=i; 
					       	
					       	 for(int k= vble+1 ; k<ListTotale.size();k++){
					       		
					       		 //ListOprt1.add(ListOprt.get(k));
					       		 //System.out.println("****on compare les op�rations num  " + (vble)   + ListTotale.get  (vble)  .getName() + "  et num  "  + (k)   + ListTotale.get (k)  .getName());	  
					       		 Operation op1=ListTotale.get(vble);
					       		 Operation op2=ListTotale.get(k);
					       		
					       		 
					       	 
					       	 
					       	//System.out.println("on compare les op�rations num  "  + (vble) +   ListOprt.get(vble).getName()  +  "  et num  "  + (k) + ListOprt.get(k).getName());	  
					       		double rslt=compare(op1,op2);
					       		ensemble_operation++;
					          	multiples[i][k]=rslt;
					       	
					       	 } 
					       	 // System.out.println(" ** "+" Operation Name ( " + i + " ): " + ListOprt.get(i));  
					        
					         
					       

					       //ListOprt1.clear();
					      
					         }
					        for(int i=0; i<multiples.length ;i++){
					    		for(int j=0; j<multiples.length;j++){
					    		//System.out.println("similarit� entre " + i + "et" + j +"est"+ multiples[i][j]);	
					    		average_sequentiel_cohesion=average_sequentiel_cohesion+multiples[i][j];
					    		}
					    	}
					    	
					    	
					    lack_of_seq_cohesion=1-( (average_sequentiel_cohesion/ensemble_operation) *0.5);
					    //System.out.println("le manque de coh�sion sequentiel est" +lack_of_seq_cohesion);
					    	
					    	JOptionPane.showMessageDialog(null, "le manque de coh�sion sequentiel est" +lack_of_seq_cohesion);
					    	
					    	
					    	
					    	//System.out.println("le nbre de type distingue input est"+nbre_distingueFinal);
					    	
					    	
					    		
					    	
					    	
					    	
					    	
					    	
					    	
					    	
					    	
					    	
					       
							
					  }

					private double compare(Operation op1, Operation op2) {
						// TODO Auto-generated method stub
						
						
						
						
							// TODO Auto-generated method stub
							
							List <String> liste1=typedistingueinput(op1);
							List <String> liste2=typedistingueoutput(op2);
							double nbrecommun=compare_input_output(liste1,liste2);
							//System.out.println("le nbre de types communs entre ces deux op�rations est "+ nbrecommun);
							List<String> listedstop1_op2 = new ArrayList<String>();
							for (int i =0 ; i<liste1.size();i++){
							if(!listedstop1_op2.contains(liste1.get(i))){
								listedstop1_op2.add(liste1.get(i));
							}
							}
							
							for (int i =0 ; i<liste2.size();i++){
								if(!listedstop1_op2.contains(liste2.get(i))){
									listedstop1_op2.add(liste2.get(i));
								}
								}
							
							//System.out.println("le nbre de type distingue totale(input/otput) est"+listedstop1_op2.size());
							//System.out.println("la similarit� s�quentielle entre ces deux op�rations est "+  nbrecommun /listedstop1_op2.size());
							



							List <String> liste11=typedistingueinput(op2);
							List <String> liste22=typedistingueoutput(op1);
							double nbrecommun1=compare_input_output(liste11,liste22);
							//System.out.println("le nbre de types communs entre ces deux op�rations est "+ nbrecommun1);
							List<String> llistedstop1_op2 = new ArrayList<String>();
							for (int i =0 ; i<liste11.size();i++){
							if(!llistedstop1_op2.contains(liste11.get(i))){
								llistedstop1_op2.add(liste11.get(i));
							}
							}
							
							for (int i =0 ; i<liste22.size();i++){
								if(!llistedstop1_op2.contains(liste22.get(i))){
									llistedstop1_op2.add(liste22.get(i));
								}
								}
							
							//System.out.println("le nbre de type distingue totale(output/input) est"+llistedstop1_op2.size());
							//System.out.println("la similarit� s�quentielle (inverse) entre ces deux op�rations est "+  nbrecommun1 /llistedstop1_op2.size());
							double Vle1=nbrecommun /listedstop1_op2.size();
							 double Vle2=nbrecommun1 /llistedstop1_op2.size();
							 double avrgin_out=(Vle1/2);
							double avrgout_in=(Vle2/2);
							double Similarit�= avrgin_out+ avrgout_in ;
							 //System.out.println("La similarit� s�quentielle est �gal � "+ Similarit�);
							 if( Similarit�==1){
								//	System.out.println("---> ces deux op�rations ont une similarit� maximale");
								//	System.out.println(""+ op1.getName());
								//	System.out.println(""+ op2.getName());
									
								}
							return Similarit�; 
							




						}



						private int compare_input_output(List<String> liste1,
								List<String> liste2) {
							int nbrecommun=0;
							
							for(int i= 0; i< liste1.size(); i++){
								String s=liste1.get(i);
								//System.out.println("TypeOp1:"+s);
								
								
								}
							for(int i= 0; i< liste2.size(); i++){
								String s=liste2.get(i);
								//System.out.println("TypeOp2:"+s);
								
								}
							for(int i=0;i<liste1.size();i++){
								if(liste2.contains(liste1.get(i))){
									nbrecommun++;
								}
								
							}
							
						return nbrecommun;
							}
							


						private List<String> typedistingueoutput(Operation op2) {
							// TODO Auto-generated method stub
							
								// TODO Auto-generated method stub
								List<Part> list = new ArrayList<Part>();
								 List<String> listString=new ArrayList<String>();
								  List<String> listD=new ArrayList<String>();
								 
							   //System.out.println(" ** "+" Operation Name: " + operation.getName());
							 
							   //System.out.println("         Operation Input Message: "
								 //   + op.getInput().getMessage().getName().toString());
							   Message msg_output=op2.getOutput().getMessage();
							 
								//System.out.println("              Message Parts: ");
								
								
								for (Part part :  msg_output.getParts()) {
								
									list.add(part);
									
								}
								

								//Message msg_out=operation.getOutput().getMessage();
							  //System.out.println("              Message Parts: ");
								
								//for (Part part : msg_out.getParts()) {
									
									////list.add(part);
								
									//String ch1=part.getElement().getQname().getQualifiedName();
									//if(ch1!=null){
										//listString.add(ch1);
									
								//}
									//String ch2=part.getType().getQname().getQualifiedName();
									//if(ch2!=null){
									//	listString.add(ch2);
									//}
									////}
								
								for( int i=0;i< list.size();i++){
								
								
								
										
								Element ch=list.get(i).getElement();
								

								
								if(ch!=null){
									String s= "s:"+ ch.getQname().getQualifiedName();
								//System.out.println("element: "+s);
								//if(s.equals("s:string")){
									//System.out.println("un element simple");
								//}
								listString.add(s);
								
								
								}
								}
								
								for( int i=0;i< list.size();i++){
									TypeDefinition t=list.get(i).getType();
									
									if(t!=null){
										String s1= t.getQname().getQualifiedName();
										//System.out.println("type: "+ s1);
										listString.add(s1);
									}
								}
								
								
								
								
								//System.out.println("le nbre des elements est "+listString.size());
								
								for(int i=0;i<listString.size();i++){
									//int j=i+1;
								
								//System.out.println("l'�lement num�ro "+ j + " est "+listString.get(i));
								
								if(! listD.contains(listString.get(i))){
									listD.add(listString.get(i));
								}
								
								}
								
								
								//System.out.println("le nbre des elements distingues pour cette op�ration est "+ listD.size());
								
								//for(int i=0 ; i<listD.size();i++){
									//System.out.println(listD.get(i));
								//}
								return listD;
								
								
								
								
							}	


						private List<String> typedistingueinput(Operation op1) {
							// TODO Auto-generated method stub
							
							
								// TODO Auto-generated method stub
								 List<Part> list = new ArrayList<Part>();
								 List<String> listString=new ArrayList<String>();
								  List<String> listD=new ArrayList<String>();
								 
							    //System.out.println(" ** "+" Operation Name: " + operation.getName());
							  
							    //System.out.println("         Operation Input Message: "
								 //   + op.getInput().getMessage().getName().toString());
							    Message msg_input=op1.getInput().getMessage();
							  
								//System.out.println("              Message Parts: ");
								
								
								for (Part part : msg_input.getParts()) {
								
									list.add(part);
									
								}
								

								//Message msg_out=operation.getOutput().getMessage();
							   //System.out.println("              Message Parts: ");
								
								//for (Part part : msg_out.getParts()) {
									
									////list.add(part);
								
									//String ch1=part.getElement().getQname().getQualifiedName();
									//if(ch1!=null){
										//listString.add(ch1);
									
								//}
									//String ch2=part.getType().getQname().getQualifiedName();
									//if(ch2!=null){
									//	listString.add(ch2);
									//}
									////}
								
								for( int i=0;i< list.size();i++){
								
								
								
										
								Element ch=list.get(i).getElement();
								

								
								if(ch!=null){
									String s= "s:"+ ch.getQname().getQualifiedName();
								//System.out.println("element: "+s);
								//if(s.equals("s:string")){
									//System.out.println("un element simple");
								//}
								listString.add(s);
								
								
								}
								}
								
								for( int i=0;i< list.size();i++){
									TypeDefinition t=list.get(i).getType();
									
									if(t!=null){
										String s1= t.getQname().getQualifiedName();
										//System.out.println("type: "+ s1);
										listString.add(s1);
									}
								}
								
								
								
								
								//System.out.println("le nbre des elements est "+listString.size());
								
								for(int i=0;i<listString.size();i++){
									//int j=i+1;
								
								//System.out.println("l'�lement num�ro "+ j + " est "+listString.get(i));
								
								if(! listD.contains(listString.get(i))){
									listD.add(listString.get(i));
								}
								
								}
								
								
								//System.out.println("le nbre des elements distingues pour cette op�ration est "+ listD.size());
								
								//for(int i=0 ; i<listD.size();i++){
									//System.out.println(listD.get(i));
								//}
								return listD;
								
								
						
						
						
						
						
					
		
				
				
				
				
				
				
				
				
			}
		});
		button.setBounds(169, 157, 138, 50);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("Semantic-Similarity");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
			
				
				
			
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			}
		});
		button_1.setBounds(317, 157, 138, 50);
		frame.getContentPane().add(button_1);
		
		
		final JList list = new JList();
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setBorder(new LineBorder(new Color(0, 0, 0), 0, true));
		list.setBounds(193, 237, 237, 184);
		frame.getContentPane().add(list);
		
		JButton button_2 = new JButton("Portypes_Number");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultListModel model=new DefaultListModel();
				for(int i=0; i<20 ;i++){
					model.addElement(i);
				}
				list.setModel(model);
			}
		});
		button_2.setBounds(21, 232, 138, 50);
		frame.getContentPane().add(button_2);
		
		
		
		JCheckBoxMenuItem chckbxmntmPortype = new JCheckBoxMenuItem("Portype");
		chckbxmntmPortype.setBackground(Color.RED);
		chckbxmntmPortype.setBounds(21, 325, 129, 22);
		frame.getContentPane().add(chckbxmntmPortype);
					
		
	
}}
