import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import java.util.Collections;

import Data_Structures.*;

import java.awt.Font;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.awt.Component;

import javax.swing.JSplitPane;

import com.predic8.wsdl.Definitions;
import com.predic8.wsdl.Operation;
import com.predic8.wsdl.PortType;
import com.predic8.wsdl.WSDLParser;

import javax.swing.ListModel;

import rita.wordnet.RiWordnet;



public class interface33 extends JFrame {
    private static int offset = 50; 
	JLabel lb1;
	private  JTable table;
	  JLabel frominterface22;
	private JTable table_2;
	private JTable Matrix;
	private JTable transitive;
	List<String>operation_converties_chaine;
	  ArrayList<Double> ListeBoxPlot = new ArrayList<Double>();

	 
	public interface33 (final JTable table, final List<Services_Registry.Operation> ListeTotale, final String[][] totale, final double[][] tablesem) {
        this.table = table; // Not array[5][5]
	    this.setSize(1045, 704);
	    this.getContentPane().setBackground(Color.PINK);
	    
	    lb1=new JLabel("");
	    lb1.setBounds(0, 0, 0, 0);
	    getContentPane().setLayout(null);
	    getContentPane().add(lb1);
	    
	    final String[]Message={ "0.1","0.2","0.25","0.3" ,"0.4" ,"0.15","0.35","0.27","0.28","0.29"};
	    final JComboBox comboBox = new JComboBox(Message);
	    comboBox.setBounds(450, 158, 61, 23);
	    getContentPane().add(comboBox);
	    
	
	    
	    final JTable table_1_1 = new JTable();
	    table_1_1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	    table_1_1.setBounds(133, 109, 200, 167); 
	    getContentPane().add(table_1_1);
	  
	   
		    
	  	    
	    table_2 = new JTable();
	    table_2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	    table_2. setBounds(530, 109, 200, 167);
	    getContentPane().add(table_2);
	  
	    
	    JLabel lblNewLabel = new JLabel("Select thresold");
	    lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    lblNewLabel.setBounds(355, 154, 107, 31);
	    getContentPane().add(lblNewLabel);
	    
	    
	  
	    DefaultTableModel dm = new DefaultTableModel(0,0);
	      Vector<Object> data1 = new Vector<Object>();
	      for(int i=0; i<table.getColumnCount();i++){
	    	  data1.add(i);
	    	}
	    	
	    	dm.setColumnIdentifiers(data1);
	      
	    	
	    	
	
	    	for(int i=0; i<table.getRowCount() ;i++){
	    		
	    		 Vector<Object> data = new Vector<Object>(); 
	    		for(int j=0; j<table.getColumnCount();j++){
	    			 Object valueac = table.getValueAt( i, j );
	    			double lllc= Double.parseDouble(valueac.toString());
					 		 
					 DecimalFormat df = new DecimalFormat();
						df.setMaximumFractionDigits(2);
				
					 data.add(df.format(lllc));
	    
			 }
	    		
	             dm.addRow(data);
	      
		}
	    	
	    	table_1_1.setModel(dm);
	    	JScrollPane scrollPane = new JScrollPane(table_1_1);
		    scrollPane.setBounds(133, 109, 200, 167);
		   // scrollPane.setViewportView(table_1_1);
	        getContentPane().add(scrollPane);

	    JLabel lblMethodbymethodfiltering = new JLabel("Method_by_Method_Filtering and Transitive Closure");
	    lblMethodbymethodfiltering.setFont(new Font("Times New Roman", Font.BOLD, 15));
	    lblMethodbymethodfiltering.setBounds(313, 11, 368, 71);
	    getContentPane().add(lblMethodbymethodfiltering);
	    
	    JLabel lblMethodbymethodmatrix = new JLabel("<html>Method_by_Method Matrix </br>before filtering </html>");
	    lblMethodbymethodmatrix.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    lblMethodbymethodmatrix.setVerticalAlignment(SwingConstants.BOTTOM);
	    lblMethodbymethodmatrix.setBounds(143, 279, 152, 31);
	    getContentPane().add(lblMethodbymethodmatrix);
	    
	    JLabel lblmethodbymethodMatrixafter = new JLabel("<html>Method_by_Method Matrix </br>after filtering </html>");
	    lblmethodbymethodMatrixafter.setVerticalAlignment(SwingConstants.BOTTOM);
	    lblmethodbymethodMatrixafter.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    lblmethodbymethodMatrixafter.setBounds(541, 280, 152, 37);
	    getContentPane().add(lblmethodbymethodMatrixafter);
	    
	    Matrix = new JTable();
	    Matrix.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	    Matrix.setBounds(143, 421, 200, 167);
	    getContentPane().add(Matrix);
	    
	    
	    
	    transitive = new JTable();
	    transitive.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	    transitive.setBounds(541, 421, 200, 167);
	    getContentPane().add(transitive);
	    
	    JButton btnNewButton = new JButton("Adjacency matrix");
	    btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    btnNewButton.setBounds(166, 605, 143, 37);
	    getContentPane().add(btnNewButton);
	    
	    JButton btnTransitiveClosure = new JButton("Transitive Closure");
	    btnTransitiveClosure.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    btnTransitiveClosure.setBounds(572, 605, 143, 37);
	    getContentPane().add(btnTransitiveClosure);
	    
	    final DefaultListModel listModel1 = new DefaultListModel();
	    JList list = new JList(listModel1);
	    list.setBounds(869, 265, 150, 45);
	    getContentPane().add(list);
	    
	    
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
	

	list.setLayoutOrientation(JList.VERTICAL);
	
	
	JScrollPane scrollPane11 = new JScrollPane(list);
	scrollPane11.setBounds(869, 265, 150, 45);
	getContentPane().add(scrollPane11);
	//scrollPane11.setViewportView(list);
	
	

	    
	
	 final DefaultListModel listModel2 = new DefaultListModel();
	
	
	    JList list_1 = new JList(listModel2);
	    list_1.setBounds(869, 345, 150, 45);
	    getContentPane().add(list_1);
	    
	    list_1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		list_1.setLayoutOrientation(JList.VERTICAL);
	    JScrollPane scrollPane22 = new JScrollPane(list_1);
		scrollPane22.setBounds(869, 345, 150, 45);
		getContentPane().add(scrollPane22);
		//scrollPane22.setViewportView();
	    
	    
	    JButton btnProposedRefactoring = new JButton("Proposed Refactoring");
	    btnProposedRefactoring.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    btnProposedRefactoring.setBounds(869, 434, 160, 37);
	    getContentPane().add(btnProposedRefactoring);
	    
	    JLabel lblSubservice = new JLabel("Sub_Service2");
	    lblSubservice.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    lblSubservice.setBounds(905, 321, 92, 24);
	    getContentPane().add(lblSubservice);
	    
	   frominterface22 = new JLabel("from interface22");
	    frominterface22.setBounds(767, 109, 262, 14);
	    getContentPane().add(frominterface22);
	    frominterface22.setVisible(false);
	    
	    JScrollPane scrollPane_1 = new JScrollPane();
	    scrollPane_1.setBounds(871, 186, 148, 43);
	    getContentPane().add(scrollPane_1);
	    
	    final DefaultListModel listModel22 = new DefaultListModel();
	    JList list_2 = new JList(listModel22);
	    scrollPane_1.setViewportView(list_2);
	    list_2.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
	    list_2.setLayoutOrientation(JList.VERTICAL);
	    
	    JLabel label = new JLabel("Sub_Service1");
	    label.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    label.setBounds(905, 240, 92, 24);
	    getContentPane().add(label);
	    
	    JLabel lblNewLabel_1 = new JLabel("Trivial Chains");
	    lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
	    lblNewLabel_1.setBounds(905, 400, 92, 23);
	    getContentPane().add(lblNewLabel_1);
	    
	   
	    
	    comboBox.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				myBox(e);
				
				
			}

			private void myBox(ActionEvent e) {
			
				if (comboBox.getSelectedItem() != null) {
			
			            Object valueacomboBox=comboBox.getSelectedItem();
			            double lllc= Double.parseDouble(valueacomboBox.toString());
			            
			            
			            DefaultTableModel dm = new DefaultTableModel(0,0);
			  	      Vector<Object> data1 = new Vector<Object>();
			  	      for(int i=0; i<table.getColumnCount();i++){
			  	    	  data1.add(i);
			  	    	}
			            
			  	    dm.setColumnIdentifiers(data1);
			  	    
			  	      
			  	      
			  	  for(int i=0; i<table.getRowCount() ;i++){
			    		
			    		 Vector<Object> data = new Vector<Object>(); 
			    		for(int j=0; j<table.getColumnCount();j++){
			    			 Object valuea = table.getValueAt( i, j );
							 double lll= Double.parseDouble(valuea.toString());
							 if(lll<=lllc){
								 lll=0.0;
								 data.add(lll);
							 }
							 else{
								 data.add(lll); 
							 }
							 
			    
					 }
			    		
			             dm.addRow(data);
			    	
				}
			    	
			    	table_2.setModel(dm);
			    	JScrollPane scrollPane = new JScrollPane(table_2);
				    scrollPane.setBounds(531, 109, 200, 167);
				    //scrollPane.setViewportView(table_2);
			        getContentPane().add(scrollPane);
			   
			  	      
					   
			        }	
				
			}
		});
	    
btnTransitiveClosure.addActionListener(new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				
		
				
		
int nb=Matrix.getColumnCount();

boolean[][]   tc = new boolean[nb][nb];
    for (int i = 0; i < nb; i++) 
    {    
        for (int j = 0; j < nb; j++) {
        	
        	 Object valueac = Matrix.getValueAt( i, j );
		 int lllc= Integer.parseInt(valueac.toString());
            if (lllc != 0)
                tc[i][j] = true;
        tc[i][i] = true;
    }
        }
    for (int i = 0; i <nb; i++) 
    {
        for (int j = 0; j < nb; j++) 
        {
            if (tc[j][i]) 
                for (int k = 0; k < nb; k++) 
                    if (tc[j][i] && tc[i][k]) 
                        tc[j][k] = true;             
        }
    }	


    DefaultTableModel dm = new DefaultTableModel(0,0);
    Vector<Object> data1 = new Vector<Object>();
    for(int i=0; i<Matrix.getColumnCount();i++){
  	  data1.add(i);
  	}
  	
  	dm.setColumnIdentifiers(data1);

    for (int v = 0; v < nb; v++)
    //System.out.print("   " + v );
    System.out.println();
     
    for (int v = 0; v < nb; v++) 
    {
    	Vector<Object> data = new Vector<Object>();
        //System.out.print(v +" ");
        for (int w = 0; w < nb; w++) 
        {
            if (tc[v][w]) 
            	data.add(1);
            
            else                  
               
            data.add(0);
        }
        
        dm.addRow(data);
        System.out.println();
    }
    transitive.setModel(dm);	
    JScrollPane scrollPane = new JScrollPane(transitive);
    scrollPane.setBounds(541, 421, 200, 167);
   // scrollPane.setViewportView(table_1_1);
    getContentPane().add(scrollPane);			
			
			}
		});
	    
	    
	    
	    
	    
	    btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		DefaultTableModel dm = new DefaultTableModel(0,0);
		   	      Vector<Object> data1 = new Vector<Object>();
	    		
	    		for(int i=0; i<table.getColumnCount();i++){
	  	    	  data1.add(i);
	  	    	}
	  	    	
	  	    	dm.setColumnIdentifiers(data1);
	    		 
	    		for(int i=0 ;i<table_2.getRowCount();i++){
	    			 Vector<Object> data = new Vector<Object>();
	    			for(int j=0;j<table_2.getColumnCount();j++){
	    				 Object valueac = table_2.getValueAt( i, j );
						 double lllc= Double.parseDouble(valueac.toString());
	    				if(lllc!=0){
	    					data.add(1);
	    					
	    				}
	    				else{
	    					data.add(0);
	    				}
	    			}
	    			dm.addRow(data);
	    		    			
	    		}
	    		
	    		Matrix.setModel(dm);
		    	JScrollPane scrollPane = new JScrollPane(Matrix);
			    scrollPane.setBounds(143, 421, 200, 167);
			   // scrollPane.setViewportView(table_1_1);
		        getContentPane().add(scrollPane);
	    		
	    		
	    		
	    	}
	    });
	    
   
	    
btnProposedRefactoring.addActionListener(new ActionListener() {
			
		
			public void actionPerformed(ActionEvent e) {
				
				
		
				for(int i=0;i<ListeTotale.size();i++){
					System.out.println("l'op�ration num " + i + "est" + ListeTotale.get(i).get_name());
				}
				
				
				
				 
			    List<String>listop=new ArrayList<String>();
				for(int i=0 ; i<Matrix.getRowCount();i++){
					String ch="";
					for(int j=0;j<Matrix.getColumnCount();j++){
						Object obj=Matrix.getValueAt(i, j);
						String val=""+obj;
						ch=ch+val;
						
					}
					listop.add(ch);
					
				}
				
				//JOptionPane.showMessageDialog(null, "taille de matrice " +listop.size());
				
				List<String>listopDisting=new ArrayList<String>();
				
				for(int i=0;i<listop.size();i++){
					if(!listopDisting.contains(listop.get(i))){
						listopDisting.add(listop.get(i));
						
						
					}
				}
				
				
				JOptionPane.showMessageDialog(null, "nbre des modules est " +listopDisting.size());
				
				
				
				List<String>Trivial_chain=new ArrayList<String>();
				List<String> NonTrivial=new ArrayList<String>();
				for(int i=0;i<listopDisting.size();i++){
					String ch=listopDisting.get(i);
					List<Integer> listopfin=new ArrayList<Integer>();
					for(int k=0;k<listop.size();k++){
						if(listop.get(k).equalsIgnoreCase(ch)){
							 listopfin.add(k);
						}
					
				}
					if(listopfin.size()<2){
						Trivial_chain.add(ch);
					
					}
					else{
						NonTrivial.add(ch);
					}
					
					
					for(int l=0 ; l<listopfin.size();l++){
				    	String chh=ListeTotale.get(listopfin.get(l)).get_name();
				    	
				    System.out.println("l'op�ration "+chh +  " est appartient au module " +  i );
					}
					
								}
				
				for(int i=0;i<NonTrivial.size();i++){
					String ch=NonTrivial.get(i);
					List<Integer> listopfin=new ArrayList<Integer>();
					for(int k=0;k<listop.size();k++){
						if(listop.get(k).equalsIgnoreCase(ch)){
							 listopfin.add(k);
						}
					
				}
					System.out.println("les noms des op�rations de chaine non triviale num " +i);	
				for(int k=0;k<listopfin.size();k++){
					System.out.println(ListeTotale.get(listopfin.get(k)).get_name());
					System.out.println((listopfin.get(k)));
				}
					
				}
				
				
				for(int i=0;i<Trivial_chain.size();i++){
					String ch=Trivial_chain.get(i);
					List<Integer> listopfin=new ArrayList<Integer>();
					for(int k=0;k<listop.size();k++){
						if(listop.get(k).equalsIgnoreCase(ch)){
							 listopfin.add(k);
						}
					
				}
					System.out.println("les noms des op�rations de chaine triviale num " + i);	
				for(int k=0;k<listopfin.size();k++){
					System.out.println(ListeTotale.get(listopfin.get(k)).get_name());
					System.out.println((listopfin.get(k)));
				}
					
				}
				
			
				List<Integer>Num_ChT=new ArrayList<Integer>();
				List<Integer>PosChNTCoupl�=new ArrayList<Integer>();
				for(int i=0;i<Trivial_chain.size();i++){
					String ch=Trivial_chain.get(i);
					//System.out.println("on compare T num " +i + "avec les chaines NT");
					List<Double>similarit�=Calcul_Similarit�(ch,NonTrivial,listop,table);
					int Max_coupl�=Maximunm(similarit�);
					System.out.println("la chaine T num "+ i +"est coupl� avec la chaineNT " + Max_coupl�);
					Num_ChT.add(i);
					PosChNTCoupl�.add(Max_coupl�);
				}
				System.out.println("les num des chaines T");
				for(int i=0;i<Num_ChT.size();i++){
					System.out.println(Num_ChT.get(i));
				}
				
				
				System.out.println("les num des chaines NT correcpond aux chaines T");
				for(int i=0;i<PosChNTCoupl�.size();i++){
					System.out.println(PosChNTCoupl�.get(i));
				}
				
				
				operation_converties_chaine=new ArrayList<String>();
			
				List<Integer>listePos = null; int taille=0;
				List<Integer>Pos_Distingue=new ArrayList<Integer>();
				for(int i=0;i<PosChNTCoupl�.size();i++){
					int pos=PosChNTCoupl�.get(i);
					if(!Pos_Distingue.contains(pos)){
						Pos_Distingue.add(pos);
				listePos=nbre_de_ce_pos(pos,PosChNTCoupl�);
					
					//fusioner(listeP)
					List<Integer>listefusion;
					listefusion=fussioner(listePos,Trivial_chain,pos,NonTrivial,listop);
					String ch=convertie_liste_op_en_chaine(listefusion);
					operation_converties_chaine.add(ch);
					System.out.println("la chaine NT Num" + pos + " avec les chaine T : apr�s fusion" );
					for(int m=0;m<listefusion.size();m++ ){
						System.out.println(ListeTotale.get(listefusion.get(m)).get_name());
						
					}
					
							double com=com(ListeTotale,listefusion);
							 System.out.println("la manque de similarity comunicationnelle est " + com);
							 
							 double seq=seq(ListeTotale,listefusion);
							 System.out.println("la manque de similarity s�quentielle est " + seq
					);
							 
							 double sem=sem(ListeTotale,listefusion,tablesem);
							 System.out.println("la manque de similarity s�mantique est " + sem);
							 
							 double manque_totale=(com+seq+sem)/3;
							 System.out.println("la manque de similarity totale " + manque_totale);	
					
					}
				}
				
				
	
				List<Integer>ChaineNonTrivial=ChaineNonTRiviale(Pos_Distingue,NonTrivial);
				for(int i=0;i<ChaineNonTrivial.size();i++){
					System.out.println("chaineNTTTTTTTTT " +ChaineNonTrivial.get(i));
					System.out.println("ces op�rations");
					List<Integer>List_op=listoperation(NonTrivial,ChaineNonTrivial.get(i) , listop);
					
					String ch=convertie_liste_op_en_chaine(List_op);
					operation_converties_chaine.add(ch);
					
					for(int y=0;y<List_op.size();y++){
						System.out.println(ListeTotale.get(List_op.get(y)).get_name());
						
							
						}
					
				
							
							double com=com(ListeTotale,List_op);
							 System.out.println("la manque de similarity comunicationnelle est " + com);
							 
							 double seq=seq(ListeTotale,List_op);
							 System.out.println("la manque de similarity s�quentielle est " + seq
					);
							 
							 double sem=sem(ListeTotale,List_op,tablesem);
							 System.out.println("la manque de similarity s�mantique est " + sem);
							 
							 double manque_totale=(com+seq+sem)/3;
							 System.out.println("la manque de similarity totale " + manque_totale);	
							
							
						}
					int possibilit�=0; double couplage_de_service=0.0; double somme_couplagedesmodules=0.0;
			
					for(int i=0;i<operation_converties_chaine.size();i++) {
						String ch=operation_converties_chaine.get(i);
						for(int j=i+1;j<operation_converties_chaine.size();j++){
							
							
							String ch1=operation_converties_chaine.get(j);
							String[] str_array = ch.split("/");
							String[] str_array1 = ch1.split("/");
							
							List<Integer>numero_op=convertie_entier(str_array);
						
							for(int t=0;t<numero_op.size();t++){
									
							}
							List<Integer>numero_op1=convertie_entier(str_array1);
							
							
							for(int t=0;t<numero_op1.size();t++){
							
							}
							
							
							Double couplage_entreModule=Comparer(numero_op,numero_op1);
							possibilit�++;
			
					
					somme_couplagedesmodules=somme_couplagedesmodules+couplage_entreModule;
						
						
					}
					}
				System.out.println("*****************************************");
				System.out.println("le couplage totale de service apr�s refactoring " + somme_couplagedesmodules/possibilit�);
				
		
				
				}
		
		
					
				}
				
				
				
	
				
			
	        );
	    
	        }	    
	

	











	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



	




	protected Double Comparer(List<Integer> numero_op, List<Integer> numero_op1) {
	
		double couplage_totale=0.0; double couplage_moyen=0.0;
		for(int i=0;i<numero_op.size();i++){
		int num_op=numero_op.get(i);
		double couplage =calcule_similarit�(num_op,numero_op1);
		//System.out.println("le couplage de l'op num " + i + "avec Module l'autre module " + couplage);
		couplage_totale=couplage_totale+couplage;
		
	 }
		return couplage_moyen=couplage_totale/numero_op.size();
	
		
		
	 }





	private double calcule_similarit�(int num_op, List<Integer> numero_op1) {
		double somme_couplage=0.0;
		for(int i=0;i<numero_op1.size();i++){
		int num_op1=numero_op1.get(i);
		//Double couplage=similarit�(num_op,num_op1);
		Object val	=table.getValueAt(num_op,num_op1);
		double couplage=Double.parseDouble(val.toString());
	//System.out.println("la similarit� entre op num " + num_op  + "et op num" +num_op1 + " est " + couplage);
		somme_couplage=somme_couplage+couplage;
	}
	return somme_couplage/numero_op1.size();
	}
		
	





	protected List<Integer> convertie_entier(String[] str_array) {
		List<Integer>list=new ArrayList<Integer>();
		
		for(int i=0;i<str_array.length;i++){
			int num=Integer.parseInt(str_array[i]);
			list.add(num);
		}
		return list;
	}





	protected String convertie_liste_op_en_chaine(List<Integer> listefusion) {
		String chNumber="";
		for(int i=0;i<listefusion.size();i++){
		String ch=String.valueOf(listefusion.get(i))	;
		//System.out.println("le nobre num " + i + "de cette chaine est " +ch);
		chNumber=chNumber+ch;
		chNumber=chNumber+"/" ;
		}
		return chNumber;
	}










	protected List<Integer> ChaineNonTRiviale(List<Integer> pos_Distingue,
			List<String> nonTrivial) {
		// TODO Auto-generated method stub
	List<Integer>Liste_op_NT=new ArrayList<Integer>();
	for(int i=0;i<nonTrivial.size();i++){
		if(!pos_Distingue.contains(i)){
			Liste_op_NT.add(i);
		}
		
	}
	return Liste_op_NT;
	}





	protected List<Integer> fussioner(List<Integer> listePos,
			List<String> trivial_chain, int pos, List<String> nonTrivial,
			List<String> listop) {
		
		List<Integer>List_op=listoperation(nonTrivial, pos, listop);
		List<Integer>list_op1=new ArrayList<Integer>();
		for(int i=0;i<listePos.size();i++){
			int p=listop.indexOf(trivial_chain.get(listePos.get(i)));
			//List<Integer>listeop2=listoperation(trivial_chain, listePos.get(i), listop);
		list_op1.add(p);
			//for(int t=0;t<trivial_chain.size();t++){
	   // int p=listop.indexOf(trivial_chain.get(listePos.get(i)));
	    //for(int t=0;t<listeop2.size();t++){
			//list_op1.add(listeop2.get(t));
		//}
	    
		}
	
		List<Integer>List_final=new ArrayList<Integer>();
		for(int i=0;i<List_op.size();i++){
			List_final.add(List_op.get(i));
		}
		for(int i=0;i<list_op1.size();i++){
			List_final.add(list_op1.get(i));
		}
		return List_final;
		
	}





	protected List<Integer> nbre_de_ce_pos(int pos, List<Integer> posChNTCoupl�) {
		// TODO Auto-generated method stub
		List<Integer>List_Pos=new ArrayList<Integer>();
		for(int i=0;i<posChNTCoupl�.size();i++){
			if(posChNTCoupl�.get(i)==pos){
				List_Pos.add(i);
			}
		}
		return List_Pos;
	}





	protected List<Double> Calcul_Similarit�(String ch, List<String> nonTrivial, List<String> listop, JTable table2) {
		// TODO Auto-generated method stub
		List<Double>List_sim=new ArrayList<Double>();
		for(int i=0;i<nonTrivial.size();i++){
			String ch1=nonTrivial.get(i);
			//System.out.println("Triviale chaine avec NT num " + i);
			double coh�sion=CompareChain(ch,ch1,listop,table2);
			//System.out.println("la coh�sion entre ce chaineT avec la chaine NT num " + i +"est " +coh�sion);
			List_sim.add(coh�sion);
		}
		return List_sim;
	}





	protected int Maximunm(List<Double> list_similarit�) {
		// TODO Auto-generated method stub
		int pos=-1; double ValeurMax=-1;
		for(int i=0;i<list_similarit�.size();i++){
			if(list_similarit�.get(i)>ValeurMax){
				 
				ValeurMax=list_similarit�.get(i);
				 pos=i;
			}
		}
		return pos;
		
		
	}





	





	private List<Integer> listoperation(List<String> nonTrivial, int max,
			List<String> listop) {
        String ch=nonTrivial.get(max);
        List<Integer>liste=Liste_operation(ch,listop);

		
		return liste;
	   }





	protected double CompareChain(String ch, String ch1, List<String> listop, JTable table2) {
		int pos=listop.indexOf(ch);
		//List<Integer>listeT=Liste_operation(ch,listop);
		double somme_cohesion = 0.0; int possibilit�=0;
		List<Integer>liste=Liste_operation(ch1,listop);
		//for(int t=0;t<listeT.size();t++){
			//int val=listeT.get(t);
		for(int i=0;i<liste.size();i++){
		//Object vall	=table.getValueAt(liste.get(i),val);
		Object vall	=table.getValueAt(liste.get(i),pos);
			double coh�sion=Double.parseDouble(vall.toString());
			possibilit�++;
			//System.out.println("la similarit� entre op num " + pos  + "et op num" +liste.get(i) + " est " + coh�sion);
			somme_cohesion=somme_cohesion+coh�sion;
		}
		
		
		
		
		return somme_cohesion/liste.size();
		}
	
	

	private List<Integer> Liste_operation(String ch1, List<String> listop) {
		List<Integer> listopfin=new ArrayList<Integer>();
		for(int k=0;k<listop.size();k++){
			if(listop.get(k).equalsIgnoreCase(ch1)){
				 listopfin.add(k);
			}}
		return listopfin;
		
	}

	
	

	

	protected double seq(List<Services_Registry.Operation> listeTotale,
			List<Integer> listopfin) {
		// TODO Auto-generated method stub

	    
		double lack_of_seq_cohesion=0;
	  
			int ensemble_operation_seq=0;
  
    for(int i=0;i<listopfin.size();i++){
    	for(int j=i+1 ;j<listopfin.size();j++){
    		
    		 Services_Registry.Operation op1=listeTotale.get(listopfin.get(i));
       		 Services_Registry.Operation op2=listeTotale.get(listopfin.get(j));
       	 	
       		 ensemble_operation_seq++;
       	
      	double cohesion=op1.get_sequential_coefficient(op2);
      	//System.out.println("la similarit� s�quentielle entre " + listeTotale.get(listopfin.get(i)).get_name() + " et " + listeTotale.get(listopfin.get(j)).get_name() +"est " + cohesion);
      	double manque=1-cohesion;
      	
      	lack_of_seq_cohesion=lack_of_seq_cohesion+manque;
     	
    		
    	}
    }
    double lack=(lack_of_seq_cohesion/ensemble_operation_seq);
    	
    DecimalFormat df_seq = new DecimalFormat();
    df_seq.setMaximumFractionDigits(2);
	  
    return lack;
    
	}
	

	protected double com(List<Services_Registry.Operation> listeTotale,
			List<Integer> listopfin) {
		double lack_of_com_cohesion=0;
		  
		int ensemble_operation_com=0;

for(int i=0;i<listopfin.size();i++){
	for(int j=i+1 ;j<listopfin.size();j++){
		
		 Services_Registry.Operation op1=listeTotale.get(listopfin.get(i));
   		 Services_Registry.Operation op2=listeTotale.get(listopfin.get(j));
   	 	
   		 ensemble_operation_com++;
   	
  	double cohesion=op1.get_communicational_coefficient(op2);
  	//System.out.println("la similarit� communicationelle entre " + listeTotale.get(listopfin.get(i)).get_name() + " et " + listeTotale.get(listopfin.get(j)).get_name() +"est " + cohesion);
  	double manque=1-cohesion;
  	
  	lack_of_com_cohesion=lack_of_com_cohesion+manque;
 	
		
	}
}
double lack=(lack_of_com_cohesion/ensemble_operation_com);
	
DecimalFormat df_seq = new DecimalFormat();
df_seq.setMaximumFractionDigits(2);
 
return lack;
	}

	public double sem(List<Services_Registry.Operation> listeTotale,
			List<Integer> listopfin, double[][] tablesem) {
		
		double somme_lack= 0.0; double possibilit�=0.0;
		for(int i=0;i<listopfin.size();i++){
			//String ch=listeTotale.get(listopfin.get(i)).get_name();
			for(int j=i+1;j<listopfin.size();j++){
				//String ch1=listeTotale.get(listopfin.get(j)).get_name();
			    possibilit�++;
			   double  Similarit�= tablesem[listopfin.get(i)][listopfin.get(j)];
			   
			  // System.out.println("la similarit� s�mantique entre " + listeTotale.get(listopfin.get(i)).get_name() + " et " + listeTotale.get(listopfin.get(j)).get_name() +"est " + Similarit�);
			  
				
			   somme_lack=somme_lack+(1-Similarit�);
			
				
			
			}}
		
		return somme_lack/possibilit�;
	
	


	
	}

	

	

	

	
	

}

 		 		
 		 		
 		 		
 		
	