

public class Main_class {
	public static void main ( String[] args )
	  {
		new interface11("hello").setVisible(true);

		
	  }
}
